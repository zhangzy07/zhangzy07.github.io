import torch
import torch.nn as nn
import torch.optim as optim

import statistics

from utils.misc import *
from utils.test_helpers import *
from utils.prepare_dataset import *
from utils.discrepancy import *
from tqdm import tqdm

from utils.tools import Timer

from utils.contrastive import SupConLoss
from datetime import datetime


def evaluation_cifar(model, dataloader):
    criterion = nn.CrossEntropyLoss(reduction='none').cuda()
    correct_ = 0
    tot_ = 0
    loss_ = 0.
    for batch_idx, (inputs, labels) in enumerate(dataloader):
        inputs, labels = inputs.cuda(), labels.cuda()
        with torch.no_grad():
            soft_pred = model.classifier(inputs)
            loss = criterion(soft_pred, labels)
            loss_ += loss.mean()
            _, predicted = soft_pred.max(1)
            correct_ += (labels == predicted).sum().item()
            tot_ += labels.shape[0]

    return loss_.cpu().numpy(), correct_ / tot_


def offline_train(cfgs, train_set, logger):
    model = TTA_ResNet(cfgs['Data']['kwargs']['class_num'])
    train_sampler = torch.utils.data.RandomSampler(train_set)
    trloader = torch.utils.data.DataLoader(
        train_set, batch_size=cfgs['Model']['Classifier']['kwargs']['source_batch_size'],
        sampler=train_sampler, drop_last=False, num_workers=4)

    parameters = list(model.classifier.parameters()) + list(model.head.parameters())
    optimizer = optim.SGD(parameters, lr=0.1, momentum=0.9, weight_decay=5e-4)
    scheduler = torch.optim.lr_scheduler.MultiStepLR(
        optimizer, [50, 65], gamma=0.1, last_epoch=-1)
    criterion = nn.CrossEntropyLoss().cuda()
    criterion_ssl = nn.CrossEntropyLoss().cuda()

    print('Running...')
    time_helper = Timer()

    n_total = len(trloader)
    print("Starting Offline Training")
    epoch = 0
    cur_step = 0
    for epoch in range(cfgs['Model']['Classifier']['kwargs']['init_erm']):
        model.classifier.train()
        model.self_learner.train()
        time_helper.tik()
        last_loss = 0.0
        for step, (inputs, labels) in enumerate(
                tqdm(trloader, desc='Train | epoch:{} | loss:{}'.format(epoch + 1, last_loss))):
            optimizer.zero_grad()

            inputs_cls, labels_cls = inputs.cuda().float(), labels.cuda().long()
            outputs_cls = model.classifier(inputs_cls)
            loss_cls = criterion(outputs_cls, labels_cls)

            if cfgs['Init']['shared'] is not None:
                inputs_ssl, labels_ssl = rotate_batch(inputs, cfgs['Init']['rotation_type'])
                inputs_ssl, labels_ssl = inputs_ssl.cuda(), labels_ssl.cuda()
                outputs_ssl = model.self_learner(inputs_ssl)
                loss_ssl = criterion_ssl(outputs_ssl, labels_ssl)

            loss = loss_cls + loss_ssl
            last_loss = loss.item()
            loss.backward()
            optimizer.step()
            cur_step = epoch * n_total + step
        scheduler.step()
        loss, acc = evaluation_cifar(model, trloader)
        logger.info(f"Train: epoch: {epoch + 1:>02}, cur_step: {cur_step}, loss: {loss:.5f}, acc: {acc:.5f}")

    if not os.path.exists('./offline_model'):
        os.makedirs('./offline_model')

    # save model to the offline_model directory
    dt = datetime.now().strftime('%m%d_%H%M%S')
    torch.save(model.state_dict(), './offline_model/offline_model_{}_{}.pth'.format(epoch + 1, dt))

    return model


def offline_feature_summarization(trloader, ext, scale):
    ext.eval()

    mu_src = None
    cov_src = None

    coral_stack = []
    mmd_stack = []
    feat_stack = []

    with torch.no_grad():
        for batch_idx, (inputs, labels) in enumerate(trloader):
            feat = ext(inputs.cuda())
            cov = covariance(feat)
            mu = feat.mean(dim=0)

            if cov_src is None:
                cov_src = cov
                mu_src = mu
            else:
                loss_coral = coral(cov_src, cov)
                loss_mmd = linear_mmd(mu_src, mu)
                coral_stack.append(loss_coral.item())
                mmd_stack.append(loss_mmd.item())
                feat_stack.append(feat)

    print("Source loss_mean: mu = {:.4f}, std = {:.4f}".format(scale,
                                                               scale / statistics.mean(mmd_stack) * statistics.stdev(
                                                                   mmd_stack)))
    print("Source loss_coral: mu = {:.4f}, std = {:.4f}".format(scale,
                                                                scale / statistics.mean(coral_stack) * statistics.stdev(
                                                                    coral_stack)))

    feat_all = torch.cat(feat_stack)
    feat_cov = covariance(feat_all)
    feat_mean = feat_all.mean(dim=0)
    return feat_cov, statistics.mean(coral_stack), feat_mean, statistics.mean(mmd_stack)