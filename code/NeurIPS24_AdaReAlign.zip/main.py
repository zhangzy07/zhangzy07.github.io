# /usr/bin/env python
# -*- coding: utf-8 -*-

import json as js
import os
import time
from os.path import join

from tqdm import tqdm
import random

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.tensorboard import SummaryWriter
import numpy as np

from online.estimator.TTA import TTA
from utils.contrastive import *
from utils.argparser import argparser
from utils.test_helpers import *
from utils.prepare_dataset import *
from utils.logger import MyLogger
from dataset.wrapper import get_dataset
from offline_train import offline_train

from offline_train import offline_train, offline_feature_summarization

from utils.tools import Timer
timer = Timer()

import warnings
warnings.filterwarnings('ignore')


def write(writer, info, t):
    for k, v in info.items():
        writer.add_scalar(k, v, t)

def set_cpu_num(cpu_num):
    os.environ['OMP_NUM_THREADS'] = str(cpu_num)
    os.environ['OPENBLAS_NUM_THREADS'] = str(cpu_num)
    os.environ['MKL_NUM_THREADS'] = str(cpu_num)
    os.environ['VECLIB_MAXIMUM_THREADS'] = str(cpu_num)
    os.environ['NUMEXPR_NUM_THREADS'] = str(cpu_num)
    torch.set_num_threads(cpu_num)
    torch.set_num_interop_threads(cpu_num)

def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True


def run(cfgs, test_set, train_set, model, writer=None):
    record = []
    error_ = 0.
    time_helper = Timer()
    time_helper.tik()

    round = cfgs['Data']['kwargs']['round']
    duration = cfgs['Data']['kwargs']['duration']
    for t in tqdm(range(round*duration)):

        teloader, teset = test_set[t]

        model.forward(teloader, teset)

        err = [model.eval_test(teloader, base)[0] for base in model._schedule.bases]
        print("error", t+1, err)

        err_t, ssl_loss_t = model.evaluation(teloader)
        error_ += err_t

        if writer is not None:
            res_info = {
                'Error/1-Instant Error': err_t,
                'Error/2-Avg Loss': float(error_/t),
                'Error/3-SSL Loss': float(ssl_loss_t),
            }

            write(writer, res_info, t)
            for k, v in res_info.items():
                res_info[k] = v.item() if isinstance(v, torch.Tensor) else v
            record.append(res_info)

        if t % cfgs.get('log_interval', 100) == 0:
            time_helper.tok('{} rounds'.format(t))
            print(
            '\n[Time {}] Ins Error: {}, Avg Error: {}, SSl Loss: {}'.format(t, err_t, float(error_/t), float(ssl_loss_t)))

    return record

if __name__ == "__main__":
    import os

    cfgs = argparser()
    device = cfgs.get('device')
    cpu_num = cfgs.get('cpu_num')
    set_cpu_num(cpu_num)
    setup_seed(cfgs['random_seed'])
    rng = np.random.default_rng(cfgs['random_seed'])

    torch.cuda.set_device(3)

    writer = None
    if cfgs.get('write', True):
        writer = SummaryWriter(join(cfgs['output'],
                                    'runs_{}'.format(time.strftime("%a_%b_%d_%H:%M:%S",
                                                                   time.localtime()))))
    print(join(cfgs['output'],
               'runs_{}'.format(time.strftime("%a_%b_%d_%H:%M:%S",
                                                                   time.localtime()))))

    logger = MyLogger('{}/{}'.format(cfgs['output'], 'log.txt'))
    logger.info(str(cfgs['output']))

    # TODO: load cifar and imagenet benchmark data here
    train_set, test_set, data_info = get_dataset(
        name=cfgs['Data']['name'],
        cfgs=cfgs['Data']['kwargs'],
        rng=rng
    )
    print("data loaded")

    init_model = TTA_ResNet(cfgs['Data']['kwargs']['class_num'])
    if 'path' in cfgs['Model']:
        init_model.load_state_dict(torch.load(cfgs['Model']['path']))
        print("load offline model")
    else:
        init_model = offline_train(cfgs, train_set, logger)
        print("offline model trained")
    print("offline model builded")

    # for debug
    train_sampler = torch.utils.data.RandomSampler(train_set)
    trloader = torch.utils.data.DataLoader(
        train_set, batch_size=cfgs['Model']['Classifier']['kwargs']['source_batch_size'],
        sampler=train_sampler, drop_last=False, num_workers=4)
    from offline_train import evaluation_cifar

    loss, acc = evaluation_cifar(init_model, trloader)
    print(f"evaluate init_model on cifar_train_set: acc {acc}, loss {loss}")

    # ----------- Offline Feature Summarization -----------
    scale_ext = cfgs['Align']['scale_ext']
    cov_src_ext, coral_src_ext, mu_src_ext, mmd_src_ext = offline_feature_summarization(trloader, init_model.ext,
                                                                                        scale_ext)
    scale_coral_ext = scale_ext / coral_src_ext
    scale_mmd_ext = scale_ext / mmd_src_ext 
    src_ext_feature = (cov_src_ext, scale_coral_ext, mu_src_ext, scale_mmd_ext)

    # ----------- Build Online TTA Model -----------
    model = TTA(cfgs, init_model, src_ext_feature, seed=rng)

    # ----------- Online Test -----------
    record = run(cfgs, test_set, train_set, model, writer=writer)

    avg_instant_error = sum([rec['Error/1-Instant Error'] for rec in record]) / len(record)
    avg_ssl_error = sum([rec['Error/2-SSL Loss'] for rec in record]) / len(record)
    print(f"avg_instant_error: {avg_instant_error}, avg_ssl_error: {avg_ssl_error}")
    record.append({'avg_instant_error': avg_instant_error, 'avg_ssl_error': avg_ssl_error})

    with open(join(output_dir, 'result.json'), 'w') as fw:
        js.dump(record, fw, indent=4)