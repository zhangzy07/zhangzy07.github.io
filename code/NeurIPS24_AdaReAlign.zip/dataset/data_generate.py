import numpy as np

from toy_data import get_offline_data

dim = 20
get_offline_data(rng=np.random.default_rng(),
                 train_num=10000, dim=dim,
                 centers=[-1*np.ones(dim), np.ones(dim)],
                 covs=[4*np.eye(dim), 4*np.eye(dim)],
                 source_priors=[.5, .5],
                 radius=10,
                 cls_num=2,
                 output="")
