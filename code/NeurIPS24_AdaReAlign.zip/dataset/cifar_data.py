# /usr/bin/env python
# -*- coding: utf-8 -*-

import torch
import torch.utils.data as data
import torchvision
import numpy as np
from PIL import Image

common_corruptions = ['gaussian_noise', 'shot_noise', 'impulse_noise', 'defocus_blur', 'glass_blur',
					'motion_blur', 'zoom_blur', 'snow', 'frost', 'fog',
					'brightness', 'contrast', 'elastic_transform', 'pixelate', 'jpeg_compression']

class TempSet(data.Dataset):
    def __init__(self, data, img, labels):
        self.data = data
        self.img = img
        self.labels = labels
        self.ori_data = data
        self.ori_img = img

    def __getitem__(self, idx):
        data, labels = self.data[idx], self.labels[idx]
        return data, labels, idx
    
    def get_data(self, idx):
        data, img, labels = self.data[idx], self.img[idx], self.labels[idx]
        return data, img, labels, idx

    def __len__(self):
        return len(self.labels)

class CifarTest(data.Dataset):
    def __init__(self, cfgs, rng=None, transform=None):
        self.rng = rng
        self.per_round_num = cfgs['per_round_num']
        self.dataroot = cfgs['path']
        self.T = cfgs['round']
        self.duration = cfgs['duration']
        self.shift_mode = cfgs['shift_mode']
        self.transform = transform
        self.ori_data = torchvision.datasets.CIFAR10(root=cfgs['path'], train=False,
                                                      download=True, transform=transform)
        self.batch_size = cfgs['batch_size']

        if self.shift_mode == 'gradual':
            severity_template = [1, 2, 3, 4, 5, 4, 3, 2, 1]
            severities = [severity_template[np.mod(t, 9)] for t in range(self.T)]
            severities = [x for x in severities for i in range(self.duration)]
            corruptions = [common_corruptions[np.mod(t // 9, len(common_corruptions))] for t in range(self.T)]
            corruptions = [x for x in corruptions for i in range(self.duration)]
        elif self.shift_mode == 'sequential':
            severities = [5] * self.T*self.duration
            corruptions = [common_corruptions[np.mod(t, len(common_corruptions))] for t in range(self.T)]
            corruptions = [x for x in corruptions for i in range(self.duration)]
        elif self.shift_mode == 'random':
            severities = [5] * self.T*self.duration
            corruptions = [common_corruptions[np.random.randint(len(common_corruptions))] for t in range(self.T)]
            corruptions = [x for x in corruptions for i in range(self.duration)]
        elif self.shift_mode == 'fix_test':
            severities = [3] * self.T
            corruptions = ['contrast'] * self.T
        else:
            raise NotImplementedError

        tesize = 10000
        te_img = []
        for i in common_corruptions:
            tmp_data = np.load(cfgs['path'] + '/CIFAR-10-C/%s.npy' % (i))
            tmp_img = [Image.fromarray(img.astype(np.uint8)) for img in tmp_data]
            te_img.append(tmp_img)
        te_labels = np.load(cfgs['path'] + '/CIFAR-10-C/labels.npy').astype(np.int64)

        self.img = []
        self.labels = []
        for i in range(self.T*self.duration):
            severity = severities[i]
            corruption = corruptions[i]
            corruption_idx = common_corruptions.index(corruption)
            tmp_cor_img = te_img[corruption_idx][(severity-1) * tesize: (severity) * tesize]
            idx = np.random.choice(tesize, cfgs['per_round_num'])
            img = [tmp_cor_img[i] for i in idx]
            labels = [te_labels[i + (severity-1) * tesize] for i in idx]
            self.img.append(img)
            self.labels.append(labels)

    def __getitem__(self, t):
        img, labels = self.img[t], self.labels[t]

        data = []
        if self.transform is not None:
            for i in img:
                data.append(self.transform(i))
        else:
            for i in img:
                data.append(i)

        dataset = TempSet(data, img, labels)
        sampler = torch.utils.data.RandomSampler(dataset)
        dataloader = torch.utils.data.DataLoader(
            dataset, batch_size=self.batch_size, sampler=sampler,
            drop_last=False, num_workers=4)

        return dataloader, dataset

class CifarTrain(data.Dataset):
    def __init__(self, cfgs, rng=None, transform=None):
        if rng is None:
            rng = np.random.default_rng()
        self.rng = rng
        self.transform = transform
        self.dataset = None

        if cfgs['name'] == 'cifar10':
            self.dataset = torchvision.datasets.CIFAR10(root=cfgs['path'],
                                                        train=True, download=True,
                                                        transform=transform)
        elif cfgs['name'] == 'cifar100':
            self.dataset = torchvision.datasets.CIFAR100(root=cfgs['path'],
                                                         train=True, download=True,
                                                         transform=transform)
        else:
            raise Exception('Dataset not found!')

        self.info = {
            'dim': cfgs['dim'],
            'channel_num': cfgs['channel_num'],
            'class_num': cfgs['class_num'],
        }

    def __len__(self):
        return len(self.dataset.data)