# /usr/bin/env python
# -*- coding: utf-8 -*-

from os.path import join

import torch
import torch.utils.data as data
from utils.shift_simulate import *

import pickle
from wildtime import dataloader
import argparse
import random
from tqdm import trange, tqdm
from PIL import Image


class SeqTrain(data.Dataset):
    def __init__(self, cfgs, name, path, start_time, end_time, rng=None, transform=None):
        if rng is None:
            rng = np.random.default_rng()
        self.rng = rng
        self.transform = transform
        self.data = []
        self.labels = []
        self.time = []

        configs = argparse.Namespace(dataset=name, device=0, random_seed=rng.integers(1, 1000),
                                     reduced_train_prop=None, data_dir=path, mini_batch_size=1, method='erm')
        data = dataloader.getdata(configs)
        all_data, all_label, all_time = [], [], []
        for i in trange(start_time, end_time):
            # [0] is tr data, [1] is te data, [2] OOD Data is mix of all times data
            images = data.datasets[i][0]['images']
            labels = data.datasets[i][0]['labels']
            for idx in range(len(images)):
                image = images[idx]
                image = image.astype(np.uint8)
                image = Image.fromarray(image)
                all_data.append(image)
                all_label.append(labels[idx])
                all_time.append(i)
        self.data = all_data
        self.labels = all_label
        self.time = all_time

        self.info = {
            'channel_num': cfgs['channel_num'],
            'dim'        : cfgs['dim'],
            'class_num'    : cfgs['class_num'],
        }
    
    def __getitem__(self, idx):
        img, target = self.data[idx], self.labels[idx]

        if self.transform is not None:
            img = self.transform(img)

        return img, target
    
    def __len__(self):
        return len(self.data)

class TempSet(data.Dataset):
    def __init__(self, X, y):
        self.data = X
        self.labels = y

    def __getitem__(self, idx):
        img, target = self.data[idx], self.labels[idx]

        return img, target, idx

    def __len__(self):
        return len(self.labels)


class SeqTest(data.Dataset):
    def __init__(self, cfgs, name, path, start_time, end_time, rng=None, transform=None):
        if rng is None:
            rng = np.random.default_rng()
        self.rng = rng
        
        configs = argparse.Namespace(dataset=name, device=0, random_seed=rng.integers(1, 1000),
                                     reduced_train_prop=None, data_dir=path, mini_batch_size=1, method='erm')
        data = dataloader.getdata(configs)
        tmp_data, tmp_label, tmp_time_period, tmp_num = [], [], [], 0
        self.data = []
        self.label = []
        self.time_period_idx = []
        for i in trange(start_time, end_time):
            # [0] is tr data, [1] is te data, [2] OOD Data is mix of all times data
            images = data.datasets[i][0]['images']
            labels = data.datasets[i][0]['labels']
            for idx in range(len(labels)):
                image = images[idx]
                image = image.astype(np.uint8)
                image = Image.fromarray(image)
                tmp_data.append(image)
                tmp_label.append(labels[idx])
                tmp_time_period.append([i])
                tmp_num += 1
                if tmp_num == cfgs['per_round_num']:
                    self.data.append(tmp_data)
                    self.label.append(tmp_label)
                    self.time_period_idx.append(tmp_time_period)
                    tmp_data, tmp_label, tmp_time_period, tmp_num = [], [], [], 0
        
        self.transform = transform
        self.info = {
            'dim'    : cfgs['dim'],
            'class_num': 2,
        }
    
    def _pre_process(self, img):  # Pre-processing one image.
        # img = np.array(img).astype(np.float32)
        return img
    
    def __getitem__(self, idx):
        img, target = self.data[idx], self.label[idx]
        # img, target = self.data[idx], int(self.label[idx])
        # doing this so that it is consistent with all other datasets
        # to return a PIL Image
        
        img = self._pre_process(img)

        imgs = []
        if self.transform is not None:
            for i in img:
                imgs.append(self.transform(i))
        else:
            for i in img:
                imgs.append(i)

        tmpset = TempSet(imgs, target)
        tmp_sampler = torch.utils.data.RandomSampler(tmpset)
        tmploader = torch.utils.data.DataLoader(
            tmpset, batch_size=8, sampler=tmp_sampler,
            drop_last=False, num_workers=4)
        
        return tmploader
    
    def __len__(self):
        return len(self.data)
    
    def get_eval(self, idx):
        img, target = self.data[idx], self.label[idx]
        # img, target = self.data[idx], int(self.label[idx])
        # doing this so that it is consistent with all other datasets
        # to return a PIL Image
        
        img = self._pre_process(img)
        
        # if self.transform is not None:
        #     img = self.transform(img)
        
        #dat = None
        #if self.transform is not None:
        #    for i in img:
        #        d = self.transform(i).unsqueeze(0)
        #        if dat is None:
        #            dat = d
        #        else:
        #            dat = torch.cat([dat, d], 0)
        #else:
        #    dat = img
        
        #if self.label_transform is not None:
        #    target = self.label_transform(target)
        
        return img, target, idx