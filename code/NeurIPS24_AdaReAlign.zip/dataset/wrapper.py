# /usr/bin/env python
# -*- coding: utf-8 -*-

from dataset.toy_data import ToyTrainSet, ToyTestSet
from dataset.cifar_data import CifarTrain, CifarTest
from dataset.sequential_data import SeqTrain, SeqTest
from torchvision import datasets, transforms


def prepare_transforms():
    tr_transforms = transforms.Compose([
        transforms.RandomCrop(32, padding=4),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
    ])

    te_transforms = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
    ])

    simclr_transforms = transforms.Compose([
        transforms.RandomResizedCrop(size=32, scale=(0.2, 1.)), 
        transforms.RandomHorizontalFlip(),
        transforms.RandomApply([
            transforms.ColorJitter(0.4, 0.4, 0.4, 0.1)
        ], p=0.8),
        transforms.RandomGrayscale(p=0.2),
        transforms.ToTensor(),
        transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
    ])

    return tr_transforms, te_transforms, simclr_transforms


class TwoCropTransform:
    """Create two crops of the same image"""
    def __init__(self, transform):
        self.transform = transform

    def __call__(self, x):
        return [self.transform(x), self.transform(x)]


def get_dataset(name, cfgs, rng):
    train_set, test_set, info = None, None, {}
    tr_transforms, te_transforms, simclr_transforms = prepare_transforms()
    if name == "cifar10":
        train_set = CifarTrain(cfgs, rng=rng, transform=tr_transforms)
        print("train data loaded")
        info = train_set.info
        train_set = train_set.dataset
        test_set = CifarTest(cfgs, rng=rng, transform=te_transforms)
        print("test data loaded")
    elif name == 'yearbook':
        train_set = SeqTrain(cfgs, name, cfgs['path'], cfgs['tr_start_time'], cfgs['tr_end_time'],
                             rng=rng, transform=TwoCropTransform(simclr_transforms),
                             )
        print("train data loaded")
        info = train_set.info
        test_set = SeqTest(cfgs, name, cfgs['path'], cfgs['te_start_time'], cfgs['te_end_time'],
                           rng=rng, transform=TwoCropTransform(simclr_transforms),
                           )
        print("test data loaded")
    else:
        raise NotImplementedError

    return train_set, test_set, info
