# /usr/bin/env python
# -*- coding: utf-8 -*-

from torch import nn

from model.ResNetGN import SupConResNet, LinearClassifier
from model.SelfLearningHead import ExtractorHead

class TTA_ResNet(nn.Module):
    def __init__(self, class_num=10, group_norm=8):
        super(TTA_ResNet, self).__init__()
        self.class_num = class_num
        self.group_norm = group_norm
        self.self_learner = SupConResNet(group_norm).cuda()
        self.ext = self.self_learner.encoder
        self.head = self.self_learner.head
        self.linear = LinearClassifier(feat_dim=self.ext.dim_out, num_classes=class_num).cuda()
        self.classifier = ExtractorHead(self.ext, self.linear).cuda()

    def forward(self, x, mode='label'):

        if mode == 'representation':
            return self.ext(x)
        if mode == 'label':
            return self.classifier(x)
        if mode == 'ssl_label':
            return self.self_learner(x)


