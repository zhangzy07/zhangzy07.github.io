# /usr/bin/env python
# -*- coding: utf-8 -*-

import torch

from model.linear import Linear, Logistic

def get_cls_model(cfgs, info, device):
    init = None

    print('Init: {}'.format(init is not None))

    model_name = cfgs['Estimator'].get('type', 'Linear')
    print('Classification model: {}'.format(model_name))

    if model_name == 'Linear':
        model = Linear(
            input_dim=info['dim'],
            output_dim=info['cls_num'],
            R=cfgs['Online']['kwargs']['R'] / 2
        )
    elif model_name == 'ResNet':
        model = ResNet()

    else:
        raise NotImplementedError

    if init is not None:
        model.load_state_dict(init)

    return model.to(device), init


def get_est_model(cfgs, info, device):
    init = None

    print('Init: {}'.format(init is not None))

    model_name = cfgs['Estimator'].get('type', 'Linear')
    print('Estimator model: {}'.format(model_name))

    if model_name == 'Linear':
        model = Logistic(
            input_dim=info['dim'],
            output_dim=info['cls_num'],
            R=cfgs['Online']['kwargs']['R'] / 2
        )
    else:
        raise NotImplementedError

    if init is not None:
        model.load_state_dict(init)

    return model.to(device), init
