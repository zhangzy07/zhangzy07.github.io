from abc import ABC, abstractmethod
import numpy as np


class LossFunction(ABC):

    def __init__(self, x, y):
        self._x = x
        self._y = y

    @abstractmethod
    def func(self, x):
        pass


class SquareLoss(LossFunction):

    def __init__(self, x, y, scale=1):
        super().__init__(x, y)
        self._scale = scale
        #self.data_size = x.shape[0]

    def func(self, w):
        #loss = 0.
        #for i in range(self.data_size):
        #    loss += self._scale * 1 / 2 * ((np.dot(w, self._x[i]) - self._y[i])**2)
        #return loss
        return self._scale * 1 / 2 * ((np.dot(w, self._x) - self._y)**2)


class LogisticLoss(LossFunction):

    def __init__(self, x, y):
        self._x = x
        self._y = y
        #self.data_size = len(y)

    def func(self, z):
        #loss = 0.
        if type(z) is not np.float64:
            loss = np.log(1 + np.exp(-self._y * np.dot(z, self._x)))
            #for i in range(self.data_size):
            #    loss += np.log(1 + np.exp(-self._y[i] * np.dot(z, self._x[i, :])))
        else:
            loss = np.log(1 + np.exp(-self._y * z))
            #for i in range(self.data_size):
            #    loss += np.log(1 + np.exp(-self._y[i] * z))
        return loss

    def sigmoid(self, x):
        return 1/(1 + np.e ** (-x))