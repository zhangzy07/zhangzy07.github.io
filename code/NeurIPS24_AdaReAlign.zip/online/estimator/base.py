# /usr/bin/env python
# -*- coding: utf-8 -*-
import copy

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from utils.misc import *
from utils.rotation import rotate_batch
from utils.discrepancy import *
from online.offline import *
from utils.contrastive import SupConLoss

from utils.test_helpers import *
from utils.prepare_dataset import *
from utils.rotation import rotate_batch

from utils.augmentation import aug, marginal_entropy

from model.TTAModel import TTA_ResNet

@torch.jit.script
def softmax_entropy(x: torch.Tensor) -> torch.Tensor:
    """Entropy of softmax distribution from logits."""
    return -(x.softmax(1) * x.log_softmax(1)).sum(1)

class TTT(object):
    def __init__(self, cfgs):
        super(TTT, self).__init__()
        self.class_num = cfgs['Data']['kwargs']['class_num']
        self.N_t = cfgs['Data']['kwargs']['per_round_num']
        self.N_t_test = cfgs['Data']['kwargs']['per_round_num_for_test']
        self.device = cfgs['device']
        self.cfgs = cfgs
        self.lr = cfgs['Model']['Classifier']['eta_base']
        self.aug_batch_size = cfgs['Data']['kwargs']['aug_batch_size']
        self.momentum = 0.9
        self.weight_decay = 5e-4
        self.divergence = cfgs['Align']['divergence']

        self.model = TTA_ResNet(self.class_num)
        self.ori_model = TTA_ResNet(self.class_num)
        self.criterion = nn.CrossEntropyLoss().cuda()
        self.criterion_aug = marginal_entropy

    def set_model(self, model):
        self.model = copy.deepcopy(model)
        self.ori_model = copy.deepcopy(model)

    def reset_model(self):
        self.model.load_state_dict(self.ori_model.state_dict())

    def set_ext_feature(self, src_ext_feature):
        cov_src_ext, scale_coral_ext, mu_src_ext, scale_mmd_ext = src_ext_feature
        self.cov_src_ext = cov_src_ext
        self.scale_coral_ext = scale_coral_ext
        self.mu_src_ext = mu_src_ext
        self.scale_mmd_ext = scale_mmd_ext

    def opt(self, dataloader, dataset):
        loss_ = 0.


        parameters = list(self.model.ext.parameters())
        optimizer = optim.SGD(parameters, lr=self.lr)

        for idx in range(self.N_t_test):
            data, img, labels, _ = dataset.get_data(idx)
            optimizer.zero_grad()

            margin = 0.4
            data = torch.stack([data]).cuda()
            logits = self.model.classifier(data.cuda().float())
            entropys = softmax_entropy(logits)
            filter_ids_1 = torch.where(entropys < margin)
            entropys = entropys[filter_ids_1]
            loss = entropys.mean(0)

            data = [dataset.get_data(idx)[0] for idx in range(self.N_t_test)]
            feat_ext = self.model.ext(data.cuda().float())
            cov_ext = covariance(feat_ext)
            bias = cov_ext.max().item()
            template_ext_cov = torch.eye(cov_ext.size(0)).cuda() * bias
            mu_ext = feat_ext.mean(dim=0)
            ext_src_mu = torch.stack([self.mu_src_ext])
            ext_src_cov = torch.stack([self.cov_src_ext])
            source_component_distribution = torch.distributions.MultivariateNormal(ext_src_mu, ext_src_cov)
            target_compoent_distribution = torch.distributions.MultivariateNormal(ext_src_mu, ext_src_cov)
            target_compoent_distribution.loc = mu_ext
            target_compoent_distribution.covariance_matrix = cov_ext
            target_compoent_distribution._unbroadcasted_scale_tril = torch.cholesky(
                cov_ext + template_ext_cov)
            loss += (torch.distributions.kl_divergence(source_component_distribution, target_compoent_distribution) \
                   + torch.distributions.kl_divergence(target_compoent_distribution,
                                                       source_component_distribution)).mean(dim=0) * 0.005

            loss.backward()
            max_norm = 1.
            nn.utils.clip_grad_norm_(self.model.ext.parameters(), max_norm)
            optimizer.step()

            loss_ += loss.item()

        return loss_