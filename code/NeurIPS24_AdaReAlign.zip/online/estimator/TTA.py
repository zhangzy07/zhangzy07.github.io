# /usr/bin/env python
# -*- coding: utf-8 -*-
import copy

import torch
import torch.nn as nn
import numpy as np

from online.estimator.meta import Hedge
from online.estimator.base import TTT
from online.estimator.schedule import Schedule
from utils.augmentation import aug, marginal_entropy


class TTA(object):
    def __init__(self, cfgs, src_model, src_ext_feature, **alg_kwargs):
        super(TTA, self).__init__()
        self.cfgs = cfgs
        self.T = cfgs['Data']['kwargs']['round']
        self.duration = cfgs['Data']['kwargs']['duration']
        self.base_niter = cfgs['Model']['Classifier']['base_niter']
        self.ignore_num = cfgs['Model']['Classifier']['ignore_num']
        self.N = int(np.ceil(np.log2(self.T*self.duration)))
        self.src_model = copy.deepcopy(src_model)
        self.src_ext_feature = copy.deepcopy(src_ext_feature)

        self._t = 0
        self.eta_meta = cfgs['Model']['Classifier']['eta_meta']
        self._meta = self.meta_setup()
        self._meta_loss_vector = torch.zeros(self.N-self.ignore_num)
        self._schedule = self.expert_setup()

    def expert_setup(self):
        return Schedule(TTT, self.base_niter, self.cfgs, self.src_model, self.src_ext_feature, self.N, self.ignore_num)

    def meta_setup(self):
        return Hedge(N=self.N, ignore_num=self.ignore_num, lr=self.eta_meta * torch.ones(self.N-self.ignore_num))

    def evaluation(self, dataloader):
        criterion = nn.CrossEntropyLoss(reduction='none').cuda()
        correct = []
        losses = []

        with torch.no_grad():
            for batch_idx, (inputs, labels, _) in enumerate(dataloader):
                inputs, labels = inputs.cuda(), labels.cuda()
                soft_pred = torch.zeros(len(labels), self.cfgs['Data']['kwargs']['class_num']).cuda()
                for i in range(self._schedule.length-self._schedule.ignore_num):
                    soft_pred += self._meta.prob[i].cuda() * self._schedule.bases[i].model.classifier(inputs)
                loss = criterion(soft_pred, labels)
                losses.append(loss.cpu())
                _, predicted = soft_pred.max(1)
                correct.append(predicted.eq(labels).cpu())
        correct = torch.cat(correct).numpy()
        losses = torch.cat(losses).numpy()

        return 1-correct.mean(), losses.mean()

    def eval_test(self, dataloader, model):
        criterion = nn.CrossEntropyLoss(reduction='none').cuda()
        correct = []
        losses = []

        with torch.no_grad():
            for batch_idx, (inputs, labels, _) in enumerate(dataloader):
                inputs, labels = inputs.cuda(), labels.cuda()
                soft_pred = model.model.classifier(inputs)
                loss = criterion(soft_pred, labels)
                losses.append(loss.cpu())
                _, predicted = soft_pred.max(1)
                correct.append(predicted.eq(labels).cpu())
        correct = torch.cat(correct).numpy()
        losses = torch.cat(losses).numpy()

        return 1 - correct.mean(), losses.mean()

    def forward(self, new_batch_loader, new_batch_data):
        self._t += 1

        self.loss_vector = self._schedule.opt(new_batch_loader, new_batch_data)
        print("loss", self._t, self.loss_vector)
        self._meta.opt(self.loss_vector)
        print("meta_prob", self._t, self._meta.get_prob())