# /usr/bin/env python
# -*- coding: utf-8 -*-
import copy

import numpy as np
import torch
import torch.nn as nn

import torch.distributed as dist
import torch.multiprocessing as mp

from utils.multi_thread import MultiThreadHelper

from online.utils.loss_function import SquareLoss, LogisticLoss

np.set_printoptions(suppress=True)


class Schedule(object):
    def __init__(self, base, base_niter, cfgs, src_model, src_ext_feature, N, ignore_num):
        self.length = N
        self.ignore_num = ignore_num
        self.base_niter = base_niter
        self.bases = []
        self.src_model = copy.deepcopy(src_model)
        self.src_ext_feature = copy.deepcopy(src_ext_feature)
        for i in range(self.length-self.ignore_num):
            self.bases.append(base(cfgs))
            self.bases[i].set_model(self.src_model)
            self.bases[i].set_ext_feature(self.src_ext_feature)

        self._t = 0
        self.threads = 0

    def __len__(self):
        return self.length

    def check_model_update(self, model1, model2):
        # Compare the parameters of the two models
        for param1, param2 in zip(model1.state_dict().values(),
                                  model2.state_dict().values()):
            if not torch.equal(param1, param2):
                print("The two models have different parameters")
                break
        else:
            print("The two models have the same parameters")

    def opt(self, dataloader, dataset):
        self._t += 1
        loss_vector = torch.zeros(self.length-self.ignore_num)

        def expert_opt(idx, expert):
            if self._t % (2 ** (idx+self.ignore_num)) == 0:
                print("restart model idx:", idx)
                expert.reset_model()
            loss = 0.
            for i in range(self.base_niter):
                loss = expert.opt(dataloader, dataset)
            return idx, loss

        commands = [(expert_opt, idx, expert) for idx, expert in enumerate(self.bases)]
        loss_result = MultiThreadHelper(commands, self.threads, multi_process=False)()

        for idx, loss in loss_result:
            if loss is not None:
                loss_vector[idx] = loss

        return loss_vector