# /usr/bin/env python
# -*- coding: utf-8 -*-

import torch


class Hedge(object):
    def __init__(self, N, ignore_num, lr, prior='uniform'):
        self._N = N
        self.ignore_num = ignore_num
        self.lr = lr
        self.potential = torch.zeros(self._N-self.ignore_num)
        self.prob = self.set_prior(prior)
        self._t = 0

    def set_prior(self, prior):
        if prior == 'uniform':
            prob = [1 / (self._N-self.ignore_num) for i in range(self._N-self.ignore_num)]
        elif prior == 'nonuniform':
            prob = [((self._N-self.ignore_num) + 1) / ((self._N-self.ignore_num) * i * (i + 1)) for i in range(1, (self._N-self.ignore_num) + 1)]
        else:
            prob = prior

        return torch.tensor(prob)

    @torch.no_grad()
    def opt(self, loss):
        self._t += 1

        # restart
        for idx in range(self._N-self.ignore_num):
            if self._t % (2 ** (idx+self.ignore_num))==0:
                self.potential[idx] = 0
            else:
                self.potential[idx] += torch.dot(self.prob, loss) - loss[idx]

        ori_prob = self.prob.detach().clone()
        self.prob = torch.exp(self.lr * self.potential)
        self.prob /= self.prob.sum()

        if torch.any(torch.isnan(self.prob)):
            self.prob = ori_prob

    def get_prob(self):
        return self.prob

    def get_potential(self):
        return self.potential

    def update_lr(self, **kwargs):
        lr = self.lr
        #if isinstance(lr, SelfTuningLr) or \
        #        isinstance(lr, OptSelfTuningLr):
        #    lr = lr.compute_lr(**kwargs)

        self.lr = lr
