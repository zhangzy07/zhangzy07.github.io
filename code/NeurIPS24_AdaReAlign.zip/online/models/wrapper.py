# /usr/bin/env python
# -*- coding: utf-8 -*-

from online.models.iwerm import *
from online.utils.risk import weighted_loss

def get_online_alg(cfgs, model, train_set, device, init, rng, info):

    alg_kwargs = {
        'model': model,
        'dataset': train_set,
        'device': device,
        'batch_size': cfgs['kwargs']['source_batch_size'],
        'init': init,
    }
    if cfgs['algorithm'] == 'OGD':
        alg_kwargs.update({
            'stepsize': cfgs['kwargs']['lr'],
            'projection': cfgs['kwargs']['projection'],
            'dim': info['dim']
        })
        online_alg = CustomOGD(cfgs=cfgs['kwargs'], **alg_kwargs)
    elif cfgs['algorithm'] == 'FIX':
        online_alg = Base(**alg_kwargs)
    else:
        raise NotImplementedError

    return online_alg
