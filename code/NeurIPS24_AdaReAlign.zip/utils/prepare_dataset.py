import torch
import torch.utils.data
import torchvision
import torchvision.transforms as transforms

import numpy as np

NORM = ((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
te_transforms = transforms.Compose([transforms.ToTensor(),
									transforms.Normalize(*NORM)])
tr_transforms = transforms.Compose([transforms.RandomCrop(32, padding=4),
									transforms.RandomHorizontalFlip(),
									transforms.ToTensor(),
									transforms.Normalize(*NORM)])
mnist_transforms = transforms.Compose([transforms.Resize((32, 32)),
										transforms.ToTensor(),
										transforms.Normalize((0.1307,), (0.3081,))])

common_corruptions = ['gaussian_noise', 'shot_noise', 'impulse_noise', 'defocus_blur', 'glass_blur',
					'motion_blur', 'zoom_blur', 'snow', 'frost', 'fog',
					'brightness', 'contrast', 'elastic_transform', 'pixelate', 'jpeg_compression']

def prepare_test_data(cfgs):
	if cfgs['Data']['name'] == 'cifar10':
		tesize = 10000 #cfgs['Data']['num_sample']
		if cfgs['Data']['corruption'] == 'original':
			print('Test on the original test set')
			teset = torchvision.datasets.CIFAR10(root=cfgs['Data']['path'],
												train=False, download=True, transform=te_transforms)
		elif cfgs['Data']['corruption'] in common_corruptions:
			print('Test on %s level %d' %(cfgs['Data']['corruption'], cfgs['Data']['level']))
			teset_raw = np.load(cfgs['Data']['path'] + '/CIFAR-10-C/%s.npy' %(cfgs['Data']['corruption']))
			teset_raw = teset_raw[(cfgs['Data']['level'] - 1) * tesize: cfgs['Data']['level'] * tesize]
			teset = torchvision.datasets.CIFAR10(root=cfgs['Data']['path'],
												train=False, download=True, transform=te_transforms)
			teset.data = teset_raw
			idx = np.random.choice(tesize, cfgs['Data']['num_sample'])
			teset = torch.utils.data.Subset(teset, idx)

		elif cfgs['Data']['corruption'] == 'cifar_new':
			from dataset.cifar_new import CIFAR_New
			print('Test on CIFAR-10.1')
			teset = CIFAR_New(root=cfgs['Data']['path'] + 'CIFAR-10.1/datasets/', transform=te_transforms)
			permute = False
		else:
			raise Exception('Corruption not found!')
	else:
		raise Exception('Dataset not found!')

	if not hasattr(cfgs, 'workers'):
		cfgs['workers'] = 1
	teloader = torch.utils.data.DataLoader(teset, batch_size=cfgs['Data']['batch_size'],
											shuffle=False, num_workers=cfgs['workers'])
	return teset, teloader

def prepare_train_data(args):
	print('Preparing data...')
	if args.dataset == 'cifar10':
		trset = torchvision.datasets.CIFAR10(root=args.dataroot,
										train=True, download=True, transform=tr_transforms)
	else:
		raise Exception('Dataset not found!')

	if not hasattr(args, 'workers'):
		args.workers = 1
	trloader = torch.utils.data.DataLoader(trset, batch_size=args.batch_size,
											shuffle=True, num_workers=args.workers)
	return trset, trloader
	