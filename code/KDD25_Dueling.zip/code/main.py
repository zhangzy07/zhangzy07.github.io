from utils import *
import argparse

def main():
    parser = argparse.ArgumentParser(description="Para of experiments")
    parser.add_argument('-t','--type', default='synthetic',type=str,required=False,help="Select experimental types")
    parser.add_argument('-r','--repeat', default='100',type=int,required=False,help="Number of repeated trials")
    parser.add_argument('-re', '--retrain', default=False,type=bool,required=False,help="Plot with exist results without training if true, retrain otherwise.")

    args = parser.parse_args()
    if args.type not in ['real','synthetic']:
        raise ValueError('Experimental types must be selected within real or synthetic.')
    type = args.type
    repeat = args.repeat
    new_trial = args.retrain
    path = "./datasets/"
    data_names = [['arxiv',
                   'sushiA',
                   'sushiB50',
                   'sushiB'
                   ], [5, 10, 20, 50, 100, 200]]
    if type == "real":
        data_index = 0
    else:
        data_index = 1
    for data_name in data_names[data_index]:
        data_path = path + type + "/pref_" + str(data_name) + ".npy"
        pref_mat, N, Delta, best_arm = load_inst(data_path)
        horizon = 50000 * N
        checkpoint = cal_log_checkpoint(horizon)
        result_rootpath = "./result/" + str(type) + "/"
        os.makedirs(result_rootpath, exist_ok=True)
        result_path = result_rootpath + str(data_name) + "_result.npy"
        print('---------------')
        print('Dataset:', data_name, ', N=', N, ', Delta=', np.around(Delta, 4))
        conduct_weak(pref_mat, best_arm, horizon, repeat, result_path, new_trial, Delta, checkpoint)

if __name__ == '__main__':
    main()
