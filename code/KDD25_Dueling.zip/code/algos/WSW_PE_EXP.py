import numpy as np
import random
from math import log,sqrt,exp

class WSW_PE_EXP():
    def __init__(self,N,comparison_function,regret_fn,delta,checking_point):
        self.delta = delta
        self.N = N
        self.It, self.Jt = None, None
        self.bandit = comparison_function
        self.t = 1
        self.regret = 0
        self.regrets = []
        self.regret_fn = regret_fn
        self.winner = None
        self.loser = None
        self.best_arm = None
        self.I = None
        self.J = None
        self.round_winner = None
        self.round_loser = None
        self.qualified = np.ones(N)  # activated or not
        self.elimination = np.ones(N)  # uneliminated set, 0 for elimination
        self.wins = np.zeros((N, N))
        self.checking_point = checking_point
        self.checking_regret = []
        self.C=np.zeros(N)
        self.cum_loss = np.zeros(N)
        self.non_champ_count = 0


    def pull(self, I, J):
        if self.I !=0 and self.J!=0:
            self.non_champ_count+=1
        res = self.bandit(I,J)
        self.regret += self.regret_fn(I,J)
        self.regrets.append(float(self.regret))
        if res == 1:
            self.winner, self.loser = I, J
        else:
            self.winner, self.loser = J, I
        self.C[self.winner]+=1
        self.C[self.loser]-=1
        self.t+=1
        if self.t in self.checking_point:
            self.checking_regret.append(np.array(self.regrets[-1]))
        self.wins[self.winner][self.loser] += 1
        return

    def compare(self):
        stop=0
        threshold=self.C[self.round_winner]+1
        n = self.wins[self.I][self.J] + self.wins[self.J][self.I]
        while self.C[self.I] < threshold and self.C[self.J] < threshold and stop==0:
            self.pull(self.I, self.J)
            n+=1
            mu = self.wins[self.I][self.J] / n
            c = sqrt(log(10 * self.N * n ** 2 / self.delta) / (2 * n))
            if mu-c>0.5 or mu+c<0.5:
                stop=1
                if mu+c<0.5:
                    self.round_winner, self.round_loser = self.J,self.I
                if mu-c>0.5:
                    self.round_winner, self.round_loser = self.I, self.J
                self.elimination[self.round_loser] = 0
        if self.C[self.I] == threshold and stop==0:
            self.round_winner = self.I
            self.round_loser = self.J
        elif self.C[self.J] == threshold and stop==0:
            self.round_winner = self.J
            self.round_loser = self.I

        self.cum_loss[self.round_winner]-=0.01
        self.cum_loss[self.round_loser]+=0.01
        return


    # def selectJ(self):
    #     qualified_index=list(np.where(self.qualified == 1)[0])
    #     qualified_index.remove(self.I)
    #     self.J=np.random.choice(qualified_index) #random
    def selectJ(self):
        qualified_index = list(np.where(self.qualified == 1)[0])
        qualified_index.remove(self.I)
        probs = []
        for optional in qualified_index:
            probs.append(exp(-self.cum_loss[optional]))  # EXP
        probs = list(np.array(probs) / sum(probs))
        self.J = qualified_index[np.random.choice(len(probs), 1, p=probs)[0]]
        return

    def algo(self):
        if self.t == 1:
            self.round_winner=1
            self.I = np.random.randint(0, self.N,1)[0]
            self.J = np.random.randint(0, self.N,1)[0]
            while self.I==self.J:
                self.J = np.random.randint(0, self.N, 1)[0]
        while sum(self.elimination) > 1:
            self.selectJ()
            self.compare()
            self.qualified[self.round_loser] = 0
            if sum(self.qualified)==1:
                self.qualified[np.where(self.elimination==1)]=1
            self.I = self.round_winner
        self.best_arm = np.where(self.elimination == 1)[0][0]
        while len(self.checking_regret)<len(self.checking_point):
            self.checking_regret.append(self.checking_regret[-1])
        return self.best_arm, self.t,self.checking_regret,self.non_champ_count




