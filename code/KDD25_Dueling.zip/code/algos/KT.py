import numpy as np

from math import log, sqrt


class KT():

    def __init__(self, K, comparison_function,regret_fn,epsilon,delta,checking_point):
        self.K = K
        self.bandit = comparison_function
        self.t = 0
        self.winner=None
        self.loser=None
        self.epsilon=epsilon
        self.delta=delta
        self.regret = 0
        self.regrets = []
        self.regret_fn = regret_fn
        self.checking_point = checking_point
        self.checking_regret = []

    def compare(self,It,Jt,epsilon,delta):
        p,c,r,w=0.5,0.5,0,0
        m=1/(2*(epsilon**2))*log(2/delta)
        while (abs(p-0.5)<=c-epsilon and r<=m):
            self.pull(It,Jt)
            self.t+=1
            if self.t in self.checking_point:
                self.checking_regret.append(np.array(self.regrets[-1]))
            if self.winner==It:
                w+=1
            r+=1
            p=w/r
            c=sqrt(1/(2*r)*log(4*r**2/delta))
        if p<=0.5:
            return Jt
        else:
            return It


    def pull(self, It, Jt):
        res = self.bandit(It,Jt)
        self.regret += self.regret_fn(It, Jt)
        self.regrets.append(float(self.regret))
        if res == 1:
            self.winner, self.loser = It, Jt
        else:
            self.winner, self.loser = Jt, It

    def knockout_round(self,S,epsilon,delta):
        O_li=[]
        np.random.shuffle(S)
        pair_li=[]
        if len(S) % 2 == 0:
            for i in range(int(len(S)/2)):
                pair_li.append([S[2*i],S[2*i+1]])
        else:
            for i in range(int((len(S)-1)/2)):
                pair_li.append([S[2*i],S[2*i+1]])
            pair_li.append([S[0],S[-1]])
        for pair in pair_li:
            It,Jt=pair[0],pair[1]
            O_li.append(self.compare(It,Jt,epsilon,delta))
        new_li=self.unq(O_li)
        return new_li

    def unq(self,o_li):
        newlist = []
        for x in o_li:
            if x not in newlist:
                newlist.append(x)
        return newlist

    def knockout(self):
        epsilon, delta=self.epsilon,self.delta
        i=1
        S=np.array(range(self.K))
        c=2**(1/3)-1
        while len(S) > 1:
            S=self.knockout_round(S,c*epsilon/(2**(i/3)),delta/(2**i))
            i+=1
        while len(self.checking_regret)<len(self.checking_point):
            self.checking_regret.append(self.checking_regret[-1])
        return S[0],self.t,self.checking_regret
