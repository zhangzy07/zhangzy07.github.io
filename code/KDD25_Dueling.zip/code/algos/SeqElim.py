import numpy as np

from math import log, sqrt


class SeqElim():

    def __init__(self, K, comparison_function,regret_fn,epsilon,delta,checking_point):
        self.K = K
        self.bandit = comparison_function
        self.t = 0
        self.winner=None
        self.loser=None
        self.delta=delta
        self.epsilon=epsilon
        self.A=list(range(K))
        self.regret = 0
        self.regrets = []
        self.regret_fn = regret_fn
        self.checking_point = checking_point
        self.checking_regret = []


    def main(self):
        rdint=np.random.randint(0,len(self.A)-1)
        i=self.A.pop(rdint)
        while len(self.A) !=0:
            if len(self.A)==1:
                rdint_j=0
            else:
                rdint_j = np.random.randint(0, len(self.A) - 1)
            j = self.A.pop(rdint_j)
            result=self.compare(j,i,0,self.epsilon,self.delta/self.K)
            if result==2:
                i=j
        while len(self.checking_regret)<len(self.checking_point):
            self.checking_regret.append(self.checking_regret[-1])
        return i,self.t,self.checking_regret

    def compare(self,Jt,It,epsilon_l,epsilon_u,delta):
        epsilon_m=(epsilon_l+epsilon_u)/2
        p,c,w,n=0,0.5,0,0
        while (abs(p-epsilon_m)<=c and n<=2/(epsilon_u-epsilon_l)**2*log(2/delta)):
            self.pull(Jt,It)
            if self.winner==Jt:
                w+=1
            self.t+=1
            if self.t in self.checking_point:
                self.checking_regret.append(np.array(self.regrets[-1]))
            n+=1
            p=w/n-0.5
            c=sqrt(1/(2*n)*log(4*n**2/delta))
        if p<=epsilon_m:
            return 1
        else:
            return 2
    def pull(self, It, Jt):
        res = self.bandit(It,Jt)
        self.regret += self.regret_fn(It, Jt)
        self.regrets.append(float(self.regret))
        if res == 1:
            self.winner, self.loser = It, Jt
        else:
            self.winner, self.loser = Jt, It
        return
