import numpy as np

from math import log, sqrt


class MallowsMPI():

    def __init__(self, K,T, comparison_function,regret_fn,delta,checking_point):
        self.T = T
        self.K = K
        self.bandit = comparison_function
        self.t = 0
        self.winner=None
        self.loser=None
        self.delta=delta
        self.A=list(range(K))
        self.n=np.zeros((K,K))
        self.W=np.zeros((K,K))
        self.regret = 0
        self.regrets = []
        self.regret_fn = regret_fn
        self.checking_point = checking_point
        self.checking_regret = []

    def main(self):
        rdint=np.random.randint(0,len(self.A)-1)
        i=self.A.pop(rdint)
        while len(self.A) !=0:
            if len(self.A)==1:
                rdint_j=0
            else:
                rdint_j = np.random.randint(0, len(self.A) - 1)
            j = self.A.pop(rdint_j)
            stop_crit=0
            while stop_crit==0:
                self.pull(i,j)
                self.t+=1
                if self.t in self.checking_point:
                    self.checking_regret.append(np.array(self.regrets[-1]))
                self.n[i][j]+=1
                if self.winner==i:
                    self.W[i][j]+=1
                else:
                    self.W[j][i]+=1
                p=self.W[i][j]/self.n[i][j]
                c=sqrt(1/(2*self.n[i][j])*log(4*self.K*self.n[i][j]**2/self.delta))
                if p-c>0.5 or p+c<0.5 or self.t>self.T:
                    stop_crit=1
            if p+c<0.5:
                i=j
        while len(self.checking_regret)<len(self.checking_point):
            self.checking_regret.append(self.checking_regret[-1])
        return i,self.t, self.checking_regret


    def pull(self, It, Jt):
        res = self.bandit(It,Jt)
        self.regret += self.regret_fn(It, Jt)
        self.regrets.append(float(self.regret))
        if res == 1:
            self.winner, self.loser = It, Jt
        else:
            self.winner, self.loser = Jt, It
        return
