import numpy as np
from matplotlib import pyplot as plt
from algos.WSW_PE_EXP import WSW_PE_EXP
from algos.WSW_PE import WSW_PE
from algos.BTW_PE import BTW_PE
from algos.KT import KT
from algos.MallowsMPI import MallowsMPI
from algos.SeqElim import SeqElim
from math import sqrt,log
import os


def conduct_weak(pref_mat, best_arm,horizon, samples,result_path,new_trial,Delta, checkpoint):
    if os.path.exists(result_path) and new_trial==False:
        print ('Result exists, skip to plot.')
        plot_weak(result_path, checkpoint)
        plot_sc(result_path)
    else:
        d = main_weak(pref_mat, best_arm, horizon, samples,result_path,Delta, checkpoint)
        print("Dumped all, plotting.")
        plot_weak(result_path, checkpoint)
        plot_sc(result_path)






def main_weak(pref_mat, best_arm, horizon, samples,result_path,Delta, checkpoint):
    def generator_fnc(i, j):
        return np.random.binomial(n=1, p=pref_mat[int(i)][int(j)], size=1)

    def regret_fn_weak(i, j):
        return min(pref_mat[best_arm][i] - 0.5, pref_mat[best_arm][j] - 0.5)

    d = {
        "WSW_PE_regrets": [],
        'BTW_PE_regrets': [],
        "WSW_PE_EXP_regrets": [],
        "KTETC_regrets":[],
        "MallowsMPIETC_regrets": [],
        "SeqElimETC_regrets": [],
        "WSW_PE_sc": [],
        "BTW_PE_sc": [],
        "WSW_PE_EXP_sc": [],
        "KT_sc": [],
        "MallowsMPI_sc": [],
        "SeqElim_sc": [],
    }

    N = len(pref_mat)
    for i in range(samples):
        print("Repeat", i + 1)

        x = WSW_PE(N, generator_fnc, regret_fn_weak, delta=0.05, checking_point=checkpoint)
        reg_WSW_PE = np.array(x.algo(),dtype=object)
        # print("WSW_PE done, best arm : ", reg_WSW_PE[0],  '|Regret',
        #       np.around(reg_WSW_PE[2][-1], 3), "|Sample complexity", reg_WSW_PE[1])
        d["WSW_PE_regrets"].append(list(np.around(reg_WSW_PE[2], 3)))
        d["WSW_PE_sc"].append(int(reg_WSW_PE[1]))

        x = BTW_PE(N, generator_fnc, regret_fn_weak, delta=0.05, checking_point=checkpoint)
        reg_BTW_PE = np.array(x.algo(),dtype=object)
        # print("BTW_PE done, best arm : ", reg_BTW_PE[0],  '|Regret',
        #       np.around(reg_BTW_PE[2][-1], 3), "Sample complexity", reg_BTW_PE[1])
        d["BTW_PE_regrets"].append(list(np.around(reg_BTW_PE[2], 3)))
        d["BTW_PE_sc"].append(int(reg_BTW_PE[1]))

        x = WSW_PE_EXP(N, generator_fnc, regret_fn_weak, delta=0.05, checking_point=checkpoint)
        reg_WSW_PE_EXP = np.array(x.algo(),dtype=object)
        # print("WSW_PE_EXP done, best arm : ", reg_WSW_PE_EXP[0],  '|Regret',
        #       np.around(reg_WSW_PE_EXP[2][-1], 3), "|Sample complexity", reg_WSW_PE_EXP[1])
        d["WSW_PE_EXP_regrets"].append(list(np.around(reg_WSW_PE_EXP[2], 3)))
        d["WSW_PE_EXP_sc"].append(int(reg_WSW_PE_EXP[1]))

        x = KT(N, generator_fnc, regret_fn_weak, epsilon=Delta, delta=0.05,checking_point=checkpoint)
        rst_KT = np.array(x.knockout(),dtype=object)
        # print("KT done,best arm:",rst_KT[0],'|Reegret',
        #       np.around(rst_KT[2][-1], 3), "|Sample complexity", rst_KT[1])
        d["KTETC_regrets"].append(list(np.around(rst_KT[2], 3)))
        d["KT_sc"].append(int(rst_KT[1]))

        x = MallowsMPI(N,horizon, generator_fnc, regret_fn_weak, delta=0.05, checking_point=checkpoint)
        rst_MallowsMPI = np.array(x.main(),dtype=object)
        # print("MallowsMPI done,best arm:",rst_MallowsMPI[0],'|Regret',
        #       np.around(rst_MallowsMPI[2][-1], 3), "|Sample complexity", rst_MallowsMPI[1])
        d["MallowsMPIETC_regrets"].append(list(np.around(rst_MallowsMPI[2], 3)))
        d["MallowsMPI_sc"].append(int(rst_MallowsMPI[1]))

        x = SeqElim(N, generator_fnc,regret_fn_weak, epsilon=Delta, delta=0.05,checking_point=checkpoint)
        rst_SeqElim = np.array(x.main(),dtype=object)
        # print("SeqElim done,best arm:",rst_SeqElim[0],'|Regret',
        #       np.around(rst_SeqElim[2][-1], 3), "|Sample complexity", rst_SeqElim[1])
        d["SeqElimETC_regrets"].append(list(np.around(rst_SeqElim[2], 3)))
        d["SeqElim_sc"].append(int(rst_SeqElim[1]))

    np.save(result_path, d)
    return d


def plot_weak(result_path, checkpoint):
    names = [
        "WSW_PE_regrets",
        "BTW_PE_regrets",
        "WSW_PE_EXP_regrets",
        "KTETC_regrets",
        "MallowsMPIETC_regrets",
        "SeqElimETC_regrets",
    ]
    colors = ['b', 'g', 'r', 'c', 'm', 'y', 'k', (0.75, 0.5, 0.5)]
    labels = ["WSW-PE", "BTW-PE", "WSW-PE-EXP",'KNOCKOUT-ETC','Mallows-MPI-ETC','Seq-Elim-ETC']
    markers = ['x', 'o', 'v','o','o','o']
    data_type = str(result_path.split('/')[2])
    if data_type == 'real':
        data_name = str(result_path.split('/')[-1].split('_')[0])
    else:
        data_name = "N=" + str(result_path.split('/')[-1].split('_')[0])
    d = np.load(result_path, allow_pickle=True).item()
    for k in range(len(names)):
        key = names[k]
        val = np.array(d[key])
        avg = val.mean(axis=0)
        plt.plot(checkpoint, avg, label=labels[k], color=colors[k], marker=markers[k])
    plt.xscale('log')
    plt.yscale('log')
    plt.xlabel('time steps')
    plt.ylabel('expected regret')
    plt.legend()
    plt.title("Average Regret on "+data_name)
    plt.show()

def plot_sc(result_path):
    names = [
        'WSW_PE_sc',
        'BTW_PE_sc',
        'WSW_PE_EXP_sc',
        "SeqElim_sc",
        "KT_sc",
        "MallowsMPI_sc"
    ]
    x = np.arange(1)
    width = 0.1
    label_set = ['WSW-PE','BTW-PE',"WSW-PE-EXP", "SeqElim", "Knockout", "MallowsMPI"]
    color_set = ['r', '#51C1C8', '#DBC60B', 'gray','b','green']
    fig, ax = plt.subplots()
    for k in range(len(names)):
        name = names[k]
        y = []
        d = np.load(result_path, allow_pickle=True).item()
        y.append(np.array(d[name]).mean())
        y = np.array(y)
        ax.bar(x + (k + 1) * width, y, width, color=color_set[k], label=label_set[k], edgecolor='black')

    data_type = str(result_path.split('/')[2])
    if data_type == 'real':
        data_name = str(result_path.split('/')[-1].split('_')[0])
    else:
        data_name = "N=" + str(result_path.split('/')[-1].split('_')[0])
    plt.ylabel('Average Sample Complexity')
    plt.legend()
    plt.yscale('log')
    plt.ylim([1E0, 2E6])
    ax.set_xticks(x + width * (k + 2) / 2)
    ax.set_xticklabels([data_name])
    plt.title('Sample complexity result on '+data_name)
    plt.show()


def cal_log_checkpoint(horizon):
    num_point = 15
    b = int(10 * np.exp(log(horizon - 1) / (num_point - 1))) / 10
    A = int(b ** num_point) + 1
    checkpoint = list(int(A / b ** (num_point) * b ** (x)) for x in range(num_point))
    return checkpoint

def load_inst(data_path):
    pref_mat = np.load(data_path)
    N = len(pref_mat)
    Delta = min(pref_mat[0][1:]) - 0.5
    best_arm=0
    return pref_mat,N,Delta,best_arm