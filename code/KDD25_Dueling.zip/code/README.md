# Implementation of wRM-PE
This is a reproducing code for the paper "**Achieving Nearly-Optimal Regret and Sample Complexity in
Dueling Bandits with Applications in Online Recommendations**".

## Experiment Environment
* Python 3.7
* Numpy 1.16.5

## Quick start
You can run an example with **existing results** on **synthetic data** by

    python main.py

For **real-world experiments**, run

    python main.py -t=real

## Other Parameters

Retraining is available by adding **-re=bool**, the number of repeats is set by adding **-r=int**. For example, the following means retraining on synthetic data with 100 independent trials.

    python main.py -t=synthetic -re=True -r=100 

Please refer **main.py** to see full and default argparse settings for parameters.