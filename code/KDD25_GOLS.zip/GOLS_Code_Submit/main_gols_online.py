import os, sys
import datetime
import argparse

from tqdm import tqdm

import numpy as np
import pandas as pd
import torch
import torch.utils.data as torch_data

from torch.utils.tensorboard import SummaryWriter

from utils_pkg import exp_config
from utils_pkg import deploy
from utils_pkg.utils import collate_first2_args

from dataset.GOLS.wrapper import get_dataset
from models_pkg.wrapper import get_cls_model, get_rep_model
from online.algorithms.GOLS.wrapper import get_online_alg


# python main_gols_online.py --config_path demos/GOLS/fix_amazon.yaml
# python main_gols_online.py --config_path demos/GOLS/fix_iwildcam_natural.yaml
# python main_gols_online.py --config_path demos/GOLS/ogd_amazon.yaml
# python main_gols_online.py --config_path demos/GOLS/ogd_iwildcam_natural.yaml
# python main_gols_online.py --config_path demos/GOLS/gem_amazon.yaml
# python main_gols_online.py --config_path demos/GOLS/gem_iwildcam_natural.yaml
# python main_gols_online.py --config_path demos/GOLS/agem_amazon.yaml
# python main_gols_online.py --config_path demos/GOLS/agem_iwildcam_natural.yaml


# # see deploy.set_hardware_state(cfgs)
# def set_cpu_num(cpu_num=8):
#     os.environ["OMP_NUM_THREADS"] = str(cpu_num)
#     os.environ["OPENBLAS_NUM_THREADS"] = str(cpu_num)
#     os.environ["MKL_NUM_THREADS"] = str(cpu_num)
#     os.environ["VECLIB_MAXIMUM_THREADS"] = str(cpu_num)
#     os.environ["NUMEXPR_NUM_THREADS"] = str(cpu_num)
#     torch.set_num_threads(cpu_num)
#     # torch.set_num_interop_threads(cpu_num)


def customize_progress(progress_bar: tqdm):
    n = progress_bar.format_dict["n"]
    total = progress_bar.format_dict["total"]
    elapsed = progress_bar.format_dict["elapsed"]

    elapsed_per_item = elapsed / (n + 1)

    mins, s = divmod(round(elapsed), 60)
    h, m = divmod(mins, 60)
    elapsed_readable_str = f"{h:02d}:{m:02d}:{s:02d}"

    if elapsed_per_item > 1e-6:
        remaining = (total - n) * elapsed_per_item
    else:
        remaining = 0

    mins, s = divmod(round(remaining), 60)
    h, m = divmod(mins, 60)
    remaining_readable_str = f"{h:02d}:{m:02d}:{s:02d}"

    return elapsed_per_item, elapsed_readable_str, remaining_readable_str


NULL_FILE = open("/dev/null", "wt")
LAUNCH_DATETIME = datetime.datetime.now()

parser = argparse.ArgumentParser("GOLS Experiment")
parser.add_argument("--config_path", type=str, required=True)
parser.add_argument("--force_random_seed", type=str, required=False, default=None)
parser.add_argument("--force_gpu_ids", type=str, required=False, default=None)
parser.add_argument("--force_online_lr", type=str, required=False, default=None)
parser.add_argument("--force_update_rounds", type=str, required=False, default=None)
args = parser.parse_args()
cfgs = exp_config.Config(config_path=args.config_path, remark="")
if args.force_random_seed:
    assert int(args.force_random_seed) == eval(args.force_random_seed)
    cfgs.seed = int(args.force_random_seed)
if args.force_gpu_ids:
    assert str(int(args.force_gpu_ids)) == args.force_gpu_ids
    cfgs.hardware_cfgs.gpu_ids = args.force_gpu_ids
if args.force_online_lr:
    assert float(args.force_online_lr) == eval(args.force_online_lr)
    cfgs.online_cfgs.kwargs["rep_lr"] = float(args.force_online_lr)
    cfgs.online_cfgs.kwargs["cls_lr"] = float(args.force_online_lr)
if args.force_update_rounds:
    assert int(args.force_update_rounds) == eval(args.force_update_rounds)
    cfgs.online_cfgs.kwargs["update_rounds"] = int(args.force_update_rounds)

cfgs.logger(str(cfgs))

# # see deploy.set_hardware_state(cfgs)
# set_cpu_num(cpu_num=cfgs.hardware_cfgs.cpu_num)

deploy.set_random_seed(cfgs.seed)
deploy.set_hardware_state(cfgs)

train_set, test_set = get_dataset(cfgs)

cls_num = max(train_set.ys.max().item(), test_set.ys.max().item()) + 1
cfgs.offline_cfgs.kwargs["cls_num"] = cls_num
cfgs.online_cfgs.kwargs["cls_num"] = cls_num
cfgs.logger(f"cls_num={repr(cls_num)}")

data_info = {
    # "dim" used only when rep_model is None
    "dim": None,
    # "cls_num" used by Linear
    "cls_num": cls_num,
    # "init_priors" is never used
    "init_priors": None,
}

cfgs.data_cfgs.data_info = data_info

offline_rep_model, _ = get_rep_model(
    cfgs,
    sub_cfgs=cfgs.offline_cfgs,
    model_type=cfgs.offline_cfgs.type,
    info=data_info,
    device=cfgs.hardware_cfgs.device,
    rep_model_name=cfgs.offline_cfgs.rep_model_name,
    rep_model_path=cfgs.offline_cfgs.rep_model_path,
)

offline_cls_model, _ = get_cls_model(
    cfgs,
    sub_cfgs=cfgs.offline_cfgs,
    model_type=cfgs.offline_cfgs.type,
    info=data_info,
    device=cfgs.hardware_cfgs.device,
    cls_model_name=cfgs.offline_cfgs.cls_model_name,
    cls_model_path=cfgs.offline_cfgs.cls_model_path,
)

online_rep_model, rep_init = get_rep_model(
    cfgs,
    sub_cfgs=cfgs.online_cfgs,
    model_type=cfgs.online_cfgs.type,
    info=data_info,
    device=cfgs.hardware_cfgs.device,
    rep_model_name=cfgs.online_cfgs.rep_model_name,
    rep_model_path=cfgs.online_cfgs.rep_model_path,
)

online_cls_model, cls_init = get_cls_model(
    cfgs,
    sub_cfgs=cfgs.online_cfgs,
    model_type=cfgs.online_cfgs.type,
    info=data_info,
    device=cfgs.hardware_cfgs.device,
    cls_model_name=cfgs.online_cfgs.cls_model_name,
    cls_model_path=cfgs.online_cfgs.cls_model_path,
)

online_rep_model = online_rep_model.to("cpu")
online_cls_model = online_cls_model.to("cpu")

online_alg = get_online_alg(
    cfgs=cfgs,
    online_cfgs=cfgs.online_cfgs,
    min_step=None,
    max_step=None,
    models_dict={
        "offline_cls_model": offline_cls_model,
        "online_cls_model": online_cls_model,
        "cls_init": cls_init,
        "rep_init": rep_init,
        "offline_rep_model": offline_rep_model,
        "online_rep_model": online_rep_model,
    },
    train_set=train_set,
    device=cfgs.hardware_cfgs.device,
    rng=None,
    info=data_info,
)

source_loader = torch_data.DataLoader(
    test_set,
    batch_size=cfgs.online_cfgs.kwargs["evaluate_batch_size"],
    shuffle=False,
    pin_memory=False,
    num_workers=cfgs.hardware_cfgs.kwargs.get("num_workers", 8),
)

error_rates = []

with tqdm(
    enumerate(source_loader), total=len(source_loader), file=NULL_FILE
) as progress_bar:
    for t, (evaluate_x, evaluate_y, evaluate_domain_id) in progress_bar:
        evaluate_dataset = torch_data.TensorDataset(
            evaluate_x, evaluate_y, evaluate_domain_id
        )
        evaluate_dataloader = torch_data.DataLoader(
            evaluate_dataset,
            batch_size=cfgs.online_cfgs.kwargs["update_batch_size"],
            shuffle=True,
            num_workers=cfgs.hardware_cfgs.kwargs.get("num_workers", 8),
        )
        error_count = 0
        total_count = 0
        for batch_index, (x, y, domain_id) in enumerate(evaluate_dataloader):
            if batch_index == 0:
                online_alg.alg_forward(x, y, domain_id)
            y_pred = online_alg.predict(x)
            error_count += torch.sum(y_pred != y).item()
            total_count += domain_id.size(0)
        error_rate = error_count / total_count
        error_rates.append(error_rate)
        elapsed_per_item, elapsed_readable_str, remaining_readable_str = (
            customize_progress(progress_bar)
        )
        time_stamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        cfgs.logger(
            f"[{time_stamp}] [{elapsed_readable_str:>8s}<{remaining_readable_str:>8s}] [{elapsed_per_item:6.1f}s/it] "
            f"[{t:>4d}/{len(source_loader):>4d}] [{100*t/len(source_loader):6.2f}%] "
            f"err_t={error_rate*100:>6.3f}% err_avg={np.mean(error_rates)*100:>6.3f}% err_std={np.std(error_rates)*100:>6.3f}%",
            flush=True,
        )

        if t == round(len(source_loader) / 4) - 1:
            cfgs.logger(f"quarter_avg={np.mean(error_rates)}", flush=True)
            cfgs.logger(f"quarter_std={np.std(error_rates)}", flush=True)
        if t == round(len(source_loader) / 2) - 1:
            cfgs.logger(f"half_avg={np.mean(error_rates)}", flush=True)
            cfgs.logger(f"half_std={np.std(error_rates)}", flush=True)
        if t == len(source_loader) - 1:
            cfgs.logger(f"total_avg={np.mean(error_rates)}", flush=True)
            cfgs.logger(f"total_std={np.std(error_rates)}", flush=True)
