"""
https://github.com/ContinualAI/avalanche/blob/master/avalanche/training/plugins/gem.py
https://github.com/facebookresearch/GradientEpisodicMemory/blob/master/model/gem.py
"""

import typing, random

import numpy as np
import cvxpy as cp
import sklearn.metrics.pairwise as pairwise


_ever_seen_qp_shape = set()  # only print shape once


def make_sure_positive_definite(A: np.ndarray, epsilon: float = 1e-4):
    d0, d1 = A.shape
    assert d0 == d1
    return (A + A.T) / 2 + epsilon * np.eye(d0)


def solve_gem_qp(
    new_grad: np.ndarray,
    old_grad_pool: typing.Iterable[np.ndarray],
    num_sample: int = 0,
) -> np.ndarray:
    """
    solve_gem_qp
        return GEM gradient, given new_grad and old_grad_pool.
        GEM gradient is np.ndarray vector (tensor order is one)
    new_grad
        gradient of online batch,
        must be np.ndarray, must be vector (tensor order is one)
    old_grad_pool
        gradient of offline batches and previous online batches,
        list, each item is an old_grad, must be np.ndarray, must
        be vector (tensor order is one)
    num_sample
        number of old_grad to be sampled from old_grad_pool,
        must be int, ignored if num_sample <= 0 (do not sample,
        use all old_grad)
    """

    # ======== sanity check ========

    assert isinstance(num_sample, int), "num_sample is not int"

    assert isinstance(new_grad, np.ndarray), "new_grad not np.ndarray"
    assert all(
        map(lambda old_grad: isinstance(old_grad, np.ndarray), old_grad_pool)
    ), "old_grad_pool not np.ndarray"

    assert len(new_grad.shape) == 1, "new_grad not vector shape"
    assert all(
        map(lambda old_grad: len(old_grad.shape) == 1, old_grad_pool)
    ), "old_grad_pool not vector shape"

    # sample without replacement
    if num_sample > 0 and num_sample < len(old_grad_pool):
        old_grad_pool = [old_grad for old_grad in old_grad_pool]
        random.shuffle(old_grad_pool)
        old_grad_pool = old_grad_pool[0:num_sample]
    else:
        num_sample = len(old_grad_pool)

    # ======== compose QP parameters ========

    # notations similar to https://arxiv.org/abs/1706.08840 eq. (8) ~ (11)

    (p,) = new_grad.shape
    if not (p, num_sample) in _ever_seen_qp_shape:
        _ever_seen_qp_shape.add((p, num_sample))
        print(f"[solve_gem_qp] prime_dim={p}, dual_dim={num_sample}")

    g = np.transpose(np.expand_dims(new_grad, axis=0))
    G = np.transpose(np.stack(old_grad_pool, axis=0))
    GTG = G.T @ G
    gTG = g.T @ G

    if np.all(gTG >= 0):
        return new_grad

    GTG = make_sure_positive_definite(GTG, epsilon=1e-3)

    v = cp.Variable((num_sample, 1))
    qp = cp.Problem(
        cp.Minimize((1 / 2) * cp.quad_form(v, GTG, assume_PSD=True) + gTG @ v),
        [v >= 0],
    )
    qp.solve()

    g_tilde = G @ v.value + g

    gem_grad = np.squeeze(g_tilde, axis=1)
    return gem_grad


def solve_kmm_qp(
    f_src: np.ndarray,
    f_tgt: np.ndarray,
    rbf_sigma: float,
) -> np.ndarray:
    """
    solve_kmm_qp
        return importance weight of f_src
    f_src
        feature from source domain;
        np.ndarray, shape (n_src, d)
    f_tgt
        feature from target domain;
        np.ndarray, shape (n_tgt, d)
    rbf_sigma
        should be the average/median norm of f_src[i]
    """

    # ======== sanity check ========

    assert isinstance(f_src, np.ndarray), "f_src not np.ndarray"
    assert isinstance(f_tgt, np.ndarray), "f_tgt not np.ndarray"
    assert isinstance(rbf_sigma, float), "rbf_sigma not float"

    (n_src, d) = f_src.shape
    (n_tgt, d) = f_tgt.shape

    # ======== compose QP parameters ========

    # https://github.com/TongtongFANG/GIW/blob/main/kmm.py

    K = pairwise.rbf_kernel(f_src, f_src, rbf_sigma)
    K = make_sure_positive_definite(K, epsilon=1e-5)

    k = pairwise.rbf_kernel(f_src, f_tgt, rbf_sigma)
    k = k @ np.ones((n_tgt, 1))
    k = -(n_src / n_tgt) * k

    x = cp.Variable((n_src, 1))
    qp = cp.Problem(
        cp.Minimize((1 / 2) * cp.quad_form(x, K, assume_PSD=True) + k.T @ x),
        [x >= 0, x <= 1],
    )
    qp.solve()

    x = x.value.reshape((-1,))
    x = np.where(x <= 1e-5, 0, x)
    return x
