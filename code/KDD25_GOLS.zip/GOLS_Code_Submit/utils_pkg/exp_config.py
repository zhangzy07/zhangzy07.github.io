import os
import random
from datetime import datetime

import yaml

from torch.utils.tensorboard import SummaryWriter

from utils_pkg.logger import MyLogger


class CONFIG_CLASS:
    def __init__(self):
        self.kwargs = {}
        return

    def update(self, data):
        for key, value in data.items():
            if "_cfgs" in key:
                getattr(self, key).update(value)
            elif "kwargs" == key:
                setattr(self, key, value)
            else:
                if key in self.__dict__.keys():
                    setattr(self, key, value)
                else:
                    raise ValueError(
                        'Unknown config key: "{}".\nWe recommend explicit config setting (adding attr to exp_config.py)!'.format(
                            key
                        )
                    )


class Hardware_Config(CONFIG_CLASS):

    def __init__(self):
        super().__init__()
        self.device = "cpu"
        self.cuda: bool = True
        self.multi_gpus: bool = False
        self.cpu_num: int = min(4, os.cpu_count() // 2)
        self.gpu_ids: str = "0"
        self.thread_num: int = 1

    def __str__(self):
        return (
            "\n".join(["    " + x + ": " + repr(y) for x, y in self.__dict__.items()])
            + "\n"
        )


class Method_Config(CONFIG_CLASS):
    def __init__(self):
        super().__init__()
        self.name: str = "method_name"
        self.optimizer: str = "SGD"
        self.solver_depth: int = 0
        self.solver_channel_size: int = 5
        self.solver_reducing_layers: int = 5

        self.importance_of_new_task: float = 0.3
        self.replay_mode: str = "none"

    def __str__(self):
        return (
            "\n".join(["    " + x + ": " + repr(y) for x, y in self.__dict__.items()])
            + "\n"
        )


class Data_Config(CONFIG_CLASS):
    def __init__(self):
        super().__init__()
        self.name: str = "data_name"
        self.path: str = ""
        self.batch_size: int = 32
        self.num_workers: int = 0

        self.ts_dataset_name: str = "ucihar"
        self.ts_datasets_idx: str = "1,2,3"

    def __str__(self):
        return (
            "\n".join(["    " + x + ": " + repr(y) for x, y in self.__dict__.items()])
            + "\n"
        )


class Online_Config(CONFIG_CLASS):
    def __init__(self):
        super().__init__()
        self.dist_buffer_size = 1000
        self.algorithm = "OnlingAlgorithm"
        self.type = "DNN"

        self.rep_model_name = (
            "None"  # rep_model is used to extract the feature before the `model`
        )
        # choice: {'None', 'ResNet', 'Transformer'}
        self.rep_model_path = ""

        self.cls_model_name = "Linear"  # model is for final classification
        # choice: {'Linear', 'Simplex'}
        self.cls_model_path = ""

        self.update_DNN_represent = (
            False  # whether update the feature extraction part of DNN,
        )
        # False means only update the last layer (cls_model)
        # True means update the 'rep_model'

        self.write = True
        self.grad_clip = False

    def __str__(self):
        return (
            "\n".join(["    " + x + ": " + repr(y) for x, y in self.__dict__.items()])
            + "\n"
        )


class Offline_Config(CONFIG_CLASS):
    def __init__(self):
        super().__init__()
        self.source_batch_size = 10
        self.type = "DNN"
        self.cls_model_name = "Linear"
        self.cls_model_path = ""
        self.rep_model_name = "None"
        self.rep_model_path = ""

    def __str__(self):
        return (
            "\n".join(["    " + x + ": " + repr(y) for x, y in self.__dict__.items()])
            + "\n"
        )


class Config(CONFIG_CLASS):
    def __init__(self, config_path, save_path=None, remark=""):
        super().__init__()
        # Time stamp:
        timenow = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        self.timenow = timenow

        # basic args
        self.config_path: str = config_path
        self.task_name: str = "Demo"
        self.remark: str = ""
        self.debug: bool = False

        # hardware args
        self.hardware_cfgs = Hardware_Config()

        # general args
        self.seed: int = 0
        self.thread = 0
        self.output_dir: str = "./output"

        # data args
        self.data_cfgs = Data_Config()

        # method args
        self.method_cfgs = Method_Config()

        self.online_cfgs = Online_Config()
        self.offline_cfgs = Offline_Config()

        self.log_interval = 100  # this is for logging

        # train args
        self.save_best_model: bool = True

        self.T = 1000  # total round of the experiment

        # Loading Config
        self.load_from_yaml(config_path)
        if remark != "":
            self.remark = remark
        all_args: str = self.get_all_args()

        # log args
        self.checkpoint_dir: str = "./" + self.task_name + "_" + "checkpoints"
        self.log_dir: str = "./tb_logs"

        # if save_path is None:
        #     self.save_path = os.path.join(all_args, timenow)
        # else:
        #     self.save_path = os.path.join(all_args, save_path)

        _random_suffix = hex(random.randrange(0, 2**16))[2:].zfill(4)
        self.save_path = (save_path if save_path else timenow) + "-" + _random_suffix
        while os.path.exists(os.path.join(self.checkpoint_dir, self.save_path)):
            _random_suffix = hex(random.randrange(0, 2**16))[2:].zfill(4)
            self.save_path = (
                (save_path if save_path else timenow) + "-" + _random_suffix
            )

        self.create_folder()
        self.use_tb: bool = True

        self.writer = lambda: SummaryWriter(
            log_dir=os.path.join(self.log_dir, self.save_path)
        )
        self.logger = MyLogger(
            os.path.join(self.checkpoint_dir, self.save_path, "StreamDataConfig.log")
        )

    def __str__(self):
        # return '\n'.join([str(x) + ': ' + str(y) for x, y in self.__dict__.items()]) + '\n'

        return (
            "\n".join(
                sorted(
                    [
                        (
                            x + ": " + repr(y)
                            if not isinstance(getattr(self, x), CONFIG_CLASS)
                            else "\n" + x + ":\n" + str(y)
                        )
                        for x, y in self.__dict__.items()
                    ],
                    key=lambda s: (s.startswith("\n"), len(s), s),
                )
            )
            + "\n"
        )

    def get_all_args(self):
        if self.remark != "":
            all_args = self.task_name + "_" + self.timenow + "_" + self.remark
        else:
            all_args = self.task_name + "_" + self.timenow
        return all_args

    def load_from_yaml(self, yaml_file):
        with open(yaml_file, "r") as file:
            data = yaml.safe_load(file)
        self.update(data)

    def create_folder(self):
        full_path = os.path.join(self.checkpoint_dir, self.save_path)
        split_full_path = full_path.split("/")
        iter_path = [
            "/".join(split_full_path[:i]) for i in range(1, len(split_full_path) + 1)
        ]
        for path in iter_path:
            if not (os.path.exists(path)):
                os.mkdir(path)
        if not (os.path.exists(self.output_dir)):
            os.mkdir("output")

    def export(self):
        self.logger.info(
            "\n".join([str(x) + ": " + str(y) for x, y in self.__dict__.items()]) + "\n"
        )
