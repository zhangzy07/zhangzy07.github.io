import scipy
import torch
import numpy as np
from sklearn import metrics


def KL_divegence_diff(a, b, num_classes):
    """
    :param a: numpy array (discrete labels)
    :param b: numpy array (discrete labels)
    :return: a float, the difference between a and b (using KL divergence as measure)
    """
    aa = np.zeros(num_classes)
    bb = np.zeros(num_classes)
    if isinstance(a, torch.Tensor):
        a = a.cpu().numpy()
    if isinstance(b, torch.Tensor):
        b = b.cpu().numpy()
    for i in range(num_classes):
        aa[i] = np.sum(a == i)
        bb[i] = np.sum(b == i)
    KL = scipy.stats.entropy(aa, bb)
    score = 1 - 1.0 / (1.0 + KL)
    return score


def mutual_info_diff(a, b, num_classes):
    """
    :param a: numpy array (discrete labels)
    :param b: numpy array (discrete labels)
    :return: a float,
    """
    longer, shorter = (a, b) if len(a) > len(b) else (b, a)
    length_diff = len(longer) - len(shorter)
    shorter = np.random.permutation(shorter)
    shorter_padded = np.pad(shorter, (0, length_diff), "wrap")
    # print(shorter_padded)

    mi = metrics.mutual_info_score(shorter_padded, longer)
    return 1.0 - mi


if __name__ == "__main__":
    a = np.array([1, 2, 3, 4, 4, 2, 1, 2, 3, 4])
    # b = torch.rand(10)
    b = np.array([2, 2, 3, 4, 4, 2])
    b = np.array([1, 2, 3, 4, 4, 2, 1, 2, 3, 4])
    # mi = KL_divegence_diff(a, b)
    # mi = mutual_info_diff(a, b, num_classes=4)
    mi = KL_divegence_diff(a, b, num_classes=4)
