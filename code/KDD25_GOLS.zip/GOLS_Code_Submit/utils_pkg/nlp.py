import os

import torch

from tokenizers import Tokenizer


_PROJECT_DIR = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
_TOKENIZER_PATH = os.path.join(
    _PROJECT_DIR, "demos", "resource", "bert_base_uncased_tokenizer.json"
)

google_tokenizer: Tokenizer = Tokenizer.from_file(_TOKENIZER_PATH)

VOCAB_SIZE = google_tokenizer.get_vocab_size()

PAD_ID = google_tokenizer.token_to_id("[PAD]")
UNK_ID = google_tokenizer.token_to_id("[UNK]")
CLS_ID = google_tokenizer.token_to_id("[CLS]")
SEP_ID = google_tokenizer.token_to_id("[SEP]")
MASK_ID = google_tokenizer.token_to_id("[MASK]")


def text2ids(text: str) -> list[int]:
    """
    text is converted to lowercase first.
    """
    lowercase = text.lower()
    encoded = google_tokenizer.encode(
        lowercase, is_pretokenized=False, add_special_tokens=False
    )
    return encoded.ids


def ids2text(ids: list[int]) -> str:
    """
    [UNK] is ignored.
    """
    return google_tokenizer.decode(ids)


def preprocess(
    text: str, prefix_tokens: list[str], suffix_tokens: list[str], max_token_num: int
) -> torch.LongTensor:
    ids = text2ids(text)
    if max_token_num > 0:
        keep_token_num = max_token_num - len(prefix_tokens) - len(suffix_tokens)
        assert keep_token_num > 0
        keep_ids = ids[:keep_token_num] + [PAD_ID] * max(0, keep_token_num - len(ids))
    else:
        keep_ids = ids
    prefix_ids = list(map(google_tokenizer.token_to_id, prefix_tokens))
    suffix_ids = list(map(google_tokenizer.token_to_id, suffix_tokens))
    return torch.LongTensor(prefix_ids + keep_ids + suffix_ids)
