"""
hardware_cfgs:
    cpu_num: 8
    device: 'cuda'
    gpu_ids: 'auto'
"""

import os, random, typing
import numpy as np
import pandas as pd
import torch
from utils_pkg import exp_config


def set_random_seed(seed: typing.Hashable, cudnn_deterministic: bool = False):
    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    if cudnn_deterministic:
        torch.backends.cudnn.deterministic = True


def set_hardware_state(cfgs: exp_config.Config):
    cfgs.logger(
        f"[set_hardware_state] (ignored fields) cfgs.hardware_cfgs.{{cuda,multi_gpus,thread_num}}"
    )

    cpu_num = int(cfgs.hardware_cfgs.cpu_num)
    cfgs.logger(f"[set_hardware_state] cpu_num={cpu_num}")

    os.environ["OMP_NUM_THREADS"] = str(cpu_num)
    os.environ["NUMEXPR_NUM_THREADS"] = str(cpu_num)
    os.environ["OPENBLAS_NUM_THREADS"] = str(cpu_num)
    os.environ["MKL_NUM_THREADS"] = str(cpu_num)
    os.environ["VECLIB_MAXIMUM_THREADS"] = str(cpu_num)
    torch.set_num_threads(cpu_num)
    torch.set_num_interop_threads(cpu_num)

    device = cfgs.hardware_cfgs.device

    if device.lower() in ("gpu", "cuda"):
        device = cfgs.hardware_cfgs.device = "cuda"
        cfgs.logger(f"[set_hardware_state] device={repr(device)}")

        gpu_ids = cfgs.hardware_cfgs.gpu_ids

        if all(map(lambda s: s.isdecimal(), gpu_ids.split(","))):
            cfgs.logger(f"[set_hardware_state] gpu_ids={repr(gpu_ids)}")

        else:
            cfgs.logger(
                f"[set_hardware_state] (illegal config) gpu_ids={repr(gpu_ids)}"
            )
            with os.popen(
                "nvidia-smi --query-gpu=utilization.memory,utilization.gpu --format=csv"
            ) as smi_csv:
                table = pd.read_csv(smi_csv).rename(
                    columns={
                        "utilization.memory [%]": "mem",
                        " utilization.gpu [%]": "gpu",
                    }
                )
                table["mem"] = table["mem"].apply(lambda s: int(s.rstrip("%").strip()))
                table["gpu"] = table["gpu"].apply(lambda s: int(s.rstrip("%").strip()))
                table = table.sort_values(by=["mem", "gpu"])
                gpu_ids = str(table.index[0])
            cfgs.logger(
                f"[set_hardware_state] (auto selection) gpu_ids={repr(gpu_ids)} mem={table.iloc[0,0]}% gpu={table.iloc[0,1]}%"
            )

        os.environ["CUDA_VISIBLE_DEVICES"] = gpu_ids

    else:
        device = cfgs.hardware_cfgs.device = "cpu"
        cfgs.logger(f"[set_hardware_state] device={repr(device)}")
