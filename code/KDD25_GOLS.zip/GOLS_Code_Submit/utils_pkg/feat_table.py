import torch
import math


class Feat_Tabel:
    def __init__(self):
        self.labeled_feat_tables = None
        self.unlabeled_feat_tables = None

    def get_mask(self, logits, threshold, num_class=10):
        ent = -(logits.softmax(1) * logits.log_softmax(1)).sum(1)
        threshold = threshold * math.log(num_class)
        mask = ent.le(threshold).float()
        return mask

    def update_feat_table(
        self,
        cur_feat_l,
        cur_feat_u,
        feat_table_size_l=128,
        feat_table_size_u=128,
        mask_l=None,
        mask_u=None,
    ):
        if mask_l is not None:
            mask_l = mask_l.nonzero().flatten()
            mask_u = mask_u.nonzero().flatten()
            cur_feat_l = cur_feat_l[mask_l]
            cur_feat_u = cur_feat_u[mask_u]
        if feat_table_size_l > 0:
            if self.labeled_feat_tables is None:
                self.labeled_feat_tables = cur_feat_l
                self.unlabeled_feat_tables = cur_feat_u
            else:
                self.labeled_feat_tables = torch.cat(
                    [self.labeled_feat_tables, cur_feat_l]
                )
                self.unlabeled_feat_tables = torch.cat(
                    [self.unlabeled_feat_tables, cur_feat_u]
                )
                if len(self.labeled_feat_tables) > feat_table_size_l:
                    self.labeled_feat_tables = self.labeled_feat_tables[
                        -feat_table_size_l:
                    ]
                if len(self.unlabeled_feat_tables) > feat_table_size_u:
                    self.unlabeled_feat_tables = self.unlabeled_feat_tables[
                        -feat_table_size_u:
                    ]
            feat_l = self.labeled_feat_tables
            feat_u = self.unlabeled_feat_tables
            self.labeled_feat_tables = self.labeled_feat_tables.detach()
            self.unlabeled_feat_tables = self.unlabeled_feat_tables.detach()
        else:
            feat_l = cur_feat_l
            feat_u = cur_feat_u

        return feat_l, feat_u

    def clear_feat_table(self):
        self.labeled_feat_tables = None
        self.unlabeled_feat_tables = None
