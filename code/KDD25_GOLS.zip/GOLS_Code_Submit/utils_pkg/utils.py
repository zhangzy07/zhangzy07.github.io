import os
import os.path
import torchvision
import torch
from torch import nn
from torch.autograd import Variable
from torch.utils.data import DataLoader
from torch.utils.data.dataloader import default_collate
from tqdm import tqdm
import random
import numpy as np
from sklearn.metrics import classification_report, roc_auc_score, accuracy_score
from sklearn import metrics
import time
from os.path import join


def collate_first2_args(batch):
    data = [item[0] for item in batch]
    target = [item[1] for item in batch]
    # target = torch.LongTensor(target)
    return [torch.stack(data, 0), torch.tensor(target)]

    # # test_set
    # if (isinstance(target, list) or isinstance(target, tuple)) and len(target) > 0 and isinstance(target[0], torch.Tensor):
    #     return [torch.concat(data), torch.concat(target)]
    # # train_set
    # else:
    #     return [torch.stack(data, 0), torch.tensor(target)]


# def roc_auc_score_FIXED(y_true, y_pred, numclasses, multi_class):
# 	if len(np.unique(y_true)) < numclasses:  # bug in roc_auc_score
# 		return accuracy_score(y_true, np.rint(y_pred))
# 	return roc_auc_score(y_true, y_pred, multi_class=multi_class)


def safe_save(model, expr_path):
    time.sleep(0.4)
    torch.save(model.state_dict(), join(expr_path, "initial_model.bin"))


def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True


def sortByKey(key, array):
    Z = zip(key, array)
    key, array = zip(*sorted(Z))
    return array


def sortByKeyNP(key, array):
    array = np.array(array)
    key = np.array(key)
    idx = np.argsort(key)
    return key[idx], array[idx, :, :]


def label_squeezing_collate_fn(batch):
    x, y, domain_idx = default_collate(batch)
    return x, y.long().squeeze(), domain_idx.long().squeeze()


def get_data_loader(
    dataset, batch_size, cuda=False, collate_fn=None, shuffle=True, drop_last=True
):
    return DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        drop_last=drop_last,
        collate_fn=(collate_fn or default_collate),
        **({"num_workers": 0, "pin_memory": True} if cuda else {})
    )


def weighted_auc(y_true, y_valid, args):
    tpr_thresholds = [0.0, 0.3, 1.0]
    weights = [5, 1]

    fpr, tpr, thresholds = metrics.roc_curve(y_true, y_valid, pos_label=1)

    # size of subsets
    areas = np.array(tpr_thresholds[1:]) - np.array(tpr_thresholds[:-1])

    # The total area is normalized by the sum of weights such that the final weighted AUC is between 0 and 1.
    normalization = np.dot(areas, weights)

    competition_metric = 0
    for idx, weight in enumerate(weights):
        y_min = tpr_thresholds[idx]
        y_max = tpr_thresholds[idx + 1]
        mask = (y_min < tpr) & (tpr < y_max)

        if mask.sum() == 0:
            continue

        x_padding = np.linspace(fpr[mask][-1], 1, 100)

        x = np.concatenate([fpr[mask], x_padding])
        y = np.concatenate([tpr[mask], [y_max] * len(x_padding)])
        y = y - y_min  # normalize such that curve starts at y=0
        score = metrics.auc(x, y)
        submetric = score * weight
        best_subscore = (y_max - y_min) * weight
        competition_metric += submetric

    return competition_metric / normalization


def check_checkpoint(model, model_dir, prefix, postfix):
    path = os.path.join(model_dir, prefix + "_" + model.name + "_" + postfix)

    if os.path.exists(path):
        return True

    return False


def save_checkpoint(model, model_dir, prefix, postfix):
    path = os.path.join(model_dir, prefix + "_" + model.name + "_" + postfix)

    # save the checkpoint.
    if not os.path.exists(model_dir):
        os.makedirs(model_dir)

    torch.save({"state": model.state_dict()}, path)

    # notify that we successfully saved the checkpoint.
    print("=> saved the model {name} to {path}".format(name=model.name, path=path))


def load_checkpoint(model, model_dir, prefix, postfix):
    # path = os.path.join(model_dir, model.name)
    path = os.path.join(model_dir, prefix + "_" + model.name + "_" + postfix)

    # load the checkpoint.
    checkpoint = torch.load(path)
    print(
        "=> loaded checkpoint of {name} from {path}".format(name=model.name, path=path)
    )

    # load parameters and return the checkpoint's epoch and precision.
    model.load_state_dict(checkpoint["state"])


def test_model(model, sample_size, path, verbose=True):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    img = None
    if hasattr(model, "sample_avg"):
        img, _ = model.sample_avg(sample_size)
        img = img.data_cfgs
    else:
        img = model.sample(sample_size).data_cfgs
    torchvision.utils.save_image(
        img,
        path + ".jpg",
        nrow=6,
    )
    if verbose:
        print('=> generated sample images at "{}".'.format(path))


def to_one_hot(label, dimension=2):
    results = torch.zeros((len(label), dimension))
    for i in range(dimension):
        results[label == i, i] = 1.0
    return results


def to_hard_label(pred, dimension=2, th=0.75):
    results = torch.zeros((len(pred), dimension))
    # max_odx
    # for i in range(dimension):
    # 	results[label == i, i] = 1.0
    one_idx = pred[:, 1] >= th
    zero_idx = pred[:, 1] < th
    results[one_idx, 1] = 1.0
    results[zero_idx, 0] = 1.0
    return results


def validate(
    model,
    dataset,
    test_size=1024,
    cuda=False,
    verbose=True,
    collate_fn=None,
    cal_regret=False,
    args=None,
):
    data_loader = get_data_loader(
        dataset,
        128,
        cuda=cuda,
        collate_fn=(collate_fn or default_collate),
        drop_last=False,
    )
    total_tested = 0
    total_correct = 0
    total_loss = 0.0
    all_preds = None
    all_labels = None
    for data, labels, domain_idx in data_loader:
        # break on test size.
        if total_tested >= test_size:
            break
        # test the model.
        data = Variable(data).cuda() if cuda else Variable(data)
        labels = Variable(labels).cuda() if cuda else Variable(labels)

        scores, _ = model.solver(data)
        solver_criterion = model.loss_class

        loss = solver_criterion(scores, labels)
        _, predicted = torch.max(scores, 1)

        if all_preds is None:
            all_preds = scores.detach().cpu()
            all_labels = labels.detach().cpu()
        else:
            all_preds = torch.cat([all_preds, scores.detach().cpu()], dim=0)
            all_labels = torch.cat([all_labels, labels.detach().cpu()], dim=0)

        # update statistics.
        # total_correct += (predicted == labels).sum().data[0]
        total_correct += (predicted == labels).sum().item()
        if cal_regret:
            total_loss += loss.item() * len(data)
        else:
            total_loss += loss.item()
        total_tested += len(data)

    precision = total_correct / total_tested

    others = {}
    others["auc_score"] = 1.0
    # args.logger.info('all label shape {}'.format(all_labels.shape))
    if "data.sim" not in args.experiment and "data.Bsim" not in args.experiment:
        # args.logger.info('All Labels: {} {} {}'.format(all_labels.shape, torch.max(all_labels), all_labels[:20]))
        auc_score = None
        try:
            if "data.loan" in args.experiment and "OMD" in args.method_cfgs:
                all_preds = torch.softmax(all_preds, dim=1)
                auc_score = weighted_auc(
                    all_labels.numpy(), all_preds.numpy()[:, 1], args
                )
                args.logger.data_info("weighted auc: {}".format(auc_score))
            else:
                auc_score = roc_auc_score(
                    to_one_hot(all_labels, dimension=args.classes).numpy(),
                    all_preds.numpy(),
                    multi_class="ovr",
                )
        except ValueError:
            pass
        if auc_score is not None:
            others["auc_score"] = auc_score

    if not cal_regret:
        return_loss = total_loss / total_tested
    else:
        return_loss = total_loss  # if calculate regret, do not average

    if verbose:
        if args:
            args.logger.data_info("=> test loss: {:.3f}".format(return_loss))
            args.logger.data_info("=> test precision: {:.3f}".format(precision))
        else:
            print("=> test loss: {:.3f}".format(return_loss))
            print("=> test precision: {:.3f}".format(precision))
    return return_loss, precision, others


def full_validate(model, dataset, cuda=False, verbose=True, collate_fn=None):
    data_loader = get_data_loader(
        dataset,
        128,
        cuda=cuda,
        collate_fn=(collate_fn or default_collate),
        shuffle=False,
        drop_last=False,
    )
    total_tested = 0
    total_correct = 0
    total_loss = 0.0
    tot_feat = None
    tot_label = None  # Just for test

    # print('data_loader Len:', len(data_loader))
    for data, labels, domain_idx in tqdm(data_loader):
        # break on test size.
        # if total_tested >= test_size:
        # 	break
        # test the model.

        data = Variable(data).cuda() if cuda else Variable(data)
        labels = Variable(labels).cuda() if cuda else Variable(labels)

        scores, _ = model.solver(data)
        solver_criterion = model.loss_class

        feat = model.solver(data, out="feat")
        feat = feat.detach().cpu()
        if tot_feat is None:
            tot_feat = feat
        else:
            tot_feat = torch.cat((tot_feat, feat), dim=0)

        loss = solver_criterion(scores, labels)
        _, predicted = torch.max(scores, 1)

        if tot_label == None:
            tot_label = predicted
        else:
            tot_label = torch.cat((tot_label, predicted), dim=0)

        # update statistics.
        # total_correct += (predicted == labels).sum().data[0]
        total_correct += (predicted == labels).sum().item()
        total_loss += loss.item()
        total_tested += len(data)

    # print('Now have tested:', total_tested)
    precision = total_correct / total_tested
    avgloss = loss / total_tested
    # if verbose:
    print("=> on sampled dataset loss: {:.3f}".format(avgloss))
    print("=> on sampled dataset precision: {:.3f}".format(precision))
    return avgloss, precision, tot_feat, tot_label


def xavier_initialize(model):
    modules = [m for n, m in model.named_modules() if "conv" in n or "fc" in n]
    parameters = [p for m in modules for p in m.parameters()]

    for p in parameters:
        if p.dim() >= 2:
            nn.init.xavier_normal(p)
        else:
            nn.init.constant(p, 0)


def gaussian_initialize(model, std=0.01):
    modules = [m for n, m in model.named_modules() if "conv" in n or "fc" in n]
    parameters = [p for m in modules for p in m.parameters()]

    for p in parameters:
        if p.dim() >= 2:
            nn.init.normal_(p, std=std)
        else:
            nn.init.constant_(p, 0)


class LambdaModule(nn.Module):
    def __init__(self, f):
        super().__init__()
        self.f = f

    def forward(self, x):
        return self.f(x)
