import copy
import typing

from PIL import Image

import torch

from transformers import MobileNetV2ImageProcessor


# https://huggingface.co/google/mobilenet_v2_0.35_96
google_preprocessor_config_96 = {
    "crop_size": {"height": 96, "width": 96},
    "do_center_crop": True,
    "do_normalize": True,
    "do_rescale": True,
    "do_resize": True,
    "image_mean": [0.5, 0.5, 0.5],
    "image_std": [0.5, 0.5, 0.5],
    "resample": 2,
    "rescale_factor": 0.00392156862745098,
    "size": {"shortest_edge": 128},
}
google_preprocessor_96 = MobileNetV2ImageProcessor(**google_preprocessor_config_96)

google_preprocessor_config_32 = copy.deepcopy(google_preprocessor_config_96)
google_preprocessor_config_32["crop_size"] = {"height": 32, "width": 32}
google_preprocessor_32 = MobileNetV2ImageProcessor(**google_preprocessor_config_32)


def preprocess_96(image: Image.Image, **kwargs) -> torch.FloatTensor:
    return google_preprocessor_96(image, return_tensors="pt", **kwargs).pixel_values[0]


def preprocess_32(
    image: typing.Union[Image.Image, torch.Tensor], **kwargs
) -> torch.FloatTensor:
    if isinstance(image, torch.Tensor):
        if len(image.shape) == 2:  # Grayscale -> RGB; MNIST
            image = image.repeat((3, 1, 1))
    return google_preprocessor_32(image, return_tensors="pt", **kwargs).pixel_values[0]
