import time


class Timer(object):
    def __init__(self):
        self.tik()

    def tik(self):
        self.timestamp = time.time()

    def tok(self, desc=""):
        history = self.timestamp
        self.tik()
        print(
            ">>> [{}] Cost time: {:.4f} seconds".format(desc, self.timestamp - history)
        )


if __name__ == "__main__":
    time_helper = Timer()
    time_helper.tik()
    time.sleep(5)
    time_helper.tok()
