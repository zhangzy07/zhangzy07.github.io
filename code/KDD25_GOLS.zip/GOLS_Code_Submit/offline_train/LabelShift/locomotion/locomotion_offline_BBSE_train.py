# /usr/bin/env python
# -*- coding: utf-8 -*-
import sys

sys.path.append("../../../../")
sys.path.append("../../../")
sys.path.append("../../")
sys.path.append("./")
import logging
import argparse
import json as js
import os
import time
from os.path import join

import numpy as np
import torch.utils.data as data
from torch.utils.tensorboard import SummaryWriter

from dataset.LabelShift.wrapper import get_dataset
from offline_train.LabelShift.DNN_bbse import DNN_BBSE
from models_pkg.wrapper import get_cls_model, get_rep_model

# from models_pkg.bbse import BBSE
from online.utils.risk import *
from utils_pkg import exp_config

# from utils_pkg import argparser

from utils_pkg.utils import setup_seed

logging.getLogger("pytorch_lightning").setLevel(logging.WARNING)


def write(writer, info, t):
    for k, v in info.items():
        writer.add_scalar(k, v, t)


def set_cpu_num(cpu_num=8):
    os.environ["OMP_NUM_THREADS"] = str(cpu_num)
    os.environ["OPENBLAS_NUM_THREADS"] = str(cpu_num)
    os.environ["MKL_NUM_THREADS"] = str(cpu_num)
    os.environ["VECLIB_MAXIMUM_THREADS"] = str(cpu_num)
    os.environ["NUMEXPR_NUM_THREADS"] = str(cpu_num)
    torch.set_num_threads(cpu_num)
    torch.set_num_interop_threads(cpu_num)


def set_gpu_id(gpu_ids="0"):
    os.environ["CUDA_VISIBLE_DEVICES"] = gpu_ids


def stepsize(cfgs: exp_config.Config, sigma_min, K):
    alg = cfgs.online_cfgs.algorithm
    kwargs = cfgs.online_cfgs.kwargs
    D = float(kwargs["D"])
    G = float(kwargs["G"])
    T = cfgs.T

    print("D: {}, G: {}, T:{}".format(D, G, T))
    print("K: {}, Sigma: {}".format(K, sigma_min))

    min_step, max_step = D / (G * (T**0.5)), D / G

    max_step_clip = kwargs.get("max_step_clip", max_step)
    max_step = min(max_step, max_step_clip)

    return min_step, max_step


parser = argparse.ArgumentParser("PyTorch implementation for Offline Training")

parser.add_argument(
    "--config_path",
    type=str,
    default="./demos/LabelShift/locomotion/DNNOGD/config.yaml",
)

parser.add_argument("--remark", type=str, default="")
# parser.add_argument('--task_name', type=str, default='')


if __name__ == "__main__":
    args = parser.parse_args()
    args.config_path = "./demos/LabelShift/locomotion/DNNOGD/config.yaml"
    cfgs = exp_config.Config(config_path=args.config_path, remark=args.remark)

    gpu_ids = "3"
    num_epoch = 100
    train_batchsize = 256
    lr = 1e-3

    cfgs.offline_cfgs.kwargs["train_batchsize"] = train_batchsize
    cfgs.offline_cfgs.kwargs["lr"] = lr
    cfgs.output_dir = "./offline_train_log/locomotion/"
    os.makedirs(cfgs.output_dir, exist_ok=True)

    setup_seed(cfgs.seed)
    experiment = cfgs.task_name

    device = cfgs.hardware_cfgs.device
    cpu_num = cfgs.hardware_cfgs.cpu_num
    set_cpu_num(cpu_num)
    set_gpu_id(gpu_ids=gpu_ids)
    rng = np.random.default_rng(cfgs.seed)

    train_set, test_set, data_info = get_dataset(
        # name=cfgs['Data']['name'],
        name=cfgs.data_cfgs.name,
        cfgs=cfgs,
        data_cfgs_kwargs=cfgs.data_cfgs.kwargs,
        rng=rng,
    )
    print("Data: {}".format(cfgs.data_cfgs.name))
    print("Data info: {}".format(data_info))

    # Clear the initialization
    cfgs.offline_cfgs.cls_model_path = ""
    cfgs.offline_cfgs.rep_model_path = ""

    # BBSE estimation
    offline_rep_model, _ = get_rep_model(
        cfgs,
        cfgs.offline_cfgs,
        cfgs.offline_cfgs.type,
        data_info,
        device,
        cfgs.offline_cfgs.rep_model_name,
        cfgs.offline_cfgs.rep_model_path,
    )
    offline_cls_model, _ = get_cls_model(
        cfgs,
        cfgs.offline_cfgs,
        cfgs.offline_cfgs.type,
        data_info,
        device,
        cfgs.offline_cfgs.cls_model_name,
        cfgs.offline_cfgs.cls_model_path,
    )

    source_loader = data.DataLoader(
        train_set,
        batch_size=cfgs.offline_cfgs.kwargs[
            "train_batchsize"
        ],  # change the batch size to train_mode's train_batchsize
        shuffle=True,
        pin_memory=False,
    )

    estimator = DNN_BBSE(
        cfgs=cfgs,
        rep_model=offline_rep_model,
        cls_model=offline_cls_model,
        train_set=source_loader,
        cls_num=data_info["cls_num"],
        device=device,
        kwargs=cfgs.offline_cfgs.kwargs,
        train_BBSE=True,
    )
    # sigma_min = estimator.get_sigma_min()
    localtime = time.localtime()
    writer = SummaryWriter(
        join(
            cfgs.output_dir,
            "runs_{}_{}_lr_{}".format(
                time.strftime("%b_%d_%H%M", localtime), "BBSE", lr
            ),
        )
    )
    save_path = join(
        cfgs.output_dir,
        "runs_{}_{}_lr_{}".format(time.strftime("%b_%d_%H%M", localtime), "BBSE", lr),
    )
    cfgs.offline_cfgs.kwargs["save_path"] = save_path
    # record = run(cfgs.T, train_set, test_set, estimator, online_alg, cfgs, data_info, device=device, writer=writer)

    # offline train the estimator (BBSE)
    record = estimator.train(
        source_loader=source_loader,
        criterion=torch.nn.CrossEntropyLoss(),
        num_epoch=num_epoch,
        writer=writer,
    )
    with open(join(cfgs.output_dir, "result.json"), "w") as fw:
        js.dump(record, fw, indent=4)
