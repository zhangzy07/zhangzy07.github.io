# /usr/bin/env python
# -*- coding: utf-8 -*-
import copy
from os.path import join

import torch
from torch.utils.data import DataLoader
from tqdm import tqdm

import torch.utils.data as data

from utils_pkg.exp_config import Config

"""
Skyline:
    Use the whole dataset as offline dataset to get the optimal underlying representation.
"""


class DNN_Skyline_Rep(object):
    def __init__(
        self,
        cfgs: Config,
        rep_model,
        cls_model,
        train_set,
        test_set,
        cls_num,
        device,
        kwargs,
        train_BBSE=False,
    ):
        cls_model.eval()
        self.cfgs = cfgs
        self.cls_num = cls_num
        self.device = device

        self.rep_model = rep_model
        if self.rep_model is not None:
            self.rep_model = self.rep_model.to(self.device)

        self.cls_model = cls_model.to(self.device)
        self.total_domain_num = (
            self.cfgs.data_cfgs.kwargs["source_data"]["domain_idx_end"]
            - self.cfgs.data_cfgs.kwargs["source_data"]["domain_idx_start"]
        ) + 1
        self.cls_model_list = []
        for i in range(self.total_domain_num):
            self.cls_model_list.append(copy.deepcopy(self.cls_model))

        self.mode = ""

        self.train_set = train_set
        self.target_loader = data.DataLoader(
            test_set,
            batch_size=16,  # change the batch size to train_mode's train_batchsize
            shuffle=False,
            pin_memory=True,
            drop_last=False,
        )

    def train_multi_domain_cls(
        self, source_loader, criterion, num_epoch, writer
    ):  # train the rep_model and based on source data
        self.mode = "train_multi_domain_cls"
        record = {}
        self.rep_model.train()
        for i in range(self.total_domain_num):
            self.cls_model_list[i].train()
        # optimize all the self.cls_model_list[i] for i in range(self.total_domain_num):
        para_list = list(self.rep_model.parameters())
        for i in range(self.total_domain_num):
            para_list += list(self.cls_model_list[i].parameters())

        optimizer = torch.optim.Adam(para_list, lr=self.cfgs.offline_cfgs.kwargs["lr"])

        for epoch in range(num_epoch):
            # train_set, _, _ = get_dataset(
            #     # name=cfgs['Data']['name'],
            #     name=self.cfgs.data_cfgs.name,
            #     cfgs=self.cfgs,
            #     data_cfgs_kwargs=self.cfgs.data_cfgs.kwargs,
            #     rng=None
            # )
            # train_set.get_datetime = True
            self.train_set.reinit()
            source_loader = DataLoader(
                self.train_set,
                batch_size=self.cfgs.offline_cfgs.kwargs[
                    "train_batchsize"
                ],  # change the batch size to train_mode's train_batchsize
                # shuffle=False,
                shuffle=True,
                pin_memory=True,
            )

            for batch_idx, (data, target, domain_idx) in enumerate(source_loader):

                data, target = data.to(self.device), target.to(self.device)
                if self.rep_model is not None:
                    data = self.rep_model(data)

                    # FTPL: use FTPL to update rep_model, and get the best underlying rep_model
                    # generate exponential-distribution noise: sigma~exp(\eta) \in \R^d
                    # exponential_distribution = Exponential(self.eta)
                    # sigma = exponential_distribution.sample((representation.shape[1],)).to(self.device)
                    # exponential_distribution = Exponential(1.0)
                    # sigma = exponential_distribution.sample((data.shape[1],)).to(self.device) * self.eta
                    # data = data - sigma

                # output = self.cls_model_list[domain_idx[0]](data)
                output = torch.cat(
                    [
                        self.cls_model_list[domain_idx[i]](data[i, :].reshape(1, -1))
                        for i in range(data.shape[0])
                    ],
                    dim=0,
                )

                loss = criterion(output, target)

                acc = (output.argmax(-1) == target).float().mean()

                optimizer.zero_grad()
                loss.backward()

                optimizer.step()

                iter = epoch * len(source_loader) + batch_idx
                if batch_idx % 10 == 0:
                    print(
                        "Train Epoch: {} [{}/{} ({:.0f}%)]\tLoss: {:.6f}\tAcc: {:.6f}".format(
                            epoch,
                            batch_idx * len(data),
                            len(source_loader.dataset),
                            100.0 * batch_idx / len(source_loader),
                            loss.item(),
                            acc.item(),
                        )
                    )
                    writer.add_scalar("Train/Loss", loss.item(), iter)
                    writer.add_scalar("Train/Acc", acc.item(), iter)

                    record["loss"] = loss.item()
                if iter % 100 == 0:
                    self.test_offline_cls(
                        target_loader=self.target_loader,
                        criterion=criterion,
                        writer=writer,
                        iter=iter,
                    )
                    self.rep_model.train()
                    for i in range(self.total_domain_num):
                        self.cls_model_list[i].train()
            # torch.save(model.state_dict(), join(expr_path, 'initial_model.bin'))
            torch.save(
                self.rep_model.state_dict(),
                join(
                    self.cfgs.offline_cfgs.kwargs["save_path"],
                    "rep_model_epoch_{}.bin".format(epoch),
                ),
            )
            for i in range(self.total_domain_num):
                torch.save(
                    self.cls_model_list[i].state_dict(),
                    join(
                        self.cfgs.offline_cfgs.kwargs["save_path"],
                        "cls_model_list_{}_epoch_{}.bin".format(i, epoch),
                    ),
                )
        return record

    def train_single_cls(
        self, source_loader, criterion, num_epoch, writer
    ):  # train the rep_model and based on source data
        self.mode = "train_single_cls"
        record = {}
        self.rep_model.train()
        self.cls_model.train()
        optimizer = torch.optim.Adam(
            list(self.rep_model.parameters()) + list(self.cls_model.parameters()),
            lr=self.cfgs.offline_cfgs.kwargs["lr"],
        )

        for epoch in range(num_epoch):
            self.train_set.reinit()
            source_loader = DataLoader(
                self.train_set,
                batch_size=self.cfgs.offline_cfgs.kwargs[
                    "train_batchsize"
                ],  # change the batch size to train_mode's train_batchsize
                shuffle=False,
                # shuffle=True,
                pin_memory=True,
            )
            for batch_idx, (data, target, domain_idx) in enumerate(source_loader):
                data, target = data.to(self.device), target.to(self.device)
                if self.rep_model is not None:
                    data = self.rep_model(data)

                    # FTPL: use FTPL to update rep_model, and get the best underlying rep_model
                    # generate exponential-distribution noise: sigma~exp(\eta) \in \R^d
                    # exponential_distribution = Exponential(self.eta)
                    # sigma = exponential_distribution.sample((representation.shape[1],)).to(self.device)
                    # exponential_distribution = Exponential(1.0)
                    # sigma = exponential_distribution.sample((data.shape[1],)).to(self.device) * self.eta
                    # data = data - sigma

                output = self.cls_model(data)

                loss = criterion(output, target)

                acc = (output.argmax(-1) == target).float().mean()

                self.cls_model.zero_grad()
                self.rep_model.zero_grad()
                loss.backward()

                optimizer.step()

                iter = epoch * len(source_loader) + batch_idx
                if batch_idx % 10 == 0:
                    print(
                        "Train Epoch: {} [{}/{} ({:.0f}%)]\tLoss: {:.6f}\tAcc: {:.6f}".format(
                            epoch,
                            batch_idx * len(data),
                            len(source_loader.dataset),
                            100.0 * batch_idx / len(source_loader),
                            loss.item(),
                            acc.item(),
                        )
                    )
                    writer.add_scalar("Train/Loss", loss.item(), iter)
                    writer.add_scalar("Train/Acc", acc.item(), iter)

                    record["loss"] = loss.item()
                if iter % 100 == 0:
                    self.test_offline_cls(
                        target_loader=self.target_loader,
                        criterion=criterion,
                        writer=writer,
                        iter=iter,
                    )
                    self.rep_model.train()
                    self.cls_model.train()

            # torch.save(model.state_dict(), join(expr_path, 'initial_model.bin'))
            torch.save(
                self.rep_model.state_dict(),
                join(
                    self.cfgs.offline_cfgs.kwargs["save_path"],
                    "rep_model_epoch_{}.bin".format(epoch),
                ),
            )
            torch.save(
                self.cls_model.state_dict(),
                join(
                    self.cfgs.offline_cfgs.kwargs["save_path"],
                    "cls_model_epoch_{}.bin".format(epoch),
                ),
            )
        return record

    @torch.no_grad()
    def test_offline_cls(self, target_loader, criterion, writer, iter):
        self.cls_model.eval()
        self.rep_model.eval()
        for i in range(self.total_domain_num):
            self.cls_model_list[i].eval()

        test_loss = 0
        correct = 0
        for data, target, domain_idx in tqdm(
            target_loader, desc="Iter {}: Test".format(iter)
        ):
            data, target = data.to(self.device), target.to(self.device)
            data = self.rep_model(data)

            if self.mode == "train_single_cls":
                output = self.cls_model(data)
            elif self.mode == "train_multi_domain_cls":
                # output = self.cls_model_list[domain_idx[0]](data)
                output = torch.cat(
                    [
                        self.cls_model_list[domain_idx[i]](data[i, :].reshape(1, -1))
                        for i in range(data.shape[0])
                    ],
                    dim=0,
                )
            else:
                raise NotImplementedError

            test_loss += criterion(output, target).item()
            pred = output.argmax(-1)
            correct += (pred == target).float().sum().item()

        test_loss /= len(target_loader.dataset)
        acc = correct / len(target_loader.dataset)

        print(
            "\nIter: {}, Test set: Average loss: {:.2f}, Test Accuracy: {}/{} ({:.2f}%)\n".format(
                iter, test_loss, correct, len(target_loader.dataset), 100.0 * acc
            )
        )
        # print('\nTest set: Average loss: {:.2f}, Accuracy: {}/{} ({:.0f}%)\n'.format(
        #     test_loss,
        #     correct,
        #     len(target_loader.dataset),
        #     100. * acc
        # ))

        writer.add_scalar("Test/Loss", test_loss, iter)
        writer.add_scalar("Test/Acc", acc, iter)

    @torch.no_grad()
    def estimate(self, target_x):
        # q_estimate as equal distribution
        q_estimate = torch.tensor([1 / self.cls_num] * self.cls_num).to(self.device)
        return q_estimate
