# /usr/bin/env python
# -*- coding: utf-8 -*-

from os.path import join
from itertools import chain

from tqdm import tqdm

import cvxpy as cp
import numpy as np

import torch
import torch.nn as nn
import torch.nn.functional as F

from utils_pkg import exp_config


class DNN_BBSE(object):
    def __init__(
        self,
        cfgs: exp_config.Config,
        rep_model: nn.Module,
        cls_model: nn.Module,
        train_set,
        cls_num,
        device,
        kwargs,
        train_BBSE=False,
    ):
        cls_model.eval()
        self.cfgs = cfgs
        self.cls_num = cls_num
        self.device = device

        self.rep_model = rep_model
        if self.rep_model is not None:
            self.rep_model = self.rep_model.to(self.device)
        self.cls_model = cls_model.to(self.device)

        if not train_BBSE:
            self.cm, self.cm_inv, self.sigma_min = self.confusion_matrix(train_set)

            self.cm = self.cm.to(self.device)
            self.cm_inv = self.cm_inv.to(self.device)

        self.nn_clip = kwargs.get("nn_clip", False)
        self.softmax = kwargs.get("softmax", False)

        self.use_history = kwargs.get("use_history", False)
        self.smooth_ratio = kwargs.get("smooth_ratio", 0)
        self.history = None

        self.use_reg = kwargs.get("use_reg", False)
        self.lamda = kwargs.get("lambda", 0)

    # train the rep_model and based on source data
    def train(
        self,
        source_loader,
        criterion,
        num_epoch,
        writer,
        train_rep=True,
        multi_gpus=False,
    ):
        record = {}

        if multi_gpus:
            self.cfgs.logger("Using Multi-GPUs for training")
            self.rep_model = nn.DataParallel(self.rep_model)
            self.cls_model = nn.DataParallel(self.cls_model)

        if train_rep and self.rep_model:
            self.rep_model.train()
        self.cls_model.train()

        if train_rep and self.rep_model:
            optimizer = torch.optim.Adam(
                list(self.rep_model.parameters()) + list(self.cls_model.parameters()),
                lr=self.cfgs.offline_cfgs.kwargs["lr"],
            )
        else:
            optimizer = torch.optim.Adam(
                list(self.cls_model.parameters()),
                lr=self.cfgs.offline_cfgs.kwargs["lr"],
            )

        # if multi_gpus:
        #     optimizer = nn.DataParallel(optimizer)

        for epoch in range(num_epoch):
            for batch_idx, (data, target) in tqdm(
                enumerate(source_loader), total=len(source_loader), ncols=80
            ):

                data, target = data.to(self.device), target.to(self.device)

                if self.rep_model:
                    if train_rep:
                        data = self.rep_model(data)
                    else:
                        with torch.no_grad():
                            data = self.rep_model(data)

                output = self.cls_model(data)
                loss = criterion(output, target)
                acc = (output.argmax(-1) == target).float().mean()

                self.cls_model.zero_grad()
                if train_rep and self.rep_model:
                    self.rep_model.zero_grad()
                loss.backward()

                optimizer.step()

                if batch_idx % 10 == 0:
                    self.cfgs.logger(
                        "Train Epoch: {} [{}/{} ({:.0f}%)]\tLoss: {:.6f}\tAcc: {:.6f}".format(
                            epoch,
                            batch_idx * len(data),
                            len(source_loader.dataset),
                            100.0 * batch_idx / len(source_loader),
                            loss.item(),
                            acc.item(),
                        )
                    )

                    _epoch_plus_progress = epoch + batch_idx / len(source_loader)
                    writer.add_scalar(
                        "Train/Progress",
                        _epoch_plus_progress,
                        epoch * len(source_loader) + batch_idx,
                    )
                    writer.add_scalar(
                        "Train/Loss",
                        loss.item(),
                        epoch * len(source_loader) + batch_idx,
                    )
                    writer.add_scalar(
                        "Train/Acc", acc.item(), epoch * len(source_loader) + batch_idx
                    )
                    record["loss"] = loss.item()

            # torch.save(model.state_dict(), join(expr_path, 'initial_model.bin'))
            if multi_gpus:
                if self.rep_model:
                    tmp_rep_model = self.rep_model.module
                else:
                    tmp_rep_model = self.rep_model
                tmp_cls_model = self.cls_model.module
            else:
                tmp_rep_model = self.rep_model
                tmp_cls_model = self.cls_model
            if train_rep and tmp_rep_model:
                if "ScriptModule" in str(
                    type(tmp_rep_model)
                ) or self.cfgs.offline_cfgs.rep_model_path.endswith(".scriptmodule"):
                    tmp_rep_model.save(
                        join(
                            self.cfgs.offline_cfgs.kwargs["save_path"],
                            f"rep_model_epoch_{epoch}.scriptmodule",
                        )
                    )
                elif isinstance(tmp_rep_model, torch.nn.Module):
                    torch.save(
                        tmp_rep_model.state_dict(),
                        join(
                            self.cfgs.offline_cfgs.kwargs["save_path"],
                            f"rep_model_epoch_{epoch}.bin",
                        ),
                    )
                else:
                    raise NotImplementedError(
                        f"can not save self.rep_model of type {type(tmp_rep_model)}"
                    )
            if "ScriptModule" in str(
                type(tmp_cls_model)
            ) or self.cfgs.offline_cfgs.cls_model_path.endswith(".scriptmodule"):
                tmp_cls_model.save(
                    join(
                        self.cfgs.offline_cfgs.kwargs["save_path"],
                        f"cls_model_epoch_{epoch}.scriptmodule",
                    )
                )
            elif isinstance(tmp_cls_model, torch.nn.Module):
                torch.save(
                    tmp_cls_model.state_dict(),
                    join(
                        self.cfgs.offline_cfgs.kwargs["save_path"],
                        f"cls_model_epoch_{epoch}.bin",
                    ),
                )
            else:
                raise NotImplementedError(
                    f"can not save self.cls_model of type {type(tmp_cls_model)}"
                )

        return record

    def train_skyline(
        self,
        train_loader,
        test_loader,
        criterion,
        num_epoch,
        writer,
        train_rep=True,
        multi_gpus=False,
    ):
        record = {}

        if multi_gpus:
            self.cfgs.logger("Using Multi-GPUs for training")
            self.rep_model = nn.DataParallel(self.rep_model)
            self.cls_model = nn.DataParallel(self.cls_model)

        if train_rep and self.rep_model:
            self.rep_model.train()
        self.cls_model.train()

        if train_rep and self.rep_model:
            optimizer = torch.optim.Adam(
                list(self.rep_model.parameters()) + list(self.cls_model.parameters()),
                lr=self.cfgs.offline_cfgs.kwargs["lr"],
            )
        else:
            optimizer = torch.optim.Adam(
                list(self.cls_model.parameters()),
                lr=self.cfgs.offline_cfgs.kwargs["lr"],
            )

        # if multi_gpus:
        #     optimizer = nn.DataParallel(optimizer)

        for epoch in range(num_epoch):
            len_loader = len(train_loader) + len(test_loader)
            for batch_idx, (data, target) in tqdm(
                enumerate(chain(train_loader, test_loader)), total=len_loader, ncols=80
            ):

                data, target = data.to(self.device), target.to(self.device)

                if self.rep_model:
                    if train_rep:
                        data = self.rep_model(data)
                    else:
                        with torch.no_grad():
                            data = self.rep_model(data)

                output = self.cls_model(data)
                loss = criterion(output, target)
                acc = (output.argmax(-1) == target).float().mean()

                self.cls_model.zero_grad()
                if train_rep and self.rep_model:
                    self.rep_model.zero_grad()
                loss.backward()

                optimizer.step()

                if batch_idx % 10 == 0:
                    self.cfgs.logger(
                        "Train Epoch: {} [{}/{} ({:.0f}%)]\tLoss: {:.6f}\tAcc: {:.6f}".format(
                            epoch,
                            batch_idx * len(data),
                            len(train_loader.dataset) + len(test_loader.dataset),
                            100.0 * batch_idx / len_loader,
                            loss.item(),
                            acc.item(),
                        )
                    )

                    _epoch_plus_progress = epoch + batch_idx / len_loader
                    writer.add_scalar(
                        "Train/Progress",
                        _epoch_plus_progress,
                        epoch * len_loader + batch_idx,
                    )
                    writer.add_scalar(
                        "Train/Loss", loss.item(), epoch * len_loader + batch_idx
                    )
                    writer.add_scalar(
                        "Train/Acc", acc.item(), epoch * len_loader + batch_idx
                    )
                    record["loss"] = loss.item()

            # torch.save(model.state_dict(), join(expr_path, 'initial_model.bin'))
            if multi_gpus:
                if self.rep_model:
                    tmp_rep_model = self.rep_model.module
                else:
                    tmp_rep_model = self.rep_model
                tmp_cls_model = self.cls_model.module
            else:
                tmp_rep_model = self.rep_model
                tmp_cls_model = self.cls_model
            if train_rep and tmp_rep_model:
                if "ScriptModule" in str(
                    type(tmp_rep_model)
                ) or self.cfgs.offline_cfgs.rep_model_path.endswith(".scriptmodule"):
                    tmp_rep_model.save(
                        join(
                            self.cfgs.offline_cfgs.kwargs["save_path"],
                            f"rep_model_epoch_{epoch}.scriptmodule",
                        )
                    )
                elif isinstance(tmp_rep_model, torch.nn.Module):
                    torch.save(
                        tmp_rep_model.state_dict(),
                        join(
                            self.cfgs.offline_cfgs.kwargs["save_path"],
                            f"rep_model_epoch_{epoch}.bin",
                        ),
                    )
                else:
                    raise NotImplementedError(
                        f"can not save self.rep_model of type {type(tmp_rep_model)}"
                    )
            if "ScriptModule" in str(
                type(tmp_cls_model)
            ) or self.cfgs.offline_cfgs.cls_model_path.endswith(".scriptmodule"):
                tmp_cls_model.save(
                    join(
                        self.cfgs.offline_cfgs.kwargs["save_path"],
                        f"cls_model_epoch_{epoch}.scriptmodule",
                    )
                )
            elif isinstance(tmp_cls_model, torch.nn.Module):
                torch.save(
                    tmp_cls_model.state_dict(),
                    join(
                        self.cfgs.offline_cfgs.kwargs["save_path"],
                        f"cls_model_epoch_{epoch}.bin",
                    ),
                )
            else:
                raise NotImplementedError(
                    f"can not save self.cls_model of type {type(tmp_cls_model)}"
                )

        return record

    def get_sigma_min(self):
        return self.sigma_min

    @torch.no_grad()
    def confusion_matrix(self, train_set):
        cmatrix = torch.zeros((self.cls_num, self.cls_num)).cpu()
        tot_data = None
        tot_target = None

        if self.rep_model is not None:
            self.rep_model.eval()

        source_loader = torch.utils.data.DataLoader(
            train_set,
            batch_size=self.cfgs.online_cfgs.kwargs.get("rep_batch_size", 256),
            shuffle=False,
            pin_memory=True,
            drop_last=False,
        )
        for batch_idx, (data, target) in enumerate(
            tqdm(source_loader, desc="Confusion Matrix | Getting Representation")
        ):
            data, target = data.to(self.device), target.to(self.device)
            # if batch_idx == 0:
            #     self.cfgs.logger('# [DNN_BBSE.confusion_matrix] data shape:', data.shape)
            #     self.cfgs.logger('# [DNN_BBSE.confusion_matrix] target shape:', target.shape)
            #     self.cfgs.logger('# [DNN_BBSE.confusion_matrix] data device:', data.device)
            #     self.cfgs.logger('# [DNN_BBSE.confusion_matrix] rep_model device:', next(self.rep_model.parameters()).device)
            if self.rep_model is not None:
                data = self.rep_model(data).detach()
            if tot_data is None:
                tot_data = data.cpu().detach()
                tot_target = target.cpu().detach()
            else:
                tot_data = torch.cat((tot_data, data.cpu().detach()), dim=0)
                tot_target = torch.cat((tot_target, target.cpu().detach()), dim=0)

        # self.cfgs.logger('# [DNN_BBSE.confusion_matrix] cls_model:', self.cls_model)
        # self.cfgs.logger('# [DNN_BBSE.confusion_matrix] tot_data shape:', tot_data.shape)
        # self.cfgs.logger('# [DNN_BBSE.confusion_matrix] tot_target shape:', tot_target.shape)
        cpu_cls_model = self.cls_model.cpu()
        output = cpu_cls_model(tot_data)
        pred = output.argmax(-1)
        indices = self.cls_num * pred + tot_target

        m = torch.bincount(indices, minlength=self.cls_num**2)
        cmatrix += m.reshape(cmatrix.shape)

        cmatrix_joint = F.normalize(cmatrix.float().view(-1), p=1, dim=0).reshape(
            self.cls_num, self.cls_num
        )
        u, s, v = torch.svd(cmatrix_joint)

        cmatrix = F.normalize(cmatrix.float(), p=1, dim=0)
        _u, _s, _v = torch.svd(cmatrix)

        cm_inv = cmatrix.inverse()

        self.cfgs.logger(
            "[BBSE] Joint Minimum Singular Value: {}".format(s.min().item())
        )
        self.cfgs.logger(
            "[BBSE] Conditional Minimum Singular Value: {}".format(_s.min().item())
        )

        return cmatrix, cm_inv, _s.min().item()

    @torch.no_grad()
    def estimate(self, target_x):
        self.cls_model = self.cls_model.cpu()
        if self.rep_model is not None:
            target_x = self.rep_model(target_x)
        target_x = target_x.cpu().detach()
        output = self.cls_model(target_x.to(torch.float32))
        # if output.shape[0] == 0:
        #     output = torch.ones((1, self.cls_num), device=self.device) / self.cls_num
        # self.cfgs.logger(output.shape)
        pred = output.argmax(-1)
        q_count = torch.bincount(pred, minlength=self.cls_num).cpu()
        q_f = F.normalize(q_count.float(), p=1, dim=0)

        if self.use_reg:
            q_estimate = self.reg_estimate(q_f)
        else:
            q_estimate = self.cm_inv.cpu().matmul(q_f.T)

            if self.nn_clip:
                q_estimate = q_estimate.clamp(min=0)

            if self.softmax:
                q_estimate = q_estimate.softmax(dim=-1)

            if self.use_history and self.history is not None:
                q_estimate = self.history * self.smooth_ratio + q_estimate * (
                    1 - self.smooth_ratio
                )

        self.history = q_estimate
        return q_estimate

    def reg_estimate(self, q_f):
        C = self.cm.detach().numpy()
        q = q_f.detach().numpy().flatten()
        ones = np.ones(len(q))

        history = None
        if self.history is not None:
            history = self.history.detach().numpy().flatten()

        ans = cp.Variable(len(q))
        loss_func = cp.pnorm(C @ ans - q, p=2)
        if history is not None:
            loss_func += self.lamda * cp.pnorm(ans / history - ones, p=2)
        objective = cp.Minimize(loss_func)
        prob = cp.Problem(objective)

        prob.solve()

        q_estimate = torch.from_numpy(ans.value).float()

        return q_estimate
