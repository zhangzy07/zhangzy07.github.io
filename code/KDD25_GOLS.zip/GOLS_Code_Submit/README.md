# Python implementation for "Adapting to Generalized Online  Label Shift by Invariant Representation Learning"

This is the python implementation for the experiments in the paper "**Adapting to Generalized Online Label Shift by Invariant Representation Learning**". We will first introduce the structure and requirements of the code, followed by a brief instruction for a quick start.

## Code Structure

`main_gols_*.py` are the entrance of the program. The code mainly contains the following four parts:

- `online/`: Implementation of the proposed method and contenders.
- `dataset/`: Code to load and split datasets.
- `utils_pkg/`: Utilities for running.
- `offline_train/`: Utilities for offline training.

The configuration of the program is a YAML file defined by `utils_pkg/exp_config.py`, where common options are class members and algorithm-specific options should be added to `kwargs`. The design pattern of the program largely follows the factory pattern, according to the YAML file, `dataset/GOLS/wrapper.py` builds the dataset/dataloader instance, `models_pkg/wrapper.py` builds the DNN instance, `online/algorithms/GOLS/wrapper.py` builds the GOLS method instance.

## Requirements

- `torch>=2.0.0` to support script-module.
- `pip install -r requirements.txt`

## Quick Start -- Run AGOE on Amazon

1\. Download the Amazon dataset from WILDS' official python package. BTW, set environment variables for all datasets to run the code.

```bash
# set environment variables, say, in ~/.bashrc
export STREAM_WILDS_DATA_DIR=/home/Username/Codes/data/wilds/data
export STREAM_TORCHVISION_CIFAR10_DIR=/home/Username/Workspace/dataset/torchvision-cifar10
export STREAM_TORCHVISION_CIFAR100_DIR=/home/Username/Workspace/dataset/torchvision-cifar100
export STREAM_TORCHVISION_MNIST_DIR=/home/Username/Workspace/dataset/torchvision-mnist
export STREAM_TORCHVISION_FASHIONMNIST_DIR=/home/Username/Workspace/dataset/torchvision-fashionmnist
export STREAM_TORCHVISION_EUROSAT_DIR=/home/Username/Workspace/dataset/torchvision-eurosat
export STREAM_TORCHVISION_CINIC10_DIR=/home/Username/Workspace/dataset/cinic10/all
```

```python
# download from wilds
import os
STREAM_WILDS_DATA_DIR = os.environ['STREAM_WILDS_DATA_DIR']
from wilds import get_dataset
get_dataset(dataset="amazon", root_dir=STREAM_WILDS_DATA_DIR, download=True)
```

2\. Then `dataset/General/wilds1_data.py` should be able to load the dataset from the disk. **Note that `DatasetAmazonByCategory` will cache in the `__pycache__` directory, the cached csv should be preserved for reproducibility.**

3\. Load and save model as `torch.jit.ScriptModule`.

- `CodeStructure/misc/huggingface_scriptmodule.py`: convert a huggingface checkpoint to a script-module. For example, `https://huggingface.co/prajjwal1/bert-mini` is dumped as `https://anonymous.4open.science/r/GOLS_Code/demos/resource/bert_plus_rep.scriptmodule`.
- **If the model is not presented as a script-module, then its class (which is a sub-class of `torch.nn.Module`) should be available in `models_pkg/DNN_wrapper.py`.**

4\. Start running

- Offline initialization: `python main_gols_offline.py --config_path demos/GOLS/offline_amazon.yaml`
- Skyline offline training: `python main_gols_skyline.py --config_path demos/GOLS/skyline_amazon.yaml`
- GOLS online testing: `python main_gols_online.py --config_path demos/GOLS/maskVX_amazon.yaml`
- Offline and skyline will save a script-module after each epoch. You should be able to run offline and skyline by only modifying hardware configurations; You need to set `cfgs.online_cfgs.rep_model_path` and `cfgs.online_cfgs.cls_model_path` to your trained offline / skyline checkpoints to run online testing.


<!--
Preprocess FMoW's metadata csv file.

```python
'''
https://github.com/p-lambda/wilds/issues/146
2011-02-07T02:48:56.643Z -> 2011-02-07T02:48:56Z
'''
import re
FMOW_META = 'data/fmow_v1.1/rgb_metadata.csv'
with open(FMOW_META, 'r') as file:
    original_content= file.read()
with open(FMOW_META + '.backup', 'w') as file:
    file.write(original_content)
modified_content = re.sub(
    r'(/d{4}-/d{2}-/d{2}T/d{2}:/d{2}:/d{2})\./d{3}Z',
    r'/1Z',
    original_content,
)
with open(FMOW_META, 'w') as file:
    file.write(modified_content)
```
-->
