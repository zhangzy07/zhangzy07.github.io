import os, sys
import datetime
import argparse

import numpy as np
import pandas as pd
import torch
import torch.utils.data as torch_data

from torch.utils.tensorboard import SummaryWriter

from utils_pkg import exp_config
from utils_pkg import deploy
from utils_pkg.utils import collate_first2_args

from dataset.GOLS.wrapper import get_dataset
from models_pkg.wrapper import get_cls_model, get_rep_model

from offline_train.LabelShift.DNN_bbse import DNN_BBSE

# python main_gols_skyline.py --config_path demos/GOLS/skyline_amazon.yaml
# python main_gols_skyline.py --config_path demos/GOLS/skyline_iwildcam_natural.yaml

CURRENT_DATETIME = datetime.datetime.now()

parser = argparse.ArgumentParser("GOLS Experiment")
parser.add_argument("--config_path", type=str, required=True)
parser.add_argument(
    "--stage",
    type=str,
    required=False,
    default="adapt_all",
    choices=["adapt_all", "adapt_linear"],
)
args = parser.parse_args()

if __name__ == "__main__":

    cfgs = exp_config.Config(config_path=args.config_path, remark="offline")
    if cfgs.hardware_cfgs.kwargs.get("offline_train_multi_gpus", False) == True:
        multi_gpus = True
    else:
        multi_gpus = False
    num_workers = cfgs.hardware_cfgs.kwargs.get("num_workers", 8)

    deploy.set_random_seed(cfgs.seed)
    deploy.set_hardware_state(cfgs)
    train_set, test_set = get_dataset(cfgs)

    cfgs.logger(str(cfgs))

    cls_num = max(train_set.ys.max().item(), test_set.ys.max().item()) + 1
    cfgs.offline_cfgs.kwargs["cls_num"] = cls_num
    cfgs.online_cfgs.kwargs["cls_num"] = cls_num
    cfgs.logger(f"cls_num={repr(cls_num)}")

    data_info = {
        # 'dim' used only when rep_model is None
        "dim": None,
        # 'cls_num' used by Linear
        "cls_num": cls_num,
        # 'init_priors' is never used
        "init_priors": None,
    }

    offline_rep_model, _ = get_rep_model(
        cfgs,
        sub_cfgs=cfgs.offline_cfgs,
        model_type=cfgs.offline_cfgs.type,
        info=data_info,
        device=cfgs.hardware_cfgs.device,
        rep_model_name=cfgs.offline_cfgs.rep_model_name,
        rep_model_path=cfgs.offline_cfgs.rep_model_path,
    )

    offline_cls_model, _ = get_cls_model(
        cfgs,
        sub_cfgs=cfgs.offline_cfgs,
        model_type=cfgs.offline_cfgs.type,
        info=data_info,
        device=cfgs.hardware_cfgs.device,
        cls_model_name=cfgs.offline_cfgs.cls_model_name,
        cls_model_path=cfgs.offline_cfgs.cls_model_path,
    )

    offline_rep_model = offline_rep_model.to("cpu")
    offline_cls_model = offline_cls_model.to("cpu")

    train_loader = torch_data.DataLoader(
        train_set,
        collate_fn=collate_first2_args,
        batch_size=cfgs.offline_cfgs.kwargs["train_batchsize"],
        pin_memory=False,
        shuffle=True,
        num_workers=num_workers,
    )

    test_loader = torch_data.DataLoader(
        test_set,
        collate_fn=collate_first2_args,
        batch_size=cfgs.offline_cfgs.kwargs["train_batchsize"],
        pin_memory=False,
        shuffle=True,
        num_workers=num_workers,
    )

    bbse = DNN_BBSE(
        cfgs,
        offline_rep_model,
        offline_cls_model,
        train_set,
        cls_num=data_info["cls_num"],
        device=cfgs.hardware_cfgs.device,
        kwargs=cfgs.offline_cfgs.kwargs,
        train_BBSE=True,
    )

    TASK_NAME = "{}-{}-adapt_all-lr_{}".format(
        CURRENT_DATETIME.strftime("%Y-%m-%d_%H-%M-%S"),
        cfgs.offline_cfgs.rep_model_name,
        cfgs.offline_cfgs.kwargs["lr"],
    )

    cfgs.offline_cfgs.kwargs["save_path"] = os.path.join(cfgs.output_dir, TASK_NAME)

    writer = SummaryWriter(cfgs.offline_cfgs.kwargs["save_path"])

    bbse.train_skyline(
        train_loader=train_loader,
        test_loader=test_loader,
        criterion=torch.nn.CrossEntropyLoss(),
        num_epoch=cfgs.offline_cfgs.kwargs["train_epoch"],
        writer=writer,
        train_rep=True,
        multi_gpus=multi_gpus,
    )
