"""
Datasets
"""

import os

import numpy as np

from ts_datasets import datasets_module, nprecord
from ts_datasets.nprecord import nprecord_filename
from data_pkg.data import LabeledDataset


def load_one(
    dataset_name,
    domain_idx,
    num_domains,
    test=False,
    train_on_everything=False,
    *args,
    **kwargs
):
    """Load a dataset (source and target). Names must be in ts_datasets.names().

    If test=True, then load real test set. Otherwise, load validation set as
    the "test" data (for use during training and hyperparameter tuning).
    """
    # Sanity checks
    assert dataset_name in names(), dataset_name + " not a supported dataset"

    # Get dataset information
    num_classes, class_labels = datasets_module.attributes(dataset_name)

    # Get dataset tfrecord filenames
    def _path(filename):
        """Files are in ts_datasets/ subdirectory. If the file exists, return it
        as an array since we may sometimes want more than one file for a
        dataset. If it doesn't exist, ignore it (some ts_datasets don't have a test
        set for example)."""
        fn = os.path.join("../ts_datasets", "nprecords", filename)
        return [fn] if os.path.exists(fn) else []

    train_filenames = _path(nprecord_filename(dataset_name, "train"))
    train_filenames_label = _path(nprecord_filename(dataset_name, "train_label"))
    valid_filenames = _path(nprecord_filename(dataset_name, "valid"))
    valid_filenames_label = _path(nprecord_filename(dataset_name, "valid_label"))
    test_filenames = _path(nprecord_filename(dataset_name, "test"))
    test_filenames_label = _path(nprecord_filename(dataset_name, "test_label"))

    # This is used for some plots not actual training
    if train_on_everything:
        print("Warning: training dataset contains all train/valid/test data")
        train_filenames += valid_filenames + test_filenames
        train_filenames_label += valid_filenames_label + test_filenames_label
        test_filenames = []
        test_filenames_label = []
    # By default use validation data as the "test" data, unless test=True
    elif not test:
        test_filenames = valid_filenames
        test_filenames_label = valid_filenames_label
    # If test=True, then make "train" consist of both training and validation
    # data to match the original dataset.
    else:
        train_filenames += valid_filenames
        train_filenames_label += valid_filenames_label

    # Create all the train, test, evaluation, ... tf.data.Dataset objects within
    # a Dataset() class that stores them

    # dataset = Dataset(num_classes, class_labels, num_domains,
    # 				  train_filenames, test_filenames, *args, **kwargs)
    train_data, train_label = nprecord.load_nprecord(
        train_filenames, train_filenames_label
    )
    test_data, test_label = nprecord.load_nprecord(test_filenames, test_filenames_label)
    if train_data is not None:
        train_dataset = LabeledDataset(
            train_data,
            train_label,
            domain_idx=domain_idx,
            # transform=transforms.Compose([transforms.ToTensor()]),
            num_classes=num_classes,
        )
    else:
        train_dataset = None
    if test_data is not None:
        test_dataset = LabeledDataset(
            test_data,
            test_label,
            domain_idx=domain_idx,
            # transform=transforms.Compose([transforms.ToTensor()]),
            num_classes=num_classes,
        )
    else:
        test_dataset = None
    return train_dataset, test_dataset


def load_da(dataset, sources, E_delay, expected, args):
    """
    Load the source(s) and target domains

    Input:
        dataset - one of the dataset names (e.g. ucihar)
        sources - comma-separated string of source domain numbers
        target - string of target domain number

    Returns:
        [source1_dataset, source2_dataset, ...], target_dataset
    """

    # Get proper dataset names
    sources = [dataset + "_" + x for x in sources.split(",")]

    # Need to know how many domains for creating the proper-sized model, etc.
    num_domains = len(sources)

    # Check they're all valid
    valid_names = names()

    for s in sources:
        assert s in valid_names, "unknown source domain: " + s

    # Load each source
    # source_datasets = []
    train_datasets = []
    test_datasets = []
    for domain_idx, s in enumerate(sources):
        train_dataset, test_dataset = load_one(s, domain_idx, num_domains)
        train_datasets.append(train_dataset)
        test_datasets.append(test_dataset)

    # Check that they all have the same number of classes as the first one
    for i in range(1, len(train_datasets)):
        assert train_datasets[i].num_classes == train_datasets[0].num_classes, (
            "Domain " + str(i) + " has different # of classes than dource 0"
        )

    # simulate delayed dataset
    # delay = 3
    if not expected:
        received_datasets = [None] * E_delay + train_datasets
    else:
        # receives = [None] * (len(train_datasets) + E_delay + 10)
        # received_datasets = []
        # for i in range(len(train_datasets)):
        # 	tmp = np.random.randint(E_delay - 2, E_delay + 3)  # stochastic delays
        # 	if receives[i + tmp] is None:
        # 		receives[i + tmp] = [train_datasets[i]]
        # 	else:
        # 		receives[i + tmp].append(train_datasets[i])
        #
        # for i, rs in enumerate(receives):
        # 	if i < E_delay and rs is None:
        # 		received_datasets.append(None)
        # 		continue
        # 	if rs:
        # 		for r in rs:
        # 			received_datasets.append(r)

        T = len(train_datasets)
        delays = []
        x_or_y_delay = []
        # E_delay = args.delay
        for i in range(T):
            tmp = np.random.randint(E_delay - 2, E_delay + 3)
            delays.append(tmp)
            if np.random.rand() > 0.8:
                x_or_y_delay.append(0)
            else:
                x_or_y_delay.append(1)
                # x_or_y_delay.append(np.random.randint(0, 2))  # 0 means x delay and 1 means y delay

        ys = [None] * (len(train_datasets) + E_delay + 5)
        xs = [None] * (len(train_datasets) + E_delay + 5)
        for i in range(T):
            if x_or_y_delay[i] == 0:
                if xs[i + delays[i]] is None:
                    xs[i + delays[i]] = [train_datasets[i]]
                else:
                    xs[i + delays[i]].append(train_datasets[i])
            else:
                if ys[i + delays[i]] is None:
                    ys[i + delays[i]] = [train_datasets[i]]
                else:
                    ys[i + delays[i]].append(train_datasets[i])

        train_datas = [None] * len(train_datasets)
        received_datas = [None] * len(train_datasets)

        for i in range(
            len(train_datasets)
        ):  # guarantee for every t, at least one part is received
            if x_or_y_delay[i] == 0:
                received_datas[i] = train_datasets[i]  # received y
            else:
                train_datas[i] = train_datasets[i]  # received x

        last_x = 0
        last_y = 0
        for i in range(len(train_datasets)):
            if train_datas[i] is None:
                for j in range(last_x, i + E_delay):
                    # for j in range(0, len(train_datasets)):
                    find = False
                    if xs[j] is not None:
                        for k in range(len(xs[j])):
                            if xs[j][k] not in train_datas and xs[j][k].domain_idx <= i:
                                train_datas[i] = xs[j][k]
                                find = True
                                last_x = j
                                break
                    if find:
                        break
            if received_datas[i] is None:
                for j in range(last_y, i + E_delay):
                    # for j in range(i, len(train_datasets)):
                    find = False
                    if ys[j] is not None:
                        for k in range(len(ys[j])):
                            if (
                                ys[j][k] not in received_datas
                                and ys[j][k].domain_idx <= i
                            ):
                                received_datas[i] = ys[j][k]
                                find = True
                                last_y = j
                                break
                    if find:
                        break
        return train_datasets, train_datas, received_datas


# return train_datasets, train_datasets, received_datasets


def names():
    """Returns list of all the available ts_datasets to load"""
    return datasets_module.names()


if __name__ == "__main__":
    print("Available ts_datasets:", names())

    # Example showing that the sizes and number of channels are matched
    ori1, train_datasets, received_datasets = load_da(
        "ucihhar", "1,2,3,4,5,6,7,8", E_delay=2, expected=True, args=None
    )
    ori2, train_datasets, received_datasets = load_da(
        "ucihar", "1,2,3,4,5,6,7,8", E_delay=2, expected=True, args=None
    )
    ori3, train_datasets, received_datasets = load_da(
        "wisdm_ar", "1,2,3,4,5,6,7,8", E_delay=2, expected=True, args=None
    )
    tot1 = sum([len(x) for x in ori1])
    tot2 = sum([len(x) for x in ori2])
    tot3 = sum([len(x) for x in ori3])
