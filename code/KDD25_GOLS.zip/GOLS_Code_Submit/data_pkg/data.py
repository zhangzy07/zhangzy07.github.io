import copy
import math

import torch
from torchvision import datasets, transforms

# from torchvision.transforms import ImageOps
from PIL import ImageOps

# from torch.utils.data import ConcatDataset
import numpy as np
from PIL import Image


# from mnistm import MNISTM


# def toLabeledDataset(datasets):
# 	labeled_datasets = []
#
# 	for idx, dataset in enumerate(datasets):
# 		if dataset is None:
# 			labeled_datasets.append(None)
# 			continue
#
# 		train_data = dataset.data
# 		if hasattr(dataset, 'targets'):
# 			train_label = dataset.targets
# 		else:
# 			train_label = dataset.labels
#
# 		data_transform = dataset.transform
# 		target_transform = dataset.target_transform
#
# 		ori_data = copy.deepcopy(train_data)
# 		ori_label = copy.deepcopy(train_label)
#
# 		labeled_datasets += [LabeledDataset(
# 			data=ori_data,
# 			label=ori_label,
# 			domain_idx=dataset.domain_idx,
# 			transform=data_transform,
# 			target_transform=target_transform
# 		)]
#
# 	return labeled_datasets


class LabeledDataset:
    """
    For labeled dataset
    """

    def __init__(
        self,
        data,
        label,
        domain_idx,
        num_classes=10,
        transform=None,
        target_transform=None,
        remark="",
    ):
        # self.dataset = dataset
        self.data = data
        self.labels = label
        self.transform = transform
        self.target_transform = target_transform
        self.num_classes = num_classes
        self.domain_idx = domain_idx
        self.remark = remark

    def _pre_process(self, img):  # Pre-processing one image.
        # print(len(img.shape), img.shape, img.size)
        if self.remark == "sim":
            return img

        if img.size == 3072:  # SHVN
            img = Image.fromarray(np.transpose(img, (1, 2, 0)))
            return img
        if len(img.shape) == 1 and img.shape[0] == 1024:  # protraits:
            # print('portraits')
            img = Image.fromarray(img.numpy().reshape((32, 32)), mode="L")
            return img

        if len(img.shape) == 2 and img.shape[1] == 28:  # MNIST (28, 28)
            img = Image.fromarray(img.numpy(), mode="L")
            return img
        if len(img.shape) == 3 and img.shape[1] == 28:  # MNIST-M (28, 28, 3)
            img = Image.fromarray(img.squeeze().numpy(), mode="RGB")
            return img
        if len(img.shape) == 2 and (
            img.shape[1] == 3 or img.shape[1] == 9
        ):  # TS Datasets
            return img
        return img

    def __getitem__(self, idx):
        if self.remark == "sim":
            # print(int(self.domain_idx), self.data, np.float32(self.labels))
            return self.data, self.labels, int(self.domain_idx)

        if self.remark == "sim_batch":
            # print(int(self.domain_idx), self.data, np.float32(self.labels))
            return self.data[idx], self.labels[idx], int(self.domain_idx)
        # # image = self.data[idx]
        # image = transforms.ToPILImage()(self.data[idx])
        # label = self.label[idx]
        # if self.transform is not None:
        # 	# if isinstance(image, np.ndarray):
        # 	# 	image = Image.fromarray(image)
        # 	image = self.transform(image)
        # if self.target_transform is not None:
        # 	label = self.target_transform(label)
        #
        # return image, label

        img, target = self.data[idx], int(self.labels[idx])

        # doing this so that it is consistent with all other datasets
        # to return a PIL Image

        img = self._pre_process(img)

        if self.transform is not None:
            img = self.transform(img)

        if self.target_transform is not None:
            target = self.target_transform(target)

        return img, target, int(self.domain_idx)

    def __len__(self):
        return len(self.data)


class UnlabeledDataset:
    """
    For unlabeled dataset
    """

    def __init__(self, data, transform=None):
        # self.dataset = dataset
        self.data = data
        self.transform = transform

    def __getitem__(self, idx):
        img = self.data[idx]
        # doing this so that it is consistent with all other datasets
        # to return a PIL Image
        if img.size == 3072:  # SHVN
            img = Image.fromarray(np.transpose(img, (1, 2, 0)))
        else:
            if len(img.shape) == 2:  # MNIST
                img = Image.fromarray(img.numpy(), mode="L")

        if self.transform is not None:
            img = self.transform(img)

        return img

    def __len__(self):
        return len(self.data)


def _permutate_image_pixels(image, permutation):
    if permutation is None:
        return image

    c, h, w = image.size()
    image = image.view(-1, c)
    image = image[permutation, :]
    return image.view(c, h, w)


def _colorize_grayscale_image(image):
    return ImageOps.colorize(image, (0, 0, 0), (255, 255, 255))


def get_dataset(name, train=True, permutation=None, capacity=None):
    dataset = (TRAIN_DATASETS[name] if train else TEST_DATASETS[name])()
    dataset.transform = transforms.Compose(
        [
            dataset.transform,
            transforms.Lambda(lambda x: _permutate_image_pixels(x, permutation)),
        ]
    )

    # if capacity is not None and len(dataset) < capacity:
    # 	return ConcatDataset([
    # 		copy.deepcopy(dataset) for _ in
    # 		range(math.ceil(capacity / len(dataset)))
    # 	])
    # else:
    # 	return dataset
    return dataset


def _rotate_image_pixels(image, rotation):
    if rotation is None:
        return image

    c, h, w = image.size()
    # Rotate the Image
    image = image.view(-1, c)
    image = image[rotation, :]
    return image.view(c, h, w)


def get_rotated_dataset(name, train=True, rotation=None, capacity=None):
    dataset = (TRAIN_DATASETS[name] if train else TEST_DATASETS[name])()
    dataset.transform = transforms.Compose(
        [
            dataset.transform,
            transforms.Lambda(lambda x: _rotate_image_pixels(x, rotation)),
        ]
    )

    # if capacity is not None and len(dataset) < capacity:
    # 	return ConcatDataset([
    # 		copy.deepcopy(dataset) for _ in
    # 		range(math.ceil(capacity / len(dataset)))
    # 	])
    # else:
    # 	return dataset
    return dataset


# mean = np.array([0.5, 0.5, 0.5])
# std = np.array([0.5, 0.5, 0.5])

_MNIST_TRAIN_TRANSFORMS = _MNIST_TEST_TRANSFORMS = [
    transforms.ToTensor(),
    transforms.ToPILImage(),
    transforms.Pad(2),
    transforms.ToTensor(),
    # transforms.Normalize(mean, std)
]

_MNIST_COLORIZED_TRAIN_TRANSFORMS = _MNIST_COLORIZED_TEST_TRANSFORMS = [
    transforms.ToTensor(),
    transforms.ToPILImage(),
    transforms.Lambda(lambda x: _colorize_grayscale_image(x)),
    transforms.Pad(2),
    transforms.ToTensor(),
    # transforms.Normalize(mean, std)
]

_CIFAR_TRAIN_TRANSFORMS = _CIFAR_TEST_TRANSFORMS = [
    transforms.ToTensor(),
]

_SVHN_TRAIN_TRANSFORMS = _SVHN_TEST_TRANSFORMS = [
    transforms.ToTensor(),
    # transforms.Normalize(mean, std)
]
_SVHN_TARGET_TRANSFORMS = [
    transforms.Lambda(lambda y: y % 10),
]

_MNIST_M_TRAIN_TRANSFORMS = _MNIST_M_TEST_TRANSFORMS = [
    transforms.ToTensor(),
    transforms.ToPILImage(),
    transforms.Pad(2),
    transforms.ToTensor(),
]

_PORTRAITS_TRAIN_TRANSFORMS = _MNIST_M_TEST_TRANSFORMS = [
    transforms.ToTensor(),
    transforms.ToPILImage(),
    transforms.Pad(2),
    transforms.ToTensor(),
]

TRAIN_DATASETS = {
    # 'mnist': lambda: datasets.MNIST(
    # 	'./datasets/mnist', train=True, download=True,
    # 	transform=transforms.Compose(_MNIST_TRAIN_TRANSFORMS)
    # ),
    # 'mnist-color': lambda: datasets.MNIST(
    # 	'./datasets/mnist', train=True, download=True,
    # 	transform=transforms.Compose(_MNIST_COLORIZED_TRAIN_TRANSFORMS)
    # ),
    "cifar10": lambda: datasets.CIFAR10(
        "./datasets/cifar10",
        train=True,
        download=True,
        transform=transforms.Compose(_CIFAR_TRAIN_TRANSFORMS),
    ),
    "cifar100": lambda: datasets.CIFAR100(
        "./datasets/cifar100",
        train=True,
        download=True,
        transform=transforms.Compose(_CIFAR_TRAIN_TRANSFORMS),
    ),
    "svhn": lambda: datasets.SVHN(
        "./datasets/svhn",
        split="train",
        download=True,
        transform=transforms.Compose(_SVHN_TRAIN_TRANSFORMS),
        target_transform=transforms.Compose(_SVHN_TARGET_TRANSFORMS),
    ),
    # 'mnist-m': lambda: MNISTM(
    # 	train=True,
    # 	transform=transforms.Compose(_MNIST_M_TRAIN_TRANSFORMS)
    # ),
}

TEST_DATASETS = {
    # 'mnist': lambda: datasets.MNIST(
    # 	'./datasets/mnist', train=False,
    # 	transform=transforms.Compose(_MNIST_TEST_TRANSFORMS)
    # ),
    # 'mnist-color': lambda: datasets.MNIST(
    # 	'./datasets/mnist', train=False, download=True,
    # 	transform=transforms.Compose(_MNIST_COLORIZED_TEST_TRANSFORMS)
    # ),
    "cifar10": lambda: datasets.CIFAR10(
        "./datasets/cifar10",
        train=False,
        transform=transforms.Compose(_CIFAR_TEST_TRANSFORMS),
    ),
    "cifar100": lambda: datasets.CIFAR100(
        "./datasets/cifar100",
        train=False,
        transform=transforms.Compose(_CIFAR_TEST_TRANSFORMS),
    ),
    # 'svhn': lambda: datasets.SVHN(
    # 	'./datasets/svhn', split='test', download=True,
    # 	transform=transforms.Compose(_SVHN_TEST_TRANSFORMS),
    # 	target_transform=transforms.Compose(_SVHN_TARGET_TRANSFORMS),
    # ),
    # 'mnist-m': lambda: MNISTM(
    # 	train=False,
    # 	transform=transforms.Compose(_MNIST_M_TEST_TRANSFORMS)
    # ),
}

DATASET_CONFIGS = {
    "mnist": {"size": 32, "channels": 1, "classes": 10},
    "mnist-color": {"size": 32, "channels": 3, "classes": 10},
    "cifar10": {"size": 32, "channels": 3, "classes": 10},
    "cifar100": {"size": 32, "channels": 3, "classes": 100},
    "svhn": {"size": 32, "channels": 3, "classes": 10},
    "mnist-m": {"size": 32, "channels": 3, "classes": 10},
    "ucihar": {"size": 128, "channels": 9, "classes": 6},
    "ucihhar": {"size": 128, "channels": 3, "classes": 6},
    "uwave": {"size": 128, "channels": 3, "classes": 8},
    "wisdm_ar": {"size": 315, "channels": 3, "classes": 6},
    "portraits": {"size": 32, "channels": 1, "classes": 2},
    "simulated": {"size": 5, "channels": 1, "classes": 1},
    "loan": {"size": 78, "channels": 1, "classes": 2},
    "syn": {"size": 2, "channels": 1, "classes": 4},
    "iot": {"size": 115, "channels": 1, "classes": 11},
}
