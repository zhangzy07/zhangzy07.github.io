import copy

import pandas as pd
import time
import numpy as np
from tqdm import tqdm

from data_pkg.load_loan_data import dat_to_num
from utils_pkg.utils import sortByKey

if __name__ == "__main__":
    t0 = time.time()
    df_ori = pd.read_csv("./dataset/preData_loan.csv")  # [1382351 rows x 98 columns]
    print("Read preData_loan.csv finished.", time.time() - t0)  # about 8 s

    # labels = df[['loan_status_risk_type']].to_numpy().reshape(len(df))

    issue_ds = df_ori["issue_d"].values

    dat_num = [None] * len(issue_ds)

    idxs = list(range(len(df_ori)))

    df = copy.deepcopy(df_ori)
    df[["term"]] = df[["term"]].fillna("36")
    df["term"] = df["term"].str.replace(" months", "")
    df["term"] = df["term"].astype("int")

    for i, dat in tqdm(enumerate(issue_ds), desc="Convert date to num"):
        dat_num[i] = dat_to_num(dat)

    idxs = sortByKey(dat_num, idxs)
    # Down Sampling:

    # indices = list(range(15000, len(df_ori)))
    # np.random.shuffle(indices)
    # indices = indices[:60000]
    # indices = sorted(indices)
    # indices = list(range(15000)) + indices
    indices = list(range(70000))
    idxs = list(np.array(idxs)[indices])
    idxs = sorted(idxs)
    df_sub = df_ori.iloc[idxs]

    df_sub.to_csv("preData_loan_subsampling.csv", index=False)

    print("Save down-sampling dataset finished.")
