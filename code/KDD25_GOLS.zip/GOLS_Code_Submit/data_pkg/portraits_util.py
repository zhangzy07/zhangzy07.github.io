import numpy as np
import torch
from scipy import io
from torchvision import transforms

from data_pkg.data import LabeledDataset


def shuffle(xs, ys):
    indices = list(range(len(xs)))
    np.random.shuffle(indices)
    return xs[indices], ys[indices]


def get_datasets(filename, t_u):
    X, Y = load_portraits_data(filename, t_u)

    train_datasets = []
    test_datasets = []
    dataset_num = len(t_u)

    s_point = 0
    for i in range(dataset_num):
        test_num = t_u[i] // 10
        train_dataset = LabeledDataset(
            X[s_point : s_point + t_u[i] - test_num],
            Y[s_point : s_point + t_u[i] - test_num],
            domain_idx=i,
            transform=transforms.Compose(_PORTRAITS_TRAIN_TRANSFORMS),
            num_classes=2,
        )

        test_dataset = LabeledDataset(
            X[s_point + t_u[i] - test_num : s_point + t_u[i]],
            Y[s_point + t_u[i] - test_num : s_point + t_u[i]],
            domain_idx=i,
            transform=transforms.Compose(_PORTRAITS_TRAIN_TRANSFORMS),
            num_classes=2,
        )

        s_point += t_u[i]

        train_datasets.append(train_dataset)
        test_datasets.append(test_dataset)

    for i in range(1, len(train_datasets)):
        assert train_datasets[i].num_classes == train_datasets[0].num_classes, (
            "Domain " + str(i) + " has different # of classes than dource 0"
        )

    return train_datasets, test_datasets


def load_portraits_data(filename, t_u):
    interval = 12000
    data = io.loadmat(filename)
    xs = np.squeeze(data["Xs"])
    ys = data["Ys"][0]
    num_domains = len(t_u)
    num = sum(t_u)
    idx = 0
    X = []
    Y = []
    for i in range(num_domains):
        shuffled = shuffle(xs[idx : idx + t_u[i]], ys[idx : idx + t_u[i]])
        X = X + [shuffled[0]]
        Y = Y + [shuffled[1]]
        print("Domain", i, "image indices range from", idx, "to", idx + t_u[i] - 1)
        idx += interval
    X = np.concatenate(X)
    Y = np.concatenate(Y)

    return torch.reshape(torch.from_numpy(X), (num, -1)), torch.from_numpy(Y).long()


_PORTRAITS_TRAIN_TRANSFORMS = _MNIST_M_TEST_TRANSFORMS = [
    transforms.ToTensor(),
    transforms.ToPILImage(),
    # transforms.Pad(2),
    transforms.ToTensor(),
]
if __name__ == "__main__":
    config = "2"
    if config == "0":
        t_u = [512, 256, 128, 64, 32]
    elif config == "1":
        t_u = [32, 64, 128, 256, 512]
    else:
        t_u = [200, 200, 200, 200, 200]
    X, Y = load_portraits_data("datasets/portraits/dataset_32x32.mat", t_u)

    from matplotlib import pyplot as plt

    plt.imshow(X[1].reshape((32, 32)), interpolation="nearest")
    plt.show()
