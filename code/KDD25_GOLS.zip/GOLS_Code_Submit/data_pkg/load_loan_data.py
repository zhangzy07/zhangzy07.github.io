import pandas as pd
import time
import numpy as np
from sklearn.linear_model import LogisticRegression
from tqdm import tqdm, trange

from data_pkg.data import LabeledDataset
from utils_pkg.utils import sortByKey

from sklearn.metrics import log_loss


def load_data():
    t0 = time.time()
    # df = pd.read_csv('./dataset/preData_loan.csv')  # [1382351 rows x 98 columns]
    df = pd.read_csv(
        "./dataset/preData_loan_subsampling.csv"
    )  # [downsample x 98 columns]
    print("Read preData_loan.csv finished.", time.time() - t0)  # about 8 s

    train_datasets = []
    receive_datasets = []

    issue_ds = df["issue_d"].values

    dat_num = [None] * len(issue_ds)

    df[["term"]] = df[["term"]].fillna("36")
    df["term"] = df["term"].str.replace(" months", "")
    df["term"] = df["term"].astype("int")

    for i, dat in tqdm(enumerate(issue_ds), desc="Convert date to num"):
        dat_num[i] = dat_to_num(dat)

    issue_ds = sortByKey(dat_num, issue_ds)

    date2id_dic = {}
    id2date_dic = {}

    id = 0
    for dat in issue_ds:
        if dat not in date2id_dic.keys():
            date2id_dic[dat] = id
            id2date_dic[id] = dat
            id += 1
    big_T = len(date2id_dic)

    # calculate the receive months of the labels
    issues = df["issue_d"].tolist()
    terms = df["term"].tolist()  # where term feature is the delay of the loan
    receive_date = []
    for i, term in enumerate(terms):
        receive_date.append(date2id_dic[issues[i]] + term)
    receive_date = np.array(receive_date)

    df = df.fillna(0)

    # delete features from future (invalid features)
    del_cols = [
        "loan_status",
        "loan_status_risk_type",
        "loan_status_le",
        "issue_d",
        "total_pymnt",
        "total_pymnt_inv",
        "total_rec_int",
        "total_rec_late_fee",
        "total_rec_prncp",
        "out_prncp",
        "out_prncp_inv",
        "recoveries",
        "collection_recovery_fee",
        "collections_12_mths_ex_med",
        "debt_settlement_flag",
        "last_pymnt_amnt",
        "next_pymnt_d",
        "last_fico_range_high",
        "last_fico_range_low",
    ]

    # Full dataset result (logistic regression):
    # THRESHOLD = 0.75
    # prob = model.predict_proba(X_test)[:, 1]
    # y_pred = np.where(prob > THRESHOLD, 1, 0)
    #
    # print(classification_report(y_test, y_pred))
    # print(roc_auc_score(y_test, prob))

    # 	              precision    recall  f1-score   support
    #
    #            0       0.39      0.57      0.46     76588
    #            1       0.86      0.74      0.80    269000
    #
    #     accuracy                           0.70    345588
    #    macro avg       0.62      0.65      0.63    345588
    # weighted avg       0.75      0.70      0.72    345588
    #
    # AUROC: 0.719142362708165
    # print(np.mean(label))  # 0.78

    # df = df.drop(columns=del_cols)

    labels = df[["loan_status_risk_type"]].to_numpy().reshape(len(df))
    datas = df.drop(columns=del_cols).to_numpy().astype(float)
    datas = datas / (datas.max(0) + 1e-16)

    model = LogisticRegression(solver="lbfgs")
    model.fit(datas, labels)
    # prob = model.predict_proba(datas)[:, 1]
    errs = []
    # celoss = torch.nn.CrossEntropyLoss()

    # print(celoss(torch.tensor(model.predict_proba(datas)).to(torch.float32),
    # 			 torch.tensor(labels).to(torch.long)).item())

    print("Best avg loss", log_loss(labels, model.predict_proba(datas)))

    for i in trange(big_T):
        idxs = (df["issue_d"] == id2date_dic[i]).to_numpy()
        label_tmp = labels[idxs].astype(int)
        data_tmp = np.float32(datas[idxs])
        train_datasets.append(LabeledDataset(data_tmp, label_tmp, i, num_classes=2))
        tmp_loss = log_loss(label_tmp, model.predict_proba(data_tmp))
        if i <= 36:
            tmp_loss *= min(1024, len(label_tmp) // 2)
        else:
            tmp_loss *= min(1024, len(label_tmp))
        errs.append(tmp_loss)  # 640 = 64 * 10, batch_size

    for i in range(big_T + 36):
        idxs = receive_date == i
        label_tmp = labels[idxs].astype(int)
        data_tmp = np.float32(datas[idxs])
        dataset = LabeledDataset(data_tmp, label_tmp, i - 36, num_classes=2)

        receive_datasets.append(dataset if len(dataset) > 0 else None)

    return train_datasets, train_datasets, receive_datasets, errs


def dat_to_num(dat):
    dic = {}
    dic["Jan"] = 1
    dic["Feb"] = 2
    dic["Mar"] = 3
    dic["Apr"] = 4
    dic["May"] = 5
    dic["Jun"] = 6
    dic["Jul"] = 7
    dic["Aug"] = 8
    dic["Sep"] = 9
    dic["Oct"] = 10
    dic["Nov"] = 11
    dic["Dec"] = 12
    return int(dat[-4:]) * 100 + dic[dat[:3]]


if __name__ == "__main__":
    o, t, r, e = load_data()
