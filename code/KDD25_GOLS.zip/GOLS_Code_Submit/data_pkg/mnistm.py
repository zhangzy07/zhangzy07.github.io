import os

import torch
from PIL import Image
from torchvision import transforms

from utils_pkg import utils


class MNISTM:
    """MNIST-M Dataset."""

    training_file = "mnist_m_train.pt"
    test_file = "mnist_m_test.pt"
    classes = [
        "0 - zero",
        "1 - one",
        "2 - two",
        "3 - three",
        "4 - four",
        "5 - five",
        "6 - six",
        "7 - seven",
        "8 - eight",
        "9 - nine",
    ]

    def __init__(
        self, root="./datasets", train=True, transform=None, target_transform=None
    ):
        """Init MNIST-M dataset."""
        # super(MNISTM, self).__init__(transform=transform, target_transform=target_transform)
        self.root = root
        self.train = train
        self.transform = transform
        self.target_transform = target_transform
        # if download:
        # 	self.download()

        if not self._check_exists():
            raise RuntimeError("Dataset not found." + " You can download it on GitHub!")

        if self.train:
            data_file = self.training_file
        else:
            data_file = self.test_file

        print(os.path.join(self.processed_folder, data_file))

        self.data, self.targets = torch.load(
            os.path.join(self.processed_folder, data_file)
        )

    def __getitem__(self, index):
        """Get images and target for data loader.
        Args:
            index (int): Index
        Returns:
            tuple: (image, target) where target is index of the target class.
        """
        img, target = self.data[index], int(self.targets[index])

        # doing this so that it is consistent with all other datasets
        # to return a PIL Image
        img = Image.fromarray(img.squeeze().numpy(), mode="RGB")

        if self.transform is not None:
            img = self.transform(img)

        if self.target_transform is not None:
            target = self.target_transform(target)

        return img, target

    def __len__(self):
        """Return size of dataset."""
        return len(self.data)

    @property
    def raw_folder(self):
        return os.path.join(self.root, self.__class__.__name__, "raw")

    @property
    def processed_folder(self):
        return os.path.join(self.root, self.__class__.__name__, "processed")

    @property
    def class_to_idx(self):
        return {_class: i for i, _class in enumerate(self.classes)}

    def _check_exists(self):
        return os.path.exists(
            os.path.join(self.processed_folder, self.training_file)
        ) and os.path.exists(os.path.join(self.processed_folder, self.test_file))

    def extra_repr(self):
        return "Split: {}".format("Train" if self.train is True else "Test")


if __name__ == "__main__":

    _MNIST_M_COLORIZED_TRAIN_TRANSFORMS = _MNIST_M_COLORIZED_TEST_TRANSFORMS = [
        transforms.ToTensor(),
        transforms.ToPILImage(),
        transforms.Pad(2),
        transforms.ToTensor(),
    ]
    mn = MNISTM(
        train=True, transform=transforms.Compose(_MNIST_M_COLORIZED_TRAIN_TRANSFORMS)
    )
    mn_test = MNISTM(
        train=False, transform=transforms.Compose(_MNIST_M_COLORIZED_TEST_TRANSFORMS)
    )
    mn_loader = utils.get_data_loader(mn, batch_size=32)
    for data, targets in mn_loader:
        break

    for i in range(32):
        img = data[i]
        toPIL = transforms.ToPILImage()
        # img = torch.randn(3, 128, 64)
        pic = toPIL(img)
        pic.save("random_{}.jpg".format(i))
