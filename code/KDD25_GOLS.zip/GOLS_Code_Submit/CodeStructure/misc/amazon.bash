ROOT=/home/Username/Workspace/StreamData
PYTHON=/home/Username/anaconda3/envs/stream/bin/python

function gols_online () {
    data=$1; algo=$2; seed=$3; gpu=$4; lr=$5; ur=$6;
    echo "data=$data, algo=$algo, seed=$seed, gpu=$gpu, learning_rate=$lr, update_rounds=$ur"
    cd $ROOT
    $PYTHON main_gols_online.py \
        --config_path demos/GOLS/"$algo"_"$data".yaml --force_random_seed $seed \
        --force_gpu_ids $gpu --force_online_lr $lr --force_update_rounds $ur \
        </dev/null &>paper_result/"$data"_ur"$ur"_lr"$lr"_"$algo"_seed"$seed".log
}

function gpu_0 () {
    #               data    algo    seed    gpu     lr      ur
    gols_online     amazon  gem     1       0       1e-4    64
    gols_online     amazon  gem     2       0       1e-4    64
    gols_online     amazon  gem     3       0       1e-4    64
    gols_online     amazon  gem     4       0       1e-4    64
}
function gpu_1 () {
    #               data    algo    seed    gpu     lr      ur
    gols_online     amazon  agem    1       1       1e-4    64
    gols_online     amazon  agem    2       1       1e-4    64
    gols_online     amazon  agem    3       1       1e-4    64
    gols_online     amazon  agem    4       1       1e-4    64
}
function gpu_2 () {
    #               data    algo    seed    gpu     lr      ur
    gols_online     amazon  ccsa    1       2       1e-4    64
    gols_online     amazon  ccsa    2       2       1e-4    64
    gols_online     amazon  ccsa    3       2       1e-4    64
    gols_online     amazon  ccsa    4       2       1e-4    64
}
function gpu_3 () {
    #               data    algo    seed    gpu     lr      ur
    gols_online     amazon  dann    1       3       1e-4    64
    gols_online     amazon  dann    2       3       1e-4    64
    gols_online     amazon  dann    3       3       1e-4    64
    gols_online     amazon  dann    4       3       1e-4    64
}
function gpu_4 () {
    #               data    algo    seed    gpu     lr      ur
    gols_online     amazon  maskV   1       4       1e-4    64
    gols_online     amazon  maskV   2       4       1e-4    64
    gols_online     amazon  maskV   3       4       1e-4    64
    gols_online     amazon  maskV   4       4       1e-4    64
}
function gpu_5 () {
    #               data    algo    seed    gpu     lr      ur
    gols_online     amazon  maskVX  1       5       1e-4    64
    gols_online     amazon  maskVX  2       5       1e-4    64
    gols_online     amazon  maskVX  3       5       1e-4    64
    gols_online     amazon  maskVX  4       5       1e-4    64
}
function gpu_6 () {
    # while ps ux | grep 1456678 | grep gols_online &>/dev/null
    # do
    #     date +'[%Y-%m-%d %H:%M:%S] gpu_6 waiting...'
    #     sleep 60
    # done
    #               data    algo    seed    gpu     lr      ur
    gols_online     amazon  ogd     0       6       5e-5    64
    gols_online     amazon  ogd     1       6       5e-5    64
    gols_online     amazon  ogd     2       6       5e-5    64
    gols_online     amazon  ogd     3       6       5e-5    64
    gols_online     amazon  ogd     4       6       5e-5    64
}
# function gpu_7 () {
#     #               data    algo    seed    gpu     lr      ur
#     gols_online     amazon  ogd     1       7       1e-5    64
#     gols_online     amazon  ogd     2       7       1e-5    64
#     gols_online     amazon  ogd     3       7       1e-5    64
#     gols_online     amazon  ogd     4       7       1e-5    64
# }
function gpu_7 () {
    #               data    algo    seed    gpu     lr      ur
    gols_online     amazon  ogd1    0       7       1e-4    64
    gols_online     amazon  ogd1    1       7       1e-4    64
    gols_online     amazon  ogd1    2       7       1e-4    64
    gols_online     amazon  ogd1    3       7       1e-4    64
    gols_online     amazon  ogd1    4       7       1e-4    64
}
# gpu_0 &
# gpu_1 &
# gpu_2 &
# gpu_3 &
# gpu_4 &
# gpu_5 &
# gpu_6 &
gpu_7 &
