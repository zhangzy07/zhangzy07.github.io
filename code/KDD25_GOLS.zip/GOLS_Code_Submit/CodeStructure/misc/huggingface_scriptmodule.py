import torch

from transformers import BertModel, MobileNetV2Model


"""
bert-tiny -> bert[_rep]
bert-mini -> bert_plus[_rep]
"""

# # https://huggingface.co/prajjwal1/bert-tiny
# hf_bert = BertModel.from_pretrained("/home/Username/Workspace/huggingface/bert-tiny")  # 127.0.0.1

# https://huggingface.co/prajjwal1/bert-mini
hf_bert = BertModel.from_pretrained(
    "/home/Username/Workspace/huggingface/bert-mini"
)  # 127.0.0.1

# https://huggingface.co/google/mobilenet_v2_0.35_96
hf_mnet = MobileNetV2Model.from_pretrained(
    "/home/Username/Workspace/huggingface/mobilenet_v2_0.35_96"
)  # 127.0.0.1


class _BERT_rep(torch.nn.Module):
    """transformers/models/bert/modeling_bert.py"""

    def __init__(self):
        super(_BERT_rep, self).__init__()
        self.embeddings = hf_bert.embeddings
        self.encoder = hf_bert.encoder
        self.pooler = hf_bert.pooler

    def forward(self, x):
        x = self.embeddings(x)
        x = self.encoder(x)
        x = self.pooler(x[0])
        return x


class _MobileNet1_rep(torch.nn.Module):
    """transformers/models/mobilenet_v2/modeling_mobilenet_v2.py"""

    def __init__(self):
        super(_MobileNet1_rep, self).__init__()
        self.conv_stem = hf_mnet.conv_stem
        self.layer = hf_mnet.layer
        self.conv_1x1 = hf_mnet.conv_1x1
        self.pooler = hf_mnet.pooler

    def forward(self, x):
        x = self.conv_stem(x)
        for layer_module in self.layer:
            x = layer_module(x)
        x = self.conv_1x1(x)
        x = self.pooler(x)
        x = torch.flatten(x, start_dim=1)
        return x


BATCH_SIZE = 8

bert = _BERT_rep()
x = torch.randint(0, 30522, (BATCH_SIZE, 512))
traced_bert = torch.jit.trace(bert, x)
scripted_bert = torch.jit.script(traced_bert)
scripted_bert.save("demos/resource/bert_plus_rep.scriptmodule")

mnet = _MobileNet1_rep()
x = torch.rand((BATCH_SIZE, 3, 96, 96))
traced_mnet = torch.jit.trace(mnet, x)
scripted_mnet = torch.jit.script(traced_mnet)
scripted_mnet.save("demos/resource/mobile_net_rep.scriptmodule")


BATCH_SIZE = 16

bert = torch.jit.load("demos/resource/bert_plus_rep.scriptmodule")
x = torch.randint(0, 30522, (BATCH_SIZE, 512))
y = bert(x)
print("bert:", x.shape, "->", y.shape)

mnet = torch.jit.load("demos/resource/mobile_net_rep.scriptmodule")
x = torch.rand((BATCH_SIZE, 3, 96, 96))
y = mnet(x)
print("mnet:", x.shape, "->", y.shape)

# bert: torch.Size([16, 512]) -> torch.Size([16, 128])
# mnet: torch.Size([16, 3, 96, 96]) -> torch.Size([16, 1280])
