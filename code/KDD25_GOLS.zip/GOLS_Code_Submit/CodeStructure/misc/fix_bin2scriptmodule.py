"""
python CodeStructure/misc/fix_bin2scriptmodule.py --sm_path demos/resource/bert_rep.scriptmodule --dir_of_bin output/2024-04-30_11-21-15-Bert_rep_20_percent-adapt_all-lr_0.0001
python CodeStructure/misc/fix_bin2scriptmodule.py --sm_path demos/resource/mobile_net_rep.scriptmodule --dir_of_bin output/2024-04-30_11-22-30-MobileNetV2_rep_20_percent-adapt_all-lr_1e-05
"""

import os, argparse
import torch


pasrser = argparse.ArgumentParser()
pasrser.add_argument("--sm_path", required=True, help="pretrained scriptmodule path")
pasrser.add_argument(
    "--dir_of_bin", required=True, help="directory of cls_model_epoch_*.bin"
)
args = pasrser.parse_args()

sm_path = args.sm_path
assert os.path.isfile(sm_path)
dir_of_bin = args.dir_of_bin
assert os.path.isdir(dir_of_bin)

for n in sorted(os.listdir(dir_of_bin)):
    if n.startswith("rep_model_epoch_"):
        wrong_path = os.path.join(dir_of_bin, n)
        right_path = wrong_path.replace(".bin", ".scriptmodule")

        print(
            os.path.basename(wrong_path), "->", os.path.basename(right_path), flush=True
        )

        wrong_weight = torch.load(wrong_path, map_location="cpu")
        right_weight = torch.jit.load(sm_path).to("cpu")

        right_weight.load_state_dict(wrong_weight)
        right_weight.save(right_path)
