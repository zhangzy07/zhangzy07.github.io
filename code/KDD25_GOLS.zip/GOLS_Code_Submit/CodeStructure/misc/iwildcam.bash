ROOT=/home/Username/Workspace/StreamDataDup
PYTHON=/home/Username/anaconda3/envs/stream/bin/python

function gols_online () {
    data=$1; algo=$2; seed=$3; gpu=$4; lr=$5; ur=$6;
    echo "data=$data, algo=$algo, seed=$seed, gpu=$gpu, learning_rate=$lr, update_rounds=$ur"
    cd $ROOT
    $PYTHON main_gols_online.py \
        --config_path demos/GOLS/"$algo"_"$data".yaml --force_random_seed $seed \
        --force_gpu_ids $gpu --force_online_lr $lr --force_update_rounds $ur \
        </dev/null &>paper_result/"$data"_ur"$ur"_lr"$lr"_"$algo"_seed"$seed".log
}

function gpu_0 () {
    #               data                algo    seed    gpu     lr      ur
    gols_online     iwildcam_natural    gem     0       0       1e-3    128
    gols_online     iwildcam_natural    gem     1       0       1e-3    128
    gols_online     iwildcam_natural    gem     2       0       1e-3    128
    gols_online     iwildcam_natural    gem     3       0       1e-3    128
    gols_online     iwildcam_natural    gem     4       0       1e-3    128
}
function gpu_1 () {
    #               data                algo    seed    gpu     lr      ur
    gols_online     iwildcam_natural    agem    0       1       1e-3    128
    gols_online     iwildcam_natural    agem    1       1       1e-3    128
    gols_online     iwildcam_natural    agem    2       1       1e-3    128
    gols_online     iwildcam_natural    agem    3       1       1e-3    128
    gols_online     iwildcam_natural    agem    4       1       1e-3    128
}
function gpu_2 () {
    #               data                algo    seed    gpu     lr      ur
    gols_online     iwildcam_natural    ccsa    0       2       1e-3    128
    gols_online     iwildcam_natural    ccsa    1       2       1e-3    128
    gols_online     iwildcam_natural    ccsa    2       2       1e-3    128
    gols_online     iwildcam_natural    ccsa    3       2       1e-3    128
    gols_online     iwildcam_natural    ccsa    4       2       1e-3    128
}
function gpu_3 () {
    #               data                algo    seed    gpu     lr      ur
    gols_online     iwildcam_natural    dann    0       3       1e-3    128
    gols_online     iwildcam_natural    dann    1       3       1e-3    128
    gols_online     iwildcam_natural    dann    2       3       1e-3    128
    gols_online     iwildcam_natural    dann    3       3       1e-3    128
    gols_online     iwildcam_natural    dann    4       3       1e-3    128
}
function gpu_4 () {
    #               data                algo    seed    gpu     lr      ur
    gols_online     iwildcam_natural    mask    0       4       1e-3    128
    gols_online     iwildcam_natural    mask    1       4       1e-3    128
    gols_online     iwildcam_natural    mask    2       4       1e-3    128
    gols_online     iwildcam_natural    mask    3       4       1e-3    128
    gols_online     iwildcam_natural    mask    4       4       1e-3    128
}
function gpu_5 () {
    #               data                algo    seed    gpu     lr      ur
    gols_online     iwildcam_natural    maskX   0       5       1e-3    128
    gols_online     iwildcam_natural    maskX   1       5       1e-3    128
    gols_online     iwildcam_natural    maskX   2       5       1e-3    128
    gols_online     iwildcam_natural    maskX   3       5       1e-3    128
    gols_online     iwildcam_natural    maskX   4       5       1e-3    128
}
function gpu_6 () {
    #               data                algo    seed    gpu     lr      ur
    gols_online     iwildcam_natural    ogd     0       6       5e-4    128
    gols_online     iwildcam_natural    ogd     1       6       5e-4    128
    gols_online     iwildcam_natural    ogd     2       6       5e-4    128
    gols_online     iwildcam_natural    ogd     3       6       5e-4    128
    gols_online     iwildcam_natural    ogd     4       6       5e-4    128
}
function gpu_7 () {
    #               data                algo    seed    gpu     lr      ur
    gols_online     iwildcam_natural    ogd1    0       7       1e-3    128
    gols_online     iwildcam_natural    ogd1    1       7       1e-3    128
    gols_online     iwildcam_natural    ogd1    2       7       1e-3    128
    gols_online     iwildcam_natural    ogd1    3       7       1e-3    128
    gols_online     iwildcam_natural    ogd1    4       7       1e-3    128
}
gpu_0 &
gpu_1 &
gpu_2 &
gpu_3 &
gpu_4 &
gpu_5 &
gpu_6 &
gpu_7 &
