from functools import reduce
import torch
from torch import nn, optim

from utils_pkg import utils
from torch.autograd import Function


class MLP(nn.Module):
    """
    A simple Multi-Layer Perceptron model
    """

    def __init__(self, input_dim=28, output_dim=16, hidden_dim=32):
        super(MLP, self).__init__()
        self.input_dim = input_dim
        self.output_dim = output_dim
        self.hidden_dim = hidden_dim

        self.fc1 = nn.Linear(input_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, output_dim)

        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        out = x.view(-1, self.num_flat_features(x))
        out = self.fc1(out)
        out = self.relu(out)
        out = self.fc2(out)
        return out

    def num_flat_features(self, x):
        size = x.size()[1:]
        num_features = 1
        for s in size:
            num_features *= s
        return num_features
