from models_pkg.linear import Base
import torch
import torch.nn as nn
import numpy as np
from utils_pkg.timer import Timer


class Simplex(Base):
    def __init__(self, init_priors):
        super(Simplex, self).__init__(init_priors=init_priors)
        self.init_priors = torch.Tensor(init_priors)
        self.priors = nn.Parameter(self.init_priors.clone())

    def forward(self, X):
        # X: p(y|x)
        self.init_priors = self.init_priors.to(X.device)
        out = X * self.priors / self.init_priors  # reweight
        # out = out / out.sum(dim=1).unsqueeze(-1)  # normalize

        return out

    def project(self):
        y = self.priors.data.cpu().double()
        a = torch.ones(len(y), dtype=torch.float64)
        l = y / a
        idx = torch.argsort(l)
        d = len(l)

        evalpL = (
            lambda k: torch.sum(a[idx[k:]] * (y[idx[k:]] - l[idx[k]] * a[idx[k:]])) - 1
        )

        def bisectsearch():
            idxL, idxH = 0, d - 1
            L = evalpL(idxL)
            H = evalpL(idxH)

            if L < 0:
                return idxL

            while (idxH - idxL) > 1:
                iMid = int((idxL + idxH) / 2)
                M = evalpL(iMid)

                if M > 0:
                    idxL, L = iMid, M
                else:
                    idxH, H = iMid, M

            return idxH

        k = bisectsearch()

        lam = (torch.sum(a[idx[k:]] * y[idx[k:]]) - 1) / torch.sum(a[idx[k:]])

        x = torch.maximum(torch.tensor(0.0), y - lam * a)
        x = x.to(self.priors.device)
        self.priors = nn.Parameter(x)


def proj(y):
    a = np.ones(len(y)).astype(int)
    y = np.array(y)
    l = y / a
    idx = np.argsort(l)
    d = len(l)

    evalpL = lambda k: np.sum(a[idx[k:]] * (y[idx[k:]] - l[idx[k]] * a[idx[k:]])) - 1

    def bisectsearch():
        idxL, idxH = 0, d - 1
        L = evalpL(idxL)
        H = evalpL(idxH)

        if L < 0:
            return idxL

        while (idxH - idxL) > 1:
            iMid = int((idxL + idxH) / 2)
            M = evalpL(iMid)

            if M > 0:
                idxL, L = iMid, M
            else:
                idxH, H = iMid, M

        return idxH

    k = bisectsearch()

    lam = (np.sum(a[idx[k:]] * y[idx[k:]]) - 1) / np.sum(a[idx[k:]])
    # print(a[idx[k:]], y[idx[k:]])
    # print(np.sum(a[idx[k:]] * y[idx[k:]]) - 1)
    # print(y, lam)
    # print(y - lam * a)

    x = np.maximum(0, y - lam * a)

    return x


if __name__ == "__main__":
    # priors = [0.4, 0.4, 1.1]
    priors = [-1.0047e-08, -2.9507e-02, 3.8500e01, 9.7789e03, 7.1715e07, 1.0000e00]
    print(proj(priors))
    print("----------------------------")
    # exit()
    simplex = Simplex(priors)
    simplex = simplex.cuda()
    timer_helper = Timer()
    timer_helper.tik()
    simplex.project()
    timer_helper.tok()
    print(simplex.priors)
    # print(proj(priors))
    # print(proj_torch(priors))
