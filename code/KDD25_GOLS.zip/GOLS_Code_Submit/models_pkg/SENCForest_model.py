import numpy as np
from torch import nn

from utils_pkg import exp_config
from utils_pkg.SENC_Forest.SENCEstimation import SENCEstimation
from utils_pkg.SENC_Forest.SENCForest import SENCForest
from utils_pkg.SENC_Forest.SENCTree import GlobalVars
from utils_pkg.SENC_Forest.updatemodel import updatemodel


class SENCForest_model(nn.Module):  # rerewrite the SENCForest model for low coupling
    def __init__(self, cfgs: exp_config.Config):
        super(SENCForest_model, self).__init__()
        self.cfgs = cfgs
        self.buffer = []
        online_kwargs = cfgs.online_cfgs.kwargs
        self.online_kwargs = online_kwargs
        global_vars = GlobalVars()
        self.global_vars = global_vars
        self.buffer = []

        self.result_new = []
        self.idbuffer = []
        self.batchdatalabel = []
        # self.batchdatalabel_true = [] # this is used for evaluation
        # self.Para = {}
        self.buffersize = online_kwargs["buffersize"]

        self.sencforest = None  # need to be initialized

    def init_forest(self, source_data, source_label):
        NumTree = self.online_kwargs["NumTree"]
        NumSub = self.online_kwargs["NumSub"]
        NumDim = self.online_kwargs["NumDim"]
        rseed = self.cfgs.seed

        source_data = source_data.cpu().numpy()
        source_label = source_label.cpu().numpy()

        self.sencforest = SENCForest(
            source_data, NumTree, NumSub, NumDim, rseed, source_label, self.global_vars
        )

    def get_feature(self, x):
        return x

    # def to(self, device):
    #     if device != 'cpu':
    #         raise 'SENC Forest model is only supported on CPU'
    #     return self

    # def cpu(self):
    #     return self

    def update_tree(self):
        if len(self.buffer) >= self.buffersize:
            self.sencforest = updatemodel(
                np.vstack(self.buffer),
                self.sencforest,
                np.array(self.batchdatalabel),
                np.vstack(self.idbuffer),
                self.global_vars,
            )

            # batchdatalabel = []
            self.idbuffer = []
            self.buffer = []

    def forward(self, target_data, newclasslabel):

        Mass, mtimetest = SENCEstimation(
            target_data,
            self.sencforest,
            self.online_kwargs["alpha"],
            self.sencforest.anomaly,
            self.global_vars,
        )
        #     Mass[:, 0]--pathline;
        #     Mass[:, 1]--distance
        #     Mass[:, 2]--label
        #     Mass[:, 3]--id to go
        #     Mass[:, 4]--new class or not
        answermass = Mass[:, 2]
        answermass[np.where(Mass[:, 4] == 1)] = newclasslabel
        Score = np.array(np.unique(answermass, return_counts=True)).T
        Score_1 = Score[Score[:, 1].argmax()]

        if Score_1[0] == newclasslabel:
            self.buffer.append(target_data)
            self.idbuffer.append(Mass[:, 3])
            # idbuffer = np.hstack((idbuffer, Mass[:, 3]))
            self.batchdatalabel.append(newclasslabel)
            # self.batchdatalabel_true.append(streamdatalabel[j])
            # self.result_new.append([newclasslabel, streamdatalabel[j]])
        # else:
        #     result_new.append([Score_1[0], streamdatalabel[j]])
        #     batchdatalabel.append(Score_1[0])

        predict_labels = Mass[:, 2]
        is_new_class = Mass[:, 4]
        return predict_labels, is_new_class
