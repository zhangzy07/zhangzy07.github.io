# /usr/bin/env python
# -*- coding: utf-8 -*-

import os

import torch
import safetensors.torch as st

# from online.algorithms.ogd import Base, CustomOGD, OptOGD

from utils_pkg.exp_config import Config


def get_script_module(cfgs: Config, sub_cfgs) -> torch.ScriptModule:
    """sub_cfgs is either cfgs.offline_cfgs or cfgs.online_cfgs"""
    path = sub_cfgs.rep_model_path
    if os.path.exists(path):
        cfgs.logger(f"[get_script_module] path={repr(path)}")
        return torch.jit.load(path)
    else:
        raise ValueError(f"[get_script_module] path={repr(path)} does not exist")


def get_model_weight(model_path: str):
    if model_path.endswith(".scriptmodule"):
        return torch.jit.load(model_path).to(device="cpu").state_dict()
    elif model_path.endswith(".safetensors"):
        return st.load_file(model_path, device="cpu")
    else:
        return torch.load(model_path, map_location="cpu")


def load_DNN_model(cfgs: Config, sub_cfgs, model_name, DNN_model_path):
    DNN_model = None

    if DNN_model_path.endswith(".scriptmodule"):
        return get_script_module(cfgs, sub_cfgs)

    if model_name == "ResNet18":
        from models_pkg.backbone_network.resnet import resnet18

        DNN_model = resnet18()
    elif model_name == "ResNet34":
        from models_pkg.backbone_network.resnet import resnet34

        DNN_model = resnet34()
    elif model_name == "ResNet50":
        from models_pkg.backbone_network.resnet import resnet50

        DNN_model = resnet50()
    elif model_name == "ResNet101":
        from models_pkg.backbone_network.resnet import resnet101

        DNN_model = resnet101()
    elif model_name == "MLP":
        from models_pkg.rep_models import MLP

        DNN_model = MLP(
            input_dim=cfgs.data_cfgs.info["dim"],
            output_dim=sub_cfgs.kwargs["rep_output_dim"],
            hidden_dim=sub_cfgs.kwargs["rep_hidden_dim"],
        )
    elif model_name == "MobileNet_rep":
        from models_pkg.MobileNet import MobileNetV2_10_rep

        DNN_model = MobileNetV2_10_rep()  # output rep dim: 1280
    elif model_name == "Linear":
        from models_pkg.linear import Linear

        # DNN_model = Linear()
        if sub_cfgs.rep_model_name == "None":
            DNN_model = Linear(
                input_dim=cfgs.data_cfgs.info["dim"],
                output_dim=cfgs.data_cfgs.info["cls_num"],
                R=cfgs.online_cfgs.kwargs["D"] / 2,
            )
        else:
            DNN_model = Linear(
                input_dim=cfgs.online_cfgs.kwargs["rep_output_dim"],
                output_dim=cfgs.data_cfgs.info["cls_num"],
                R=cfgs.online_cfgs.kwargs["D"] / 2,
            )
    elif model_name == "None":
        DNN_model = None
    else:
        raise NotImplementedError(f"unknown model_name={repr(model_name)}")

    # load DNN_model from checkpoint:
    if DNN_model_path:
        init = get_model_weight(DNN_model_path)
        DNN_model.load_state_dict(init)

    if DNN_model_path:
        cfgs.logger(
            f"[load_DNN_model] type={type(DNN_model)}, path={repr(DNN_model_path)}"
        )
    else:
        cfgs.logger(
            f"[load_DNN_model] type={type(DNN_model)}, initialized from nothing"
        )
    return DNN_model
