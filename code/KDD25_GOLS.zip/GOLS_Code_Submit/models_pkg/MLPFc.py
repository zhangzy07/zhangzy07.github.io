import torch.nn as nn
from torchvision import models


class MLPFc(nn.Module):
    def __init__(self, dim, width, out_feature):
        super(MLPFc, self).__init__()
        self.layers = nn.Sequential(
            nn.Linear(dim, width),
            nn.BatchNorm1d(width),
            nn.Tanh(),
            nn.Dropout(0.2),
            nn.Linear(width, out_feature),
        )
        self.__in_features = out_feature

    def forward(self, x):
        x = x.view(x.size(0), -1)
        x = self.layers(x)
        return x

    def output_num(self):
        return self.__in_features


network_dict = {"MLP": MLPFc}
