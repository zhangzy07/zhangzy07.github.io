from torch import nn
from torchvision.models import resnet34
from collections import OrderedDict


class Init(object):
    def __init__(self, cfg):
        self.cfg = cfg
        if cfg["type"] == "normal_":
            self.init_func = self.init_weights_normal
        elif cfg["type"] == "xavier_normal_":
            self.init_func = self.init_weights_xavier_normal
        elif cfg["type"] == "zeros_":
            self.init_func = self.init_weights_zeros
        elif cfg["type"] == "kaiming_normal_":
            self.init_func = self.init_weights_kaiming_normal
        else:
            raise NotImplementedError

    def init_weights_zeros(self, m):
        if isinstance(m, nn.Conv2d):
            nn.init.zeros_(m.weight.data)
            # nn.init.zeros_(m.bias.data)
            nn.init.constant_(m.bias.data, 0.01)

    def init_weights_normal(self, m):
        if isinstance(m, nn.Conv2d):
            nn.init.normal_(m.weight.data, 0, self.cfg.get("std", 0.05))
            nn.init.zeros_(m.bias.data)
        else:
            self.init_others(m)

    def init_weights_xavier_normal(self, m):
        if isinstance(m, nn.Conv2d):
            import math

            fan_in, fan_out = nn.init._calculate_fan_in_and_fan_out(m.weight.data)
            std = math.sqrt(2.0 / float(fan_in + fan_out))
            print(std)
            nn.init.xavier_normal_(m.weight.data, self.cfg.get("gain", 1.0))
            nn.init.zeros_(m.bias.data)
        else:
            self.init_others(m)

    def init_weights_kaiming_normal(self, m):
        if isinstance(m, nn.Conv2d):
            nn.init.kaiming_normal_(
                m.weight.data,
                mode=self.cfg.get("mode", "fan_in"),
                nonlinearity=self.cfg.get("nonlinearity", "relu"),
            )
            nn.init.zeros_(m.bias.data)
        else:
            self.init_others(m)

    def init_others(self, m):
        if isinstance(m, nn.BatchNorm2d):
            nn.init.constant_(m.weight, 1)
            nn.init.constant_(m.bias, 0)

        if isinstance(m, nn.Linear):
            nn.init.normal_(m.weight, 0, 0.01)
            nn.init.constant_(m.bias, 0)

    def __call__(self, m):
        self.init_func(m)


class CNN(nn.Module):
    def __init__(self, num_classes=7, init_cfg=None):
        super(CNN, self).__init__()
        self.features = nn.Sequential(
            # 1
            nn.Conv2d(3, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(True),
            # 2
            nn.Conv2d(64, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),  # BN
            nn.ReLU(True),
            nn.MaxPool2d(kernel_size=2, stride=2),
            # 3
            nn.Conv2d(64, 128, kernel_size=3, padding=1),
            nn.BatchNorm2d(128),  # BN
            nn.ReLU(True),
            # 4
            nn.Conv2d(128, 128, kernel_size=3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(True),
            nn.MaxPool2d(kernel_size=2, stride=2),
            # 5
            nn.Conv2d(128, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(True),
            # 6
            nn.Conv2d(256, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(True),
            # 7
            nn.Conv2d(256, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(True),
            nn.MaxPool2d(kernel_size=2, stride=2),
            # 8
            nn.Conv2d(256, 512, kernel_size=3, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(True),
            # 9
            nn.Conv2d(512, 512, kernel_size=3, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(True),
            # 10
            nn.Conv2d(512, 512, kernel_size=3, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(True),
            nn.MaxPool2d(kernel_size=2, stride=2),
            # 11
            nn.Conv2d(512, 512, kernel_size=3, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(True),
            # 12
            nn.Conv2d(512, 512, kernel_size=3, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(True),
            # 13
            nn.Conv2d(512, 512, kernel_size=3, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(True),
            nn.MaxPool2d(kernel_size=2, stride=2),
            nn.AvgPool2d(kernel_size=1, stride=1),
        )
        self.classifier = nn.Linear(512, num_classes)

        if not init_cfg is None:
            self.init_helper = Init(init_cfg)
            self.features.apply(self.init_helper)
            self.classifier.apply(self.init_helper)

    def forward(self, x):
        out = self.features(x)
        features = out
        out = out.view(out.size(0), -1)
        out = self.classifier(out)
        return out, features
