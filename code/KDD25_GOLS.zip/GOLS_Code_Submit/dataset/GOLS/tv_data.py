"""
add to `~/.bashrc` and then run `. ~/.bashrc` or `source ~/.bashrc`

```
# on 127.0.0.1
export STREAM_WILDS_DATA_DIR=/home/Username/Codes/data/wilds/data
export STREAM_TORCHVISION_CIFAR10_DIR=/home/Username/Workspace/dataset/torchvision-cifar10
export STREAM_TORCHVISION_CIFAR100_DIR=/home/Username/Workspace/dataset/torchvision-cifar100
export STREAM_TORCHVISION_MNIST_DIR=/home/Username/Workspace/dataset/torchvision-mnist
export STREAM_TORCHVISION_FASHIONMNIST_DIR=/home/Username/Workspace/dataset/torchvision-fashionmnist
export STREAM_TORCHVISION_EUROSAT_DIR=/home/Username/Workspace/dataset/torchvision-eurosat
export STREAM_TORCHVISION_CINIC10_DIR=/home/Username/Workspace/dataset/cinic10/all

cp -r /home/Username/Workspace/StreamData/dataset/General/__pycache__ ./dataset/General/__pycache__
```

"""

import os, random, pickle

from tqdm import trange

import torch
import torchvision

from utils_pkg.exp_config import Config
from dataset.GOLS.gols_data import GOLSDataset
from utils_pkg.cv import preprocess_32 as cv_preprocess

_PYCACHE_DIR = os.path.join(os.path.dirname(os.path.realpath(__file__)), "__pycache__")


TORCHVISION_DATASET_CLASS_DICT = {
    "cifar10": torchvision.datasets.cifar.CIFAR10,
    "cifar100": torchvision.datasets.cifar.CIFAR100,
    "mnist": torchvision.datasets.MNIST,
    "fashionmnist": torchvision.datasets.FashionMNIST,
}

TORCHVISION_DATASET_DIR_DICT = {
    "cifar10": os.environ["STREAM_TORCHVISION_CIFAR10_DIR"],
    "cifar100": os.environ["STREAM_TORCHVISION_CIFAR100_DIR"],
    "mnist": os.environ["STREAM_TORCHVISION_MNIST_DIR"],
    "fashionmnist": os.environ["STREAM_TORCHVISION_FASHIONMNIST_DIR"],
}


TORCHVISION_EUROSAT_DIR = os.environ["STREAM_TORCHVISION_EUROSAT_DIR"]
TORCHVISION_CINIC10_DIR = os.environ["STREAM_TORCHVISION_CINIC10_DIR"]


def generate_random_k_hot(n, k):
    assert k <= n and k >= 0
    a = torch.rand(n)
    indices = torch.argsort(a)
    a[indices[:k]] = 1
    a[indices[k:]] = 0
    return a.long()


def simulate_shifts(
    class_count: torch.LongTensor,
    mu0: torch.FloatTensor,
    mu1: torch.FloatTensor,
    alpha: torch.FloatTensor,
):
    """
    input:
        class_count, mu0, mu1: non-negative vector of shape (num_class,)
        alpha: non-negative vector of shape (T,)

    input explained:
        sum(alpha) / len(alpha) = 1 / 2
        (mu0 + mu1) / 2 = class_count / len(alpha)
        mu[t] = alpha[t] * mu0 + (1 - alpha[t]) * mu1

    output:
        allocation: non-negative matrix of shape (T, num_class)

    output explained:
        for the t th domain, the i th class should have allocation[t][i] samples
        sum(allocation[:,i]) = class_count[i]
    """

    assert all(
        (
            torch.all(class_count > 0),
            torch.all(mu0 >= 0),
            torch.all(mu1 >= 0),
            torch.all(alpha >= 0),
        )
    )

    K = class_count.size(0)
    T = alpha.size(0)

    # normalize
    alpha_scale = torch.mean(alpha) * 2
    alpha = torch.reshape(alpha / alpha_scale, (T, 1))
    mu_scale = T * (mu0 + mu1) / (2 * class_count)
    mu0 = torch.reshape(mu0 / mu_scale, (1, K))
    mu1 = torch.reshape(mu1 / mu_scale, (1, K))

    # round
    allocation = torch.floor(alpha @ mu0 + (1 - alpha) @ mu1).long()
    allocation[allocation < 0] = 0
    for i in range(K):
        delta = class_count[i] - torch.sum(allocation[:, i])
        assert delta >= 0
        while delta != 0:
            k_hot = generate_random_k_hot(T, min(delta, T))
            allocation[:, i] += k_hot
            delta = class_count[i] - torch.sum(allocation[:, i])
            assert delta >= 0

    return allocation


# simulate_shifts(
#     class_count=torch.LongTensor([10000, 1000, 100, 9]),
#     mu0=torch.FloatTensor([1, 0, 1, 0]),
#     mu1=torch.FloatTensor([0, 1, 0, 1]),
#     alpha=torch.FloatTensor([1, 2, 3, 4]),
# )
# tensor([[1000,  400,   10,    3],
#         [2000,  300,   20,    3],
#         [3000,  200,   30,    2],
#         [4000,  100,   40,    1]])
# tensor([[1000,  400,   10,    4],
#         [2000,  300,   20,    2],
#         [3000,  200,   30,    2],
#         [4000,  100,   40,    1]])
# tensor([[1000,  400,   10,    4],
#         [2000,  300,   20,    3],
#         [3000,  200,   30,    1],
#         [4000,  100,   40,    1]])


def make_domain(
    cfgs: Config, name: str, num_domain: int, alpha_period: float, ys: torch.LongTensor
):
    random.seed(cfgs.seed)
    torch.manual_seed(cfgs.seed)

    if name == "squ":
        alpha = torch.ones(num_domain)
        alpha[::2] = 0
    elif name == "ber":
        alpha = generate_random_k_hot(num_domain, num_domain // 2).float()
    elif name == "lin":
        alpha = torch.linspace(0, num_domain / alpha_period, num_domain)
        alpha = alpha - torch.floor(alpha)
    elif name == "sin":
        alpha = torch.linspace(0, num_domain / (alpha_period * torch.pi), num_domain)
        alpha = torch.abs(torch.sin(alpha))
    else:
        raise NotImplementedError()

    ascend_index = torch.argsort(ys)
    class_count = torch.bincount(ys)

    K = len(class_count)
    T = num_domain

    class_index_pool = {class_id: None for class_id in range(K)}
    accumulate_count = 0
    for class_id, one_count in enumerate(class_count):
        class_index_pool[class_id] = ascend_index[
            accumulate_count : accumulate_count + one_count
        ].tolist()
        random.shuffle(class_index_pool[class_id])
        accumulate_count += one_count

    mu0 = torch.zeros(K)
    mu0[: K // 2] = 1
    mu1 = torch.zeros(K)
    mu1[K // 2 :] = 1

    allocation = simulate_shifts(class_count, mu0, mu1, alpha)
    domain_index_pool = {domian_id: [] for domian_id in range(T)}
    for t in range(T):
        for class_id in range(K):
            sample_size = allocation[t, class_id]
            domain_index_pool[t].extend(class_index_pool[class_id][:sample_size])
            class_index_pool[class_id] = class_index_pool[class_id][sample_size:]
            sample_size = None

    domain_ids = torch.zeros_like(ys)
    for t in range(T):
        domain_ids[domain_index_pool[t]] = t

    return domain_ids


class GOLSDatasetTVDS(GOLSDataset):
    """torchvision dataset"""

    def load_data(self):
        self.tvds_name = self.cfgs.data_cfgs.kwargs["gols_name"]
        self.tvds_class = TORCHVISION_DATASET_CLASS_DICT[self.tvds_name]
        self.tvds_dir = TORCHVISION_DATASET_DIR_DICT[self.tvds_name]
        self.tvds_train = self.tvds_class(root=self.tvds_dir, train=True)
        self.tvds_test = self.tvds_class(root=self.tvds_dir, train=False)
        self.tvds_ys = torch.concat(
            (
                torch.LongTensor(self.tvds_train.targets),
                torch.LongTensor(self.tvds_test.targets),
            )
        )
        _name = self.cfgs.data_cfgs.kwargs.get("simulated_shift", "lin")
        _num_domain = self.cfgs.data_cfgs.kwargs.get("num_domain", 80)
        _alpha_period = self.cfgs.data_cfgs.kwargs.get("alpha_period", 8)
        self.tvds_domain_ids = make_domain(
            cfgs=self.cfgs,
            name=_name,
            num_domain=_num_domain,
            alpha_period=_alpha_period,
            ys=self.tvds_ys,
        )
        self.index_map = torch.argsort(self.tvds_domain_ids)
        self.gols_ys = self.tvds_ys[self.index_map]
        self.gols_domain_ids = self.tvds_domain_ids[self.index_map]

    def get_x(self, index):
        tv_index = self.index_map[index]
        if tv_index < len(self.tvds_train):
            image = self.tvds_train.data[tv_index]
        else:
            image = self.tvds_test.data[tv_index - len(self.tvds_train)]
        return cv_preprocess(image)

    @property
    def ys(self):
        return self.gols_ys

    @property
    def domain_ids(self):
        return self.gols_domain_ids


class GOLSDatasetEuroSAT(GOLSDataset):

    def load_data(self):
        self.tvds_name = self.cfgs.data_cfgs.kwargs["gols_name"]
        assert self.tvds_name == "eurosat"
        self.tvds = torchvision.datasets.EuroSAT(root=TORCHVISION_EUROSAT_DIR)
        self.tvds_xy_pairs = [
            self.tvds[i] for i in trange(len(self.tvds), ncols=80, desc="EuroSAT")
        ]
        self.tvds_data = [image for image, label in self.tvds_xy_pairs]
        self.tvds_targets = [label for image, label in self.tvds_xy_pairs]
        self.tvds_ys = torch.LongTensor(self.tvds_targets)
        _name = self.cfgs.data_cfgs.kwargs.get("simulated_shift", "lin")
        _num_domain = self.cfgs.data_cfgs.kwargs.get("num_domain", 80)
        _alpha_period = self.cfgs.data_cfgs.kwargs.get("alpha_period", 8)
        self.tvds_domain_ids = make_domain(
            cfgs=self.cfgs,
            name=_name,
            num_domain=_num_domain,
            alpha_period=_alpha_period,
            ys=self.tvds_ys,
        )
        self.index_map = torch.argsort(self.tvds_domain_ids)
        self.gols_ys = self.tvds_ys[self.index_map]
        self.gols_domain_ids = self.tvds_domain_ids[self.index_map]

    def get_x(self, index):
        tv_index = self.index_map[index]
        image = self.tvds_data[tv_index]
        return cv_preprocess(image)

    @property
    def ys(self):
        return self.gols_ys

    @property
    def domain_ids(self):
        return self.gols_domain_ids


class GOLSDatasetCINIC10(GOLSDataset):

    def load_data(self):
        self.tvds_name = self.cfgs.data_cfgs.kwargs["gols_name"]
        assert self.tvds_name == "cinic10"
        self.tvds = torchvision.datasets.ImageFolder(root=TORCHVISION_CINIC10_DIR)
        _xy_pairs_cache_path = os.path.join(_PYCACHE_DIR, "cinic10_xy_pairs.pickle")
        if not os.path.exists(_xy_pairs_cache_path):
            _xy_pairs = [
                self.tvds[i] for i in trange(len(self.tvds), ncols=80, desc="CINIC10")
            ]
            with open(_xy_pairs_cache_path, "wb") as _xy_pairs_cache_file:
                pickle.dump(_xy_pairs, _xy_pairs_cache_file)
        else:
            with open(_xy_pairs_cache_path, "rb") as _xy_pairs_cache_file:
                _xy_pairs = pickle.load(_xy_pairs_cache_file)
        self.tvds_xy_pairs = _xy_pairs
        self.tvds_data = [image for image, label in self.tvds_xy_pairs]
        self.tvds_targets = [label for image, label in self.tvds_xy_pairs]
        self.tvds_ys = torch.LongTensor(self.tvds_targets)
        _name = self.cfgs.data_cfgs.kwargs.get("simulated_shift", "lin")
        _num_domain = self.cfgs.data_cfgs.kwargs.get("num_domain", 80)
        _alpha_period = self.cfgs.data_cfgs.kwargs.get("alpha_period", 8)
        self.tvds_domain_ids = make_domain(
            cfgs=self.cfgs,
            name=_name,
            num_domain=_num_domain,
            alpha_period=_alpha_period,
            ys=self.tvds_ys,
        )
        self.index_map = torch.argsort(self.tvds_domain_ids)
        self.gols_ys = self.tvds_ys[self.index_map]
        self.gols_domain_ids = self.tvds_domain_ids[self.index_map]

    def get_x(self, index):
        tv_index = self.index_map[index]
        image = self.tvds_data[tv_index]
        return cv_preprocess(image)

    @property
    def ys(self):
        return self.gols_ys

    @property
    def domain_ids(self):
        return self.gols_domain_ids
