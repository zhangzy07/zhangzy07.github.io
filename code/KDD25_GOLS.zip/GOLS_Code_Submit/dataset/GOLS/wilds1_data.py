import torch
from utils_pkg import exp_config
from dataset.GOLS.gols_data import GOLSDataset
from dataset.General.wilds1_data import (
    DatasetFMOW,
    DatasetIWildCam,
    DatasetIWildCamNatural,
    DatasetAmazon,
    DatasetAmazonByCategory,
)

WILDS1_DATASET_CLASS_DICT = {
    "fmow": DatasetFMOW,
    "iwildcam": DatasetIWildCam,
    "iwildcam_natural": DatasetIWildCamNatural,
    "amazon": DatasetAmazon,
    "amazon_by_category": DatasetAmazonByCategory,
}


class GOLSDatasetWilds1(GOLSDataset):
    def load_data(self):
        self.wilds1_name = self.cfgs.data_cfgs.kwargs["gols_name"]
        self.wilds1_data = WILDS1_DATASET_CLASS_DICT[self.wilds1_name]()
        self.wilds1_ys = torch.LongTensor(self.wilds1_data.metadata["y"])
        self.wilds1_domain_ids = torch.LongTensor(
            self.wilds1_data.metadata["domain_id"]
        )

        # _domain_id_count = self.wilds1_data.metadata["domain_id"].value_counts(sort=False).to_frame("count")
        # _domain_id_count["cumsum"] = _domain_id_count["count"].cumsum()
        # _domain_id_count["cumsum/len"] = _domain_id_count["cumsum"].apply(lambda n: n / len(self.wilds1_data.metadata))
        # self.cfgs.logger(_domain_id_count.to_string())

        # Google Bert max_position_embeddings
        if self.wilds1_name in ("amazon", "amazon_by_category"):
            self.wilds1_data.max_token_num = self.cfgs.data_cfgs.kwargs.get(
                "max_token_num", 512
            )

    def get_x(self, index):
        return self.wilds1_data.get_x(index)

    @property
    def ys(self):
        return self.wilds1_ys

    @property
    def domain_ids(self):
        return self.wilds1_domain_ids
