from utils_pkg import exp_config
from dataset.GOLS.gols_data import gols_dataset_train_test_split
from dataset.GOLS.wilds1_data import GOLSDatasetWilds1
from dataset.GOLS.tv_data import GOLSDatasetTVDS, GOLSDatasetEuroSAT, GOLSDatasetCINIC10


def get_dataset(cfgs: exp_config.Config):
    assert cfgs.data_cfgs.name == "gols"

    gols_name = cfgs.data_cfgs.kwargs["gols_name"]

    # wilds1
    if gols_name in (
        "fmow",
        "iwildcam",
        "iwildcam_natural",
        "amazon",
        "amazon_by_category",
    ):
        gols_dataset_class = GOLSDatasetWilds1

    # cifar, mnist
    elif gols_name in ("cifar10", "cifar100", "mnist", "fashionmnist"):
        gols_dataset_class = GOLSDatasetTVDS

    # eurosat
    elif gols_name in ("eurosat",):
        gols_dataset_class = GOLSDatasetEuroSAT

    # cinic100
    elif gols_name in ("cinic10",):
        gols_dataset_class = GOLSDatasetCINIC10

    # unknown
    else:
        raise NotImplementedError(f"gols_name={repr(gols_name)} unknown")

    return gols_dataset_train_test_split(cfgs, gols_dataset_class)
