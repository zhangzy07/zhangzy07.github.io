"""
data_cfgs:
    name: gols
    kwargs:
        gols_name: iwildcam
        domain_allocation:
            train:
                first_domain_id: 0
                last_domain_id: 63
            test:
                first_domain_id: 64
                last_domain_id: 127
"""

import numpy as np

import torch
import torch.utils.data as torch_data

from utils_pkg import exp_config


class GOLSDataset(torch_data.Dataset):
    def __init__(self, cfgs: exp_config.Config):
        super(GOLSDataset, self).__init__()
        self.cfgs = cfgs
        self.load_data()

    def __getitem__(self, index):
        index = index % len(self)
        return self.get_x(index), self.ys[index], self.domain_ids[index]

    def __len__(self):
        return self.domain_ids.shape[0]

    def load_data(self):
        raise NotImplementedError()

    def get_x(self, index) -> torch.Tensor:
        raise NotImplementedError()

    @property
    def ys(self) -> torch.LongTensor:
        raise NotImplementedError()

    @property
    def domain_ids(self) -> torch.LongTensor:
        raise NotImplementedError()


class GOLSDatasetView(torch_data.Dataset):
    def __init__(self, gols_dataset: GOLSDataset, first_index: int, last_index: int):
        super(GOLSDatasetView, self).__init__()

        self.data = gols_dataset
        self.first_index = first_index
        self.last_index = last_index

    def __getitem__(self, index):
        return self.get_x(index), self.ys[index], self.domain_ids[index]

    def __len__(self):
        return self.last_index - self.first_index + 1

    def get_x(self, index) -> torch.Tensor:
        return self.data.get_x(self.first_index + index)

    @property
    def ys(self) -> torch.LongTensor:
        return self.data.ys[self.first_index : self.last_index + 1]

    @property
    def domain_ids(self) -> torch.LongTensor:
        return self.data.domain_ids[self.first_index : self.last_index + 1]


def first_index_of_domain_id(domain_ids, domain_id):
    if "torch.Tensor" in str(type(domain_ids)):
        return torch.where(domain_ids >= domain_id)[0][0].item()
    elif "numpy.ndarray" in str(type(domain_ids)):
        return np.where(domain_ids >= domain_id)[0][0]
    else:
        raise TypeError("self.domain_ids must be numpy/torch vector")


def last_index_of_domain_id(domain_ids, domain_id):
    if "torch.Tensor" in str(type(domain_ids)):
        return torch.where(domain_ids <= domain_id)[0][-1].item()
    elif "numpy.ndarray" in str(type(domain_ids)):
        return np.where(domain_ids <= domain_id)[0][-1]
    else:
        raise TypeError("self.domain_ids must be numpy/torch vector")


def gols_dataset_train_test_split(
    cfgs: exp_config.Config, gols_dataset_class: type[GOLSDataset]
):
    data = gols_dataset_class(cfgs)

    train_cfgs = cfgs.data_cfgs.kwargs["domain_allocation"]["train"]
    train_first = first_index_of_domain_id(
        data.domain_ids, train_cfgs["first_domain_id"]
    )
    train_last = last_index_of_domain_id(data.domain_ids, train_cfgs["last_domain_id"])
    train_view = GOLSDatasetView(data, train_first, train_last)

    test_cfgs = cfgs.data_cfgs.kwargs["domain_allocation"]["test"]
    test_first = first_index_of_domain_id(data.domain_ids, test_cfgs["first_domain_id"])
    test_last = last_index_of_domain_id(data.domain_ids, test_cfgs["last_domain_id"])
    test_view = GOLSDatasetView(data, test_first, test_last)

    return train_view, test_view
