"""
export STREAM_WILDS_DATA_DIR=/home/Username/Codes/data/wilds/data  # on 127.0.0.1

    x: torch.Tensor, y: int, domain_id: int = wilds1_data[index]
    wilds1_data.metadata: pd.DataFrame
    wilds1_data.metadata["y"]
    wilds1_data.metadata["domain_id"]
    wilds1_data.metadata["_timestamp"]
"""

import os
import os.path as path
import glob
import re
import io
import time

from tqdm import tqdm

from PIL import Image

import numpy as np
import pandas as pd

import torch
import torch.utils.data as torch_data
from torchvision.transforms import transforms

from utils_pkg.cv import preprocess_96 as cv_preprocess
from utils_pkg.nlp import preprocess as npl_preprocess

_WILDS_DATA_DIR = os.environ["STREAM_WILDS_DATA_DIR"]
_PYCACHE_DIR = path.join(path.dirname(path.realpath(__file__)), "__pycache__")

if not path.exists(_PYCACHE_DIR):
    os.makedirs(_PYCACHE_DIR)


class DatasetFMOW(torch_data.Dataset):
    def __init__(self):
        torch_data.Dataset.__init__(self)

        customized_path = path.join(_PYCACHE_DIR, "fmow_customized.csv")
        if not path.exists(customized_path):
            self.customize_fmow(customized_path)

        self.metadata = pd.read_csv(customized_path)
        self.transform = cv_preprocess

    def __len__(self):
        return len(self.metadata)

    def __getitem__(self, index):
        y = self.metadata["y"][index]
        domain_id = self.metadata["domain_id"][index]
        return self.get_x(index), y, domain_id

    def get_x(self, index):
        x_path = path.join(
            _WILDS_DATA_DIR, "fmow_v1.1/images/" + self.metadata["x_filename"][index]
        )
        x_image = Image.open(x_path).convert("RGB")
        x = self.transform(x_image)
        return x

    @staticmethod
    def customize_fmow(customized_path):
        # cache customized metadata to customized_path as a csv file

        meta_path = path.join(_WILDS_DATA_DIR, "fmow_v1.1/rgb_metadata.csv")
        country_path = path.join(_WILDS_DATA_DIR, "fmow_v1.1/country_code_mapping.csv")

        # https://github.com/p-lambda/wilds/issues/146
        # 2011-02-07T02:48:56.643Z -> 2011-02-07T02:48:56Z
        with open(meta_path, "rt") as meta_file:
            meta_text = meta_file.read()
            meta_text = re.sub(
                r"(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})\.\d{3}Z", r"\1Z", meta_text
            )

        # do not save csv on disk, make an in-memory file
        meta_file = io.StringIO(meta_text)
        del meta_text

        meta_table = pd.read_csv(meta_file)
        country_table = pd.read_csv(country_path)

        # delete any sequestered images, but keep original index as filename
        # see wilds source code site-packages/wilds/datasets/fmow_dataset.py
        meta_table["index"] = np.arange(len(meta_table))
        meta_table["x_filename"] = meta_table["index"].apply(
            lambda x: f"rgb_img_{x}.png"
        )
        meta_table = meta_table[~meta_table["split"].str.contains("seq")]

        # create column year based on timestamp
        # year is the primary domain indicator
        meta_table["timestamp"] = pd.to_datetime(meta_table["timestamp"])
        meta_table["year"] = meta_table["timestamp"].apply(lambda x: x.year)

        # create column region based on country_code
        # region is the secondary domain indicator
        country2region = {}
        for k, v in zip(country_table["alpha-3"], country_table["region"]):
            if not (pd.isna(k) or pd.isna(v)):
                country2region[k] = v
        meta_table["region"] = meta_table["country_code"].apply(
            lambda x: country2region.get(x, "Other")
        )

        # make index for category
        categories = meta_table["category"].unique().tolist()
        category2id = {
            category: index for index, category in enumerate(sorted(categories))
        }
        meta_table["category_id"] = meta_table["category"].apply(
            lambda x: category2id[x]
        )

        # make index for region
        years = meta_table["year"].unique().tolist()
        year2id = {year: index for index, year in enumerate(sorted(years))}
        meta_table["year_id"] = meta_table["year"].apply(lambda x: year2id[x])

        # make index for region
        regions = meta_table["region"].unique().tolist()
        region2id = {region: index for index, region in enumerate(sorted(regions))}
        meta_table["region_id"] = meta_table["region"].apply(lambda x: region2id[x])

        # make index for domain
        meta_table["domain_id"] = (
            meta_table["year_id"] * (meta_table["region_id"].max() + 1)
            + meta_table["region_id"]
        )

        # rename concerned columns, drop irrelevant columns
        concerned = [
            # (old_column_name, new_column_name) in sequence
            ("x_filename", "x_filename"),
            ("category_id", "y"),
            ("domain_id", "domain_id"),
            ("category", "_y_name"),
            ("timestamp", "_timestamp"),
            ("year_id", "_year_id"),
            ("country_code", "_country_code"),
            ("region_id", "_region_id"),
        ]
        meta_table = meta_table.loc[:, [old for old, new in concerned]].rename(
            columns=dict(concerned)
        )

        # sort images by region_id
        meta_table = meta_table.sort_values(by="domain_id")
        meta_table = meta_table.reset_index(drop=True)

        with open(customized_path, "wt") as customized_file:
            meta_table.to_csv(customized_file, index=False, encoding="utf-8")


class DatasetIWildCam(torch_data.Dataset):
    def __init__(self):
        torch_data.Dataset.__init__(self)

        customized_path = path.join(_PYCACHE_DIR, "iwildcam_customized.csv")
        if not path.exists(customized_path):
            self.customize_iwildcam(customized_path)

        self.metadata = pd.read_csv(customized_path)
        self.transform = cv_preprocess

    def __len__(self):
        return len(self.metadata)

    def __getitem__(self, index):
        y = self.metadata["y"][index]
        domain_id = self.metadata["domain_id"][index]
        return self.get_x(index), y, domain_id

    def get_x(self, index):
        x_path = path.join(
            _WILDS_DATA_DIR, "iwildcam_v2.0/train/" + self.metadata["x_filename"][index]
        )
        x_image = Image.open(x_path).convert("RGB")
        x = self.transform(x_image)
        return x

    @staticmethod
    def customize_iwildcam(customized_path):
        # cache customized metadata to customized_path as a csv file

        meta_path = path.join(_WILDS_DATA_DIR, "iwildcam_v2.0/metadata.csv")
        species_path = path.join(_WILDS_DATA_DIR, "iwildcam_v2.0/categories.csv")

        meta_table = pd.read_csv(meta_path)
        species_table = pd.read_csv(species_path)

        # append readable species name
        id2species = {
            k: v for k, v in zip(species_table["y"], species_table["name"]) if k < 1024
        }
        meta_table["species"] = meta_table["y"].apply(lambda x: id2species[x])

        # create column year and month based on datetime
        # (year, month) is the domain indicator
        meta_table["datetime"] = pd.to_datetime(meta_table["datetime"])
        meta_table["year"] = meta_table["datetime"].apply(lambda x: x.year)
        meta_table["month"] = meta_table["datetime"].apply(lambda x: x.month)

        # make index for domain (year, month)
        years = meta_table["year"].unique().tolist()
        year2id = {year: index for index, year in enumerate(sorted(years))}
        meta_table["year_id"] = meta_table["year"].apply(lambda x: year2id[x])
        months = meta_table["month"].unique().tolist()
        month2id = {month: index for index, month in enumerate(sorted(months))}
        meta_table["month_id"] = meta_table["month"].apply(lambda x: month2id[x])
        meta_table["domain_id"] = (
            meta_table["year_id"] * (meta_table["month_id"].max() + 1)
            + meta_table["month_id"]
        )

        # (location, sequence) is also a meaningful domain indicator
        # see wilds source code site-packages/wilds/datasets/iwildcam_dataset.py

        # rename concerned columns, drop irrelevant columns
        concerned = [
            # (old_column_name, new_column_name) in sequence
            ("filename", "x_filename"),
            ("y", "y"),
            ("domain_id", "domain_id"),
            ("species", "_y_name"),
            ("datetime", "_timestamp"),
            ("year_id", "_year_id"),
            ("month_id", "_month_id"),
            ("location_remapped", "_location_id"),
            ("sequence_remapped", "_sequence_id"),
        ]
        meta_table = meta_table.loc[:, [old for old, new in concerned]].rename(
            columns=dict(concerned)
        )

        # sort images by region_id
        meta_table = meta_table.sort_values(by="domain_id")
        meta_table = meta_table.reset_index(drop=True)

        with open(customized_path, "wt") as customized_file:
            meta_table.to_csv(customized_file, index=False, encoding="utf-8")


class DatasetIWildCamNatural(torch_data.Dataset):
    def __init__(self):
        torch_data.Dataset.__init__(self)

        customized_path = path.join(_PYCACHE_DIR, "iwildcam_natural_customized.csv")
        if not path.exists(customized_path):
            self.customize_iwildcam(customized_path)

        self.metadata = pd.read_csv(customized_path)
        self.transform = cv_preprocess

    def __len__(self):
        return len(self.metadata)

    def __getitem__(self, index):
        y = self.metadata["y"][index]
        domain_id = self.metadata["domain_id"][index]
        return self.get_x(index), y, domain_id

    def get_x(self, index):
        x_path = path.join(
            _WILDS_DATA_DIR, "iwildcam_v2.0/train/" + self.metadata["x_filename"][index]
        )
        x_image = Image.open(x_path).convert("RGB")
        x = self.transform(x_image)
        return x

    @staticmethod
    def customize_iwildcam(customized_path):
        # cache customized metadata to customized_path as a csv file

        meta_path = path.join(_WILDS_DATA_DIR, "iwildcam_v2.0/metadata.csv")
        species_path = path.join(_WILDS_DATA_DIR, "iwildcam_v2.0/categories.csv")

        meta_table = pd.read_csv(meta_path)
        species_table = pd.read_csv(species_path)

        # append readable species name
        id2species = {
            k: v for k, v in zip(species_table["y"], species_table["name"]) if k < 1024
        }
        meta_table["species"] = meta_table["y"].apply(lambda x: id2species[x])

        # create column year and month based on datetime
        # (year, month) is the domain indicator
        meta_table["datetime"] = pd.to_datetime(meta_table["datetime"])
        meta_table["year"] = meta_table["datetime"].apply(lambda x: x.year)
        meta_table["month"] = meta_table["datetime"].apply(lambda x: x.month)

        meta_table["domain_id"] = meta_table["sequence_remapped"]

        # (location, sequence) is also a meaningful domain indicator
        # see wilds source code site-packages/wilds/datasets/iwildcam_dataset.py

        # rename concerned columns, drop irrelevant columns
        concerned = [
            # (old_column_name, new_column_name) in sequence
            ("filename", "x_filename"),
            ("y", "y"),
            ("domain_id", "domain_id"),
            ("species", "_y_name"),
            ("datetime", "_timestamp"),
            ("location_remapped", "_location_id"),
            ("sequence_remapped", "_sequence_id"),
        ]
        meta_table = meta_table.loc[:, [old for old, new in concerned]].rename(
            columns=dict(concerned)
        )

        # sort images by region_id
        meta_table = meta_table.sort_values(by="domain_id")
        meta_table = meta_table.reset_index(drop=True)

        with open(customized_path, "wt") as customized_file:
            meta_table.to_csv(customized_file, index=False, encoding="utf-8")


class DatasetAmazon(torch_data.Dataset):
    def __init__(self, max_token_num=0):
        torch_data.Dataset.__init__(self)
        self.max_token_num = max_token_num

        customized_path = path.join(_PYCACHE_DIR, "amazon_customized.csv")
        if not path.exists(customized_path):
            self.customize_amazon(customized_path)

        _start_load_meta_table = time.time()
        print(
            "# start load amazon meta ({:d}MB)".format(
                path.getsize(customized_path) // 2**20
            )
        )

        self.metadata = pd.read_csv(customized_path)
        self.metadata["x_string"] = self.metadata["x_string"].astype("str")

        _end_load_meta_table = time.time()
        print(
            "# end load amazon meta ({:.2f}s)".format(
                _end_load_meta_table - _start_load_meta_table
            )
        )

        # insert [MASK]
        # see CodeStructure/misc/huggingface_scriptmodule.py
        # and transformers/models/bert/modeling_bert.py
        # about pooler's behavior
        self.transform = lambda text: npl_preprocess(
            text,
            prefix_tokens=["[MASK]"],
            suffix_tokens=[],
            max_token_num=self.max_token_num,
        )

    def __len__(self):
        return len(self.metadata)

    def __getitem__(self, index):
        y = self.metadata["y"][index]
        domain_id = self.metadata["domain_id"][index]
        return self.get_x(index), y, domain_id

    def get_x(self, index):
        x_string = self.metadata["x_string"][index]
        x = self.transform(x_string)
        return x

    @staticmethod
    def customize_amazon(customized_path):
        # cache customized metadata to customized_path as a csv file

        meta_path = path.join(_WILDS_DATA_DIR, "amazon_v2.1/reviews.csv")
        meta_table = pd.read_csv(meta_path)

        meta_table["reviewText"] = meta_table["reviewText"].astype("str")

        meta_table["y"] = np.int64(meta_table["overall"]) - 1
        meta_table["verified"] = np.int64(meta_table["verified"])
        meta_table["timestamp"] = pd.to_datetime(meta_table["unixReviewTime"], unit="s")

        # make index for domain (year, category)
        years = meta_table["reviewYear"].unique().tolist()
        year2id = {year: index for index, year in enumerate(sorted(years))}
        meta_table["year_id"] = meta_table["reviewYear"].apply(lambda x: year2id[x])
        categoies = meta_table["category"].unique().tolist()
        category2id = {
            category: index for index, category in enumerate(sorted(categoies))
        }
        meta_table["category_id"] = meta_table["category"].apply(
            lambda x: category2id[x]
        )
        meta_table["domain_id"] = (
            meta_table["year_id"] * (meta_table["category_id"].max() + 1)
            + meta_table["category_id"]
        )

        # rename concerned columns, drop irrelevant columns
        concerned = [
            # (old_column_name, new_column_name) in sequence
            ("reviewText", "x_string"),
            ("y", "y"),
            ("domain_id", "domain_id"),
            ("timestamp", "_timestamp"),
            ("year_id", "_year_id"),
            ("category", "_category_name"),
            ("category_id", "_category_id"),
            ("reviewerID", "_user_code"),
            ("asin", "_item_code"),
            ("summary", "_summary"),
            ("verified", "_verified"),
        ]
        meta_table = meta_table.loc[:, [old for old, new in concerned]].rename(
            columns=dict(concerned)
        )

        # sort images by region_id
        meta_table = meta_table.sort_values(by="domain_id")
        meta_table = meta_table.reset_index(drop=True)

        with open(customized_path, "wt") as customized_file:
            meta_table.to_csv(customized_file, index=False, encoding="utf-8")


class DatasetAmazonByCategory(torch_data.Dataset):
    def __init__(self, max_token_num=0):
        torch_data.Dataset.__init__(self)
        self.max_token_num = max_token_num

        customized_path = path.join(_PYCACHE_DIR, "amazon_by_category_customized.csv")
        if not path.exists(customized_path):
            self.customize_amazon_by_category(customized_path)

        _start_load_meta_table = time.time()
        print(
            "# start load amazon_by_category meta ({:d}MB)".format(
                path.getsize(customized_path) // 2**20
            )
        )

        self.metadata = pd.read_csv(customized_path)
        self.metadata["x_string"] = self.metadata["x_string"].astype("str")

        _end_load_meta_table = time.time()
        print(
            "# end load amazon_by_category meta ({:.2f}s)".format(
                _end_load_meta_table - _start_load_meta_table
            )
        )

        # insert [MASK]
        # see CodeStructure/misc/huggingface_scriptmodule.py
        # and transformers/models/bert/modeling_bert.py
        # about pooler's behavior
        self.transform = lambda text: npl_preprocess(
            text,
            prefix_tokens=["[MASK]"],
            suffix_tokens=[],
            max_token_num=self.max_token_num,
        )

    def __len__(self):
        return len(self.metadata)

    def __getitem__(self, index):
        y = self.metadata["y"][index]
        domain_id = self.metadata["domain_id"][index]
        return self.get_x(index), y, domain_id

    def get_x(self, index):
        x_string = self.metadata["x_string"][index]
        x = self.transform(x_string)
        return x

    @staticmethod
    def customize_amazon_by_category(customized_path):
        # cache customized metadata to customized_path as a csv file

        meta_path = path.join(_WILDS_DATA_DIR, "amazon_v2.1/reviews.csv")
        meta_table = pd.read_csv(meta_path)

        meta_table["reviewText"] = meta_table["reviewText"].astype("str")

        meta_table["y"] = np.int64(meta_table["overall"]) - 1
        meta_table["verified"] = np.int64(meta_table["verified"])
        meta_table["timestamp"] = pd.to_datetime(meta_table["unixReviewTime"], unit="s")

        # make index for domain (category, year)
        years = meta_table["reviewYear"].unique().tolist()
        year2id = {year: index for index, year in enumerate(sorted(years))}
        meta_table["year_id"] = meta_table["reviewYear"].apply(lambda x: year2id[x])
        categoies = meta_table["category"].unique().tolist()
        category2id = {
            category: index for index, category in enumerate(sorted(categoies))
        }
        meta_table["category_id"] = meta_table["category"].apply(
            lambda x: category2id[x]
        )
        meta_table["domain_id"] = (
            meta_table["category_id"] * (meta_table["year_id"].max() + 1)
            + meta_table["year_id"]
        )

        # rename concerned columns, drop irrelevant columns
        concerned = [
            # (old_column_name, new_column_name) in sequence
            ("reviewText", "x_string"),
            ("y", "y"),
            ("domain_id", "domain_id"),
            ("timestamp", "_timestamp"),
            ("year_id", "_year_id"),
            ("category", "_category_name"),
            ("category_id", "_category_id"),
            ("reviewerID", "_user_code"),
            ("asin", "_item_code"),
            ("summary", "_summary"),
            ("verified", "_verified"),
        ]
        meta_table = meta_table.loc[:, [old for old, new in concerned]].rename(
            columns=dict(concerned)
        )

        # sort images by region_id
        meta_table = meta_table.sort_values(by="domain_id")
        meta_table = meta_table.reset_index(drop=True)

        with open(customized_path, "wt") as customized_file:
            meta_table.to_csv(customized_file, index=False, encoding="utf-8")


class DatasetAmazonOneTenth(DatasetAmazon):
    def __init__(self, max_token_num=0):
        torch_data.Dataset.__init__(self)
        self.max_token_num = max_token_num

        customized_path = path.join(_PYCACHE_DIR, "amazon_customized_one_tenth.csv")
        if not path.exists(customized_path):
            self.customize_amazon_one_tenth(customized_path)

        _start_load_meta_table = time.time()
        print(
            "# start load one tenth amazon meta ({:d}MB)".format(
                path.getsize(customized_path) // 2**20
            )
        )

        self.metadata = pd.read_csv(customized_path)
        self.metadata["x_string"] = self.metadata["x_string"].astype("str")

        _end_load_meta_table = time.time()
        print(
            "# end load one tenth amazon meta ({:.2f}s)".format(
                _end_load_meta_table - _start_load_meta_table
            )
        )

        # insert [MASK]
        # see CodeStructure/misc/huggingface_scriptmodule.py
        # and transformers/models/bert/modeling_bert.py
        # about pooler's behavior
        self.transform = lambda text: npl_preprocess(
            text,
            prefix_tokens=["[MASK]"],
            suffix_tokens=[],
            max_token_num=self.max_token_num,
        )

    @staticmethod
    def customize_amazon_one_tenth(customized_path):
        full_path = path.join(_PYCACHE_DIR, "amazon_customized.csv")
        if not path.exists(full_path):
            DatasetAmazon.customize_amazon(full_path)

        _start_load_meta_table = time.time()
        print(
            "# start load amazon meta ({:d}MB)".format(path.getsize(full_path) // 2**20)
        )

        meta_table = pd.read_csv(full_path)

        _end_load_meta_table = time.time()
        print(
            "# end load amazon meta ({:.2f}s)".format(
                _end_load_meta_table - _start_load_meta_table
            )
        )

        # randomly keep one tenth of records
        fixed_rng = np.random.default_rng(seed=0)
        meta_table["_temp_domain_id_perturbed"] = meta_table[
            "domain_id"
        ] + fixed_rng.random(size=meta_table["domain_id"].shape)
        meta_table = meta_table.sort_values(by="_temp_domain_id_perturbed")
        meta_table = meta_table.drop(columns=["_temp_domain_id_perturbed"])
        meta_table = meta_table.iloc[::10]

        with open(customized_path, "wt") as customized_file:
            meta_table.to_csv(customized_file, index=False, encoding="utf-8")
