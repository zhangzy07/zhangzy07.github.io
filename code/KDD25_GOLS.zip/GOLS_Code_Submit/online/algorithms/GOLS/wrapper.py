import random

from tqdm import tqdm

import numpy as np

import torch
import torch.optim as optim
import torch.utils
import torch.utils.data as torch_data

from utils_pkg import exp_config
from utils_pkg.convex_opt.qp import (
    solve_gem_qp,
    solve_kmm_qp,
    make_sure_positive_definite,
)
from online.algorithms.General.DNN_FIX import DNN_FIX as DNN_FIX_abc
from online.algorithms.General.DNN_ogd import DNN_OGD as DNN_OGD_abc
from online.algorithms.General.DNN_gem import DNN_GEM as DNN_GEM_abc
from online.algorithms.General.DNN_agem import DNN_AGEM as DNN_AGEM_abc
from online.algorithms.GOLS.DNN_MaskOGD import DNN_MaskOGD as DNN_MaskOGD_abc


class DNN_MaskOGD(DNN_MaskOGD_abc):
    def __init__(self, cfgs: exp_config.Config, stepsize=0.0, **algo_kwargs):
        super(DNN_MaskOGD, self).__init__(cfgs=cfgs, stepsize=stepsize, **algo_kwargs)


class DNN_FIX(DNN_FIX_abc):
    def __init__(self, cfgs: exp_config.Config, stepsize=0.0, **algo_kwargs):
        super(DNN_FIX, self).__init__(cfgs=cfgs, stepsize=stepsize, **algo_kwargs)

    def opt_rep(self, dataloader):
        pass

    def opt_cls(self, dataloader):
        pass

    def alg_forward(self, x, y, domain_id):
        pass


class DNN_Skyline(DNN_OGD_abc):
    def __init__(self, cfgs: exp_config.Config, stepsize=0.0, **algo_kwargs):
        super(DNN_Skyline, self).__init__(cfgs=cfgs, stepsize=stepsize, **algo_kwargs)

        self.update_rounds = self.cfgs.online_cfgs.kwargs["update_rounds"]
        self.rep_lr = self.cfgs.online_cfgs.kwargs["rep_lr"]
        self.cls_lr = self.cfgs.online_cfgs.kwargs["cls_lr"]
        self.rep_batch_size = self.cfgs.online_cfgs.kwargs["rep_batch_size"]
        self.cls_batch_size = self.cfgs.online_cfgs.kwargs["cls_batch_size"]
        self.num_workers = self.cfgs.hardware_cfgs.kwargs.get("num_workers", 8)

    def opt_rep(self, dataloader):
        pass

    def opt_cls(self, dataloader):
        self.online_rep_model = self.online_rep_model.to(self.device)
        self.online_cls_model = self.online_cls_model.to(self.device)
        self.online_rep_model.eval()
        self.online_cls_model.train()
        loss_func = torch.nn.CrossEntropyLoss()
        optimizer = optim.SGD(self.online_cls_model.parameters(), lr=self.cls_lr)

        for x, y, domain_id in dataloader:
            optimizer.zero_grad()
            x = x.to(self.device)
            y = y.to(self.device)
            z = self.online_rep_model(x)
            y_pred = self.online_cls_model(z)
            loss = loss_func(y_pred, y)
            loss.backward()

            if self.grad_clip:
                torch.nn.utils.clip_grad_norm_(
                    self.online_cls_model.parameters(), 1.0, norm_type=1.0
                )
            optimizer.step()

    def alg_forward(self, x, y, domain_id):
        dataset = torch_data.TensorDataset(x, y, domain_id)
        for round in range(self.update_rounds):
            # rep_dataloader = torch_data.DataLoader(
            #     dataset,
            #     batch_size=self.rep_batch_size,
            #     shuffle=True,
            #     # num_workers=self.num_workers,
            # )
            # self.opt_rep(rep_dataloader)
            cls_dataloader = torch_data.DataLoader(
                dataset,
                batch_size=self.cls_batch_size,
                shuffle=True,
                # num_workers=self.num_workers,
            )
            self.opt_cls(cls_dataloader)


class LAMEAffinityMatrix:
    def __init__(self, **kwargs):
        pass

    def __call__(X, **kwargs):
        raise NotImplementedError

    def is_psd(self, mat):
        eigenvalues = torch.eig(mat)[0][:, 0].sort(descending=True)[0]
        return eigenvalues, float((mat == mat.t()).all() and (eigenvalues >= 0).all())

    def symmetrize(self, mat):
        return 1 / 2 * (mat + mat.t())


class lame_knn_affinity(LAMEAffinityMatrix):
    def __init__(self, knn: int, **kwargs):
        self.knn = knn

    def __call__(self, X):
        N = X.size(0)
        dist = torch.norm(X.unsqueeze(0) - X.unsqueeze(1), dim=-1, p=2)  # [N, N]
        n_neighbors = min(self.knn + 1, N)
        knn_index = dist.topk(n_neighbors, -1, largest=False).indices[:, 1:]  # [N, knn]
        W = torch.zeros(N, N, device=X.device)
        W.scatter_(dim=-1, index=knn_index, value=1.0)
        return W.to(torch.float32)


class lame_rbf_affinity(LAMEAffinityMatrix):
    def __init__(self, sigma: float, knn: int, **kwargs):
        self.sigma = sigma
        self.k = knn

    def __call__(self, X):
        N = X.size(0)
        dist = torch.norm(X.unsqueeze(0) - X.unsqueeze(1), dim=-1, p=2)  # [N, N]
        n_neighbors = min(self.k, N)
        kth_dist = dist.topk(k=n_neighbors, dim=-1, largest=False).values[:, -1]
        # compute k^th distance for each point, [N, knn + 1]
        sigma = kth_dist.mean()
        rbf = torch.exp(-(dist**2) / (2 * sigma**2))
        # mask = torch.eye(X.size(0)).to(X.device)
        # rbf = rbf * (1 - mask)
        return rbf.to(torch.float32)


def lame_entropy_energy(Y, unary, pairwise, bound_lambda):
    E = (unary * Y - bound_lambda * pairwise * Y + Y * torch.log(Y.clip(1e-20))).sum()
    return E


def lame_laplacian_optimization(unary, kernel, bound_lambda=1, max_steps=100):
    E_list = []
    oldE = float("inf")
    Y = (-unary).softmax(-1)  # [N, K]
    for i in range(max_steps):
        pairwise = bound_lambda * kernel.matmul(Y)  # [N, K]
        exponent = -unary + pairwise
        Y = exponent.softmax(-1)
        E = lame_entropy_energy(Y, unary, pairwise, bound_lambda).item()
        E_list.append(E)
        if i > 1 and (abs(E - oldE) <= 1e-8 * abs(oldE)):
            # print(f"Converged in {i} iterations")
            break
        else:
            oldE = E
    return Y


class DNN_LAME(DNN_FIX_abc):
    """https://github.com/fiveai/LAME/blob/d2e5f63090bc1c8129bf7cbd781029a5955e1a67/src/adaptation/lame.py#L92"""

    def __init__(self, cfgs: exp_config.Config, stepsize=0.0, **algo_kwargs):
        super(DNN_LAME, self).__init__(cfgs=cfgs, stepsize=stepsize, **algo_kwargs)

    def opt_rep(self, dataloader):
        pass

    def opt_cls(self, dataloader):
        pass

    def alg_forward(self, x, y, domain_id):
        pass

    @torch.no_grad()
    def predict(self, data, return_logits=False):
        self.online_cls_model.eval()
        self.online_cls_model = self.online_cls_model.cpu()
        if self.online_rep_model:
            self.online_rep_model.eval()
            self.online_rep_model = self.online_rep_model.to(self.device)

        data = data.to(self.device)
        _dtype_name = repr(data.dtype)
        if "float" in _dtype_name or "double" in _dtype_name:
            data = data.to(torch.float32)
        elif "long" in _dtype_name or "int" in _dtype_name:
            data = data.to(torch.long)

        if self.online_rep_model is not None:
            data = self.online_rep_model(data)
        data = data.detach().cpu()
        output = self.online_cls_model(data)

        output = output.detach().cpu()
        unary = -torch.log(torch.softmax(output, dim=1) + 1e-10)
        feats = torch.nn.functional.normalize(output, p=2, dim=1)
        affmat = lame_knn_affinity(knn=4)
        kernel = affmat(feats)
        kernel = torch.FloatTensor(make_sure_positive_definite(kernel.numpy()))
        y_pred = lame_laplacian_optimization(unary, kernel)

        if return_logits:
            return y_pred
        else:
            return y_pred.argmax(-1)


class DNN_OGD(DNN_OGD_abc):
    def __init__(self, cfgs: exp_config.Config, stepsize=0.0, **algo_kwargs):
        super(DNN_OGD, self).__init__(cfgs=cfgs, stepsize=stepsize, **algo_kwargs)

        self.update_rounds = self.cfgs.online_cfgs.kwargs["update_rounds"]
        self.rep_lr = self.cfgs.online_cfgs.kwargs["rep_lr"]
        self.cls_lr = self.cfgs.online_cfgs.kwargs["cls_lr"]
        self.rep_batch_size = self.cfgs.online_cfgs.kwargs["rep_batch_size"]
        self.cls_batch_size = self.cfgs.online_cfgs.kwargs["cls_batch_size"]
        self.num_workers = self.cfgs.hardware_cfgs.kwargs.get("num_workers", 8)

    def opt_rep(self, dataloader):
        self.online_rep_model = self.online_rep_model.to(self.device)
        self.online_cls_model = self.online_cls_model.to(self.device)
        self.online_rep_model.train()
        self.online_cls_model.eval()
        loss_func = torch.nn.CrossEntropyLoss()
        optimizer = optim.SGD(self.online_rep_model.parameters(), lr=self.rep_lr)

        for x, y, domain_id in dataloader:
            optimizer.zero_grad()
            x = x.to(self.device)
            y = y.to(self.device)
            z = self.online_rep_model(x)
            y_pred = self.online_cls_model(z)
            loss = loss_func(y_pred, y)
            loss.backward()

            if self.grad_clip:
                torch.nn.utils.clip_grad_norm_(
                    self.online_rep_model.parameters(), 1.0, norm_type=1.0
                )
            optimizer.step()

    def opt_cls(self, dataloader):
        self.online_rep_model = self.online_rep_model.to(self.device)
        self.online_cls_model = self.online_cls_model.to(self.device)
        self.online_rep_model.eval()
        self.online_cls_model.train()
        loss_func = torch.nn.CrossEntropyLoss()
        optimizer = optim.SGD(self.online_cls_model.parameters(), lr=self.cls_lr)

        for x, y, domain_id in dataloader:
            optimizer.zero_grad()
            x = x.to(self.device)
            y = y.to(self.device)
            z = self.online_rep_model(x)
            y_pred = self.online_cls_model(z)
            loss = loss_func(y_pred, y)
            loss.backward()

            if self.grad_clip:
                torch.nn.utils.clip_grad_norm_(
                    self.online_cls_model.parameters(), 1.0, norm_type=1.0
                )
            optimizer.step()

    def alg_forward(self, x, y, domain_id):
        dataset = torch_data.TensorDataset(x, y, domain_id)
        for round in range(self.update_rounds):
            rep_dataloader = torch_data.DataLoader(
                dataset,
                batch_size=self.rep_batch_size,
                shuffle=True,
                # num_workers=self.num_workers,
            )
            self.opt_rep(rep_dataloader)
            cls_dataloader = torch_data.DataLoader(
                dataset,
                batch_size=self.cls_batch_size,
                shuffle=True,
                # num_workers=self.num_workers,
            )
            self.opt_cls(cls_dataloader)


class DNN_OGD1(DNN_OGD_abc):
    def __init__(self, cfgs: exp_config.Config, stepsize=0.0, **algo_kwargs):
        super(DNN_OGD1, self).__init__(cfgs=cfgs, stepsize=stepsize, **algo_kwargs)

        self.update_rounds = self.cfgs.online_cfgs.kwargs["update_rounds"]
        self.rep_lr = self.cfgs.online_cfgs.kwargs["rep_lr"]
        self.cls_lr = self.cfgs.online_cfgs.kwargs["cls_lr"]
        self.rep_batch_size = self.cfgs.online_cfgs.kwargs["rep_batch_size"]
        self.cls_batch_size = self.cfgs.online_cfgs.kwargs["cls_batch_size"]
        self.num_workers = self.cfgs.hardware_cfgs.kwargs.get("num_workers", 8)

        self.sqrt_lr = 1.0

    def opt_rep(self, dataloader):
        self.online_rep_model = self.online_rep_model.to(self.device)
        self.online_cls_model = self.online_cls_model.to(self.device)
        self.online_rep_model.train()
        self.online_cls_model.eval()
        loss_func = torch.nn.CrossEntropyLoss()
        optimizer = optim.SGD(
            self.online_rep_model.parameters(), lr=self.rep_lr * self.sqrt_lr
        )

        for x, y, domain_id in dataloader:
            optimizer.zero_grad()
            x = x.to(self.device)
            y = y.to(self.device)
            z = self.online_rep_model(x)
            y_pred = self.online_cls_model(z)
            loss = loss_func(y_pred, y)
            loss.backward()

            if self.grad_clip:
                torch.nn.utils.clip_grad_norm_(
                    self.online_rep_model.parameters(), 1.0, norm_type=1.0
                )
            optimizer.step()

    def opt_cls(self, dataloader):
        self.online_rep_model = self.online_rep_model.to(self.device)
        self.online_cls_model = self.online_cls_model.to(self.device)
        self.online_rep_model.eval()
        self.online_cls_model.train()
        loss_func = torch.nn.CrossEntropyLoss()
        optimizer = optim.SGD(
            self.online_cls_model.parameters(), lr=self.cls_lr * self.sqrt_lr
        )

        for x, y, domain_id in dataloader:
            optimizer.zero_grad()
            x = x.to(self.device)
            y = y.to(self.device)
            z = self.online_rep_model(x)
            y_pred = self.online_cls_model(z)
            loss = loss_func(y_pred, y)
            loss.backward()

            if self.grad_clip:
                torch.nn.utils.clip_grad_norm_(
                    self.online_cls_model.parameters(), 1.0, norm_type=1.0
                )
            optimizer.step()

    def alg_forward(self, x, y, domain_id):
        ogd_sqrt_lr_scale = self.cfgs.online_cfgs.kwargs.get(
            "ogd_sqrt_lr_scale", self.update_rounds / 4
        )
        dataset = torch_data.TensorDataset(x, y, domain_id)
        for round in range(self.update_rounds):
            self.sqrt_lr = 1.0 / np.sqrt(1.0 + round / ogd_sqrt_lr_scale)
            assert self.sqrt_lr <= 1.0
            rep_dataloader = torch_data.DataLoader(
                dataset,
                batch_size=self.rep_batch_size,
                shuffle=True,
                # num_workers=self.num_workers,
            )
            self.opt_rep(rep_dataloader)
            cls_dataloader = torch_data.DataLoader(
                dataset,
                batch_size=self.cls_batch_size,
                shuffle=True,
                # num_workers=self.num_workers,
            )
            self.opt_cls(cls_dataloader)


class DNN_AGEM(DNN_AGEM_abc):
    def __init__(self, cfgs: exp_config.Config, stepsize=0.0, **algo_kwargs):
        super(DNN_AGEM, self).__init__(cfgs=cfgs, stepsize=stepsize, **algo_kwargs)

        self.train_set = self.alg_kwargs["dataset"]
        self.train_indecies = list(range(len(self.train_set)))
        self.test_set = []
        self.test_indecies = []

        self.update_rounds = self.cfgs.online_cfgs.kwargs["update_rounds"]
        self.rep_lr = self.cfgs.online_cfgs.kwargs["rep_lr"]
        self.cls_lr = self.cfgs.online_cfgs.kwargs["cls_lr"]
        self.rep_batch_size = self.cfgs.online_cfgs.kwargs["rep_batch_size"]
        self.cls_batch_size = self.cfgs.online_cfgs.kwargs["cls_batch_size"]
        self.num_workers = self.cfgs.hardware_cfgs.kwargs.get("num_workers", 8)

    def stratified_sample(self, sample_size):
        lucky = []
        random.shuffle(self.test_indecies)
        random.shuffle(self.train_indecies)
        n_test = round(
            sample_size
            * len(self.test_indecies)
            / (len(self.train_indecies) + len(self.test_indecies))
        )
        n_train = sample_size - n_test
        for i_test in self.test_indecies[:n_test]:
            lucky.append(self.test_set[i_test])
        for i_train in self.train_indecies[:n_train]:
            lucky.append(self.train_set[i_train])
        return lucky

    def opt_rep(self, dataloader):
        self.online_rep_model = self.online_rep_model.to(self.device)
        self.online_cls_model = self.online_cls_model.to(self.device)
        self.online_rep_model.train()
        self.online_cls_model.eval()
        loss_func = torch.nn.CrossEntropyLoss()
        optimizer = optim.SGD(self.online_rep_model.parameters(), lr=self.rep_lr)

        agem_batch_size = self.cfgs.online_cfgs.kwargs.get("agem_batch_size", 32)

        accum_numel = 0
        para_interval = []
        for para in self.online_rep_model.parameters():
            para_interval.append((accum_numel, accum_numel + para.numel()))
            accum_numel += para.numel()

        for batch, (x, y, domain_id) in enumerate(dataloader):
            optimizer.zero_grad()
            x = x.to(self.device)
            y = y.to(self.device)
            z = self.online_rep_model(x)
            y_pred = self.online_cls_model(z)
            loss = loss_func(y_pred, y)
            loss.backward()

            new_grad = np.concatenate(
                [
                    para.grad.cpu().flatten().numpy()
                    for para in self.online_rep_model.parameters()
                ],
                axis=0,
            )

            x = torch.stack([record[0] for record in self.lucky])
            y = torch.stack([record[1] for record in self.lucky])
            x = x.to(self.device)
            y = y.to(self.device)
            z = self.online_rep_model(x)
            y_pred = self.online_cls_model(z)
            loss = loss_func(y_pred, y)
            loss.backward()

            old_grad = np.concatenate(
                [
                    para.grad.cpu().flatten().numpy()
                    for para in self.online_rep_model.parameters()
                ],
                axis=0,
            )

            agem_grad = (
                new_grad
                - (np.dot(new_grad, old_grad) / np.dot(old_grad, old_grad)) * old_grad
            )
            for (start, end), para in zip(
                para_interval, self.online_rep_model.parameters()
            ):
                para.grad = (
                    torch.FloatTensor(agem_grad[start:end])
                    .reshape(para.shape)
                    .to(self.device)
                )

            if self.grad_clip:
                torch.nn.utils.clip_grad_norm_(
                    self.online_rep_model.parameters(), 1.0, norm_type=1.0
                )
            optimizer.step()

    def opt_cls(self, dataloader):
        self.online_rep_model = self.online_rep_model.to(self.device)
        self.online_cls_model = self.online_cls_model.to(self.device)
        self.online_rep_model.eval()
        self.online_cls_model.train()
        loss_func = torch.nn.CrossEntropyLoss()
        optimizer = optim.SGD(self.online_cls_model.parameters(), lr=self.cls_lr)

        for x, y, domain_id in dataloader:
            optimizer.zero_grad()
            x = x.to(self.device)
            y = y.to(self.device)
            z = self.online_rep_model(x)
            y_pred = self.online_cls_model(z)
            loss = loss_func(y_pred, y)
            loss.backward()

            if self.grad_clip:
                torch.nn.utils.clip_grad_norm_(
                    self.online_cls_model.parameters(), 1.0, norm_type=1.0
                )
            optimizer.step()

    def alg_forward(self, x, y, domain_id):
        agem_batch_size = self.cfgs.online_cfgs.kwargs.get("agem_batch_size", 32)
        self.lucky = self.stratified_sample(agem_batch_size)

        dataset = torch_data.TensorDataset(x, y, domain_id)
        for round in range(self.update_rounds):
            rep_dataloader = torch_data.DataLoader(
                dataset,
                batch_size=self.rep_batch_size,
                shuffle=True,
                # num_workers=self.num_workers,
            )
            self.opt_rep(rep_dataloader)
            cls_dataloader = torch_data.DataLoader(
                dataset,
                batch_size=self.cls_batch_size,
                shuffle=True,
                # num_workers=self.num_workers,
            )
            self.opt_cls(cls_dataloader)

        for index in range(domain_id.size(0)):
            self.test_set.append(
                (x[index].cpu(), y[index].cpu(), domain_id[index].cpu())
            )
        self.test_indecies = list(range(len(self.test_set)))


class DNN_DANN(DNN_OGD_abc):
    """
    https://github.com/fungtion/DANN
    """

    def __init__(self, cfgs: exp_config.Config, stepsize=0.0, **algo_kwargs):
        super(DNN_DANN, self).__init__(cfgs=cfgs, stepsize=stepsize, **algo_kwargs)

        self.online_dom_model = None

        self.train_set = self.alg_kwargs["dataset"]
        self.train_indecies = list(range(len(self.train_set)))
        self.test_set = []
        self.test_indecies = []

        self.update_rounds = self.cfgs.online_cfgs.kwargs["update_rounds"]
        self.rep_lr = self.cfgs.online_cfgs.kwargs["rep_lr"]
        self.cls_lr = self.cfgs.online_cfgs.kwargs["cls_lr"]
        self.rep_batch_size = self.cfgs.online_cfgs.kwargs["rep_batch_size"]
        self.cls_batch_size = self.cfgs.online_cfgs.kwargs["cls_batch_size"]
        self.num_workers = self.cfgs.hardware_cfgs.kwargs.get("num_workers", 8)

    def stratified_sample(self, sample_size):
        lucky = []
        random.shuffle(self.test_indecies)
        random.shuffle(self.train_indecies)
        n_test = round(
            sample_size
            * len(self.test_indecies)
            / (len(self.train_indecies) + len(self.test_indecies))
        )
        n_train = sample_size - n_test
        for i_test in self.test_indecies[:n_test]:
            lucky.append(self.test_set[i_test])
        for i_train in self.train_indecies[:n_train]:
            lucky.append(self.train_set[i_train])
        return lucky

    def opt_rep(self, dataloader):
        self.online_rep_model = self.online_rep_model.to(self.device)
        self.online_cls_model = self.online_cls_model.to(self.device)
        self.online_rep_model.train()
        self.online_cls_model.eval()
        loss_func = torch.nn.CrossEntropyLoss()
        optimizer = optim.SGD(self.online_rep_model.parameters(), lr=self.rep_lr)

        if self.online_dom_model:
            self.online_dom_model = self.online_dom_model.to(self.device)
            self.online_dom_model.eval()

        dann_lambda = self.cfgs.online_cfgs.kwargs.get("dann_lambda", 0.0001)
        dann_batch_size = self.cfgs.online_cfgs.kwargs.get(
            "dann_batch_size", self.rep_batch_size
        )

        for x_tgt, y_tgt, domain_id_tgt in dataloader:
            optimizer.zero_grad()
            x_tgt = x_tgt.to(self.device)
            # y_tgt = y_tgt.to(self.device)
            z_tgt = self.online_rep_model(x_tgt)
            # y_pred_tgt = self.online_cls_model(z_tgt)

            x_src = torch.stack([record[0] for record in self.lucky])
            y_src = torch.stack([record[1] for record in self.lucky])
            # domain_id_src = torch.stack([record[2] for record in self.lucky])
            x_src = x_src.to(self.device)
            y_src = y_src.to(self.device)
            z_src = self.online_rep_model(x_src)
            y_pred_src = self.online_cls_model(z_src)

            iw = torch.ones((z_src.size(0), 1)).to(self.device)

            if self.online_dom_model is None:
                feature_dim = z_src.size(1)

            else:
                cls_loss = loss_func(y_pred_src, y_src)
                ssl_loss = torch.mean(iw * self.online_dom_model(z_src)) - torch.mean(
                    self.online_dom_model(z_tgt)
                )
                loss = cls_loss + dann_lambda * ssl_loss
                loss.backward()

                if self.grad_clip:
                    torch.nn.utils.clip_grad_norm_(
                        self.online_rep_model.parameters(), 1.0, norm_type=1.0
                    )
                optimizer.step()

        if self.online_dom_model is None:
            self.online_dom_model = torch.nn.Linear(feature_dim, 1)

    def opt_cls(self, dataloader):
        self.online_rep_model = self.online_rep_model.to(self.device)
        self.online_cls_model = self.online_cls_model.to(self.device)
        self.online_rep_model.eval()
        self.online_cls_model.train()
        loss_func = torch.nn.CrossEntropyLoss()
        optimizer = optim.SGD(self.online_cls_model.parameters(), lr=self.cls_lr)

        for x, y, domain_id in dataloader:
            optimizer.zero_grad()
            x = x.to(self.device)
            y = y.to(self.device)
            z = self.online_rep_model(x)
            y_pred = self.online_cls_model(z)
            loss = loss_func(y_pred, y)
            loss.backward()

            if self.grad_clip:
                torch.nn.utils.clip_grad_norm_(
                    self.online_cls_model.parameters(), 1.0, norm_type=1.0
                )
            optimizer.step()

        self.online_dom_model = self.online_dom_model.to(self.device)
        self.online_dom_model.train()
        optimizer = optim.SGD(self.online_cls_model.parameters(), lr=self.cls_lr)

        dann_batch_size = self.cfgs.online_cfgs.kwargs.get(
            "dann_batch_size", self.rep_batch_size
        )

        for x_tgt, y_tgt, domain_id_tgt in dataloader:
            optimizer.zero_grad()
            x_tgt = x_tgt.to(self.device)
            # y_tgt = y_tgt.to(self.device)
            z_tgt = self.online_rep_model(x_tgt)

            x_src = torch.stack([record[0] for record in self.lucky])
            y_src = torch.stack([record[1] for record in self.lucky])
            # domain_id_src = torch.stack([record[2] for record in self.lucky])
            x_src = x_src.to(self.device)
            y_src = y_src.to(self.device)
            z_src = self.online_rep_model(x_src)

            loss = torch.mean(self.online_dom_model(z_tgt)) - torch.mean(
                self.online_dom_model(z_src)
            )
            loss.backward()

            if self.grad_clip:
                torch.nn.utils.clip_grad_norm_(
                    self.online_cls_model.parameters(), 1.0, norm_type=1.0
                )
            optimizer.step()

    def alg_forward(self, x, y, domain_id):
        dann_batch_size = self.cfgs.online_cfgs.kwargs.get(
            "dann_batch_size", self.rep_batch_size
        )
        self.lucky = self.stratified_sample(dann_batch_size)

        dataset = torch_data.TensorDataset(x, y, domain_id)
        for round in range(self.update_rounds):
            rep_dataloader = torch_data.DataLoader(
                dataset,
                batch_size=self.rep_batch_size,
                shuffle=True,
                # num_workers=self.num_workers,
            )
            self.opt_rep(rep_dataloader)
            cls_dataloader = torch_data.DataLoader(
                dataset,
                batch_size=self.cls_batch_size,
                shuffle=True,
                # num_workers=self.num_workers,
            )
            self.opt_cls(cls_dataloader)

        for index in range(domain_id.size(0)):
            self.test_set.append(
                (x[index].cpu(), y[index].cpu(), domain_id[index].cpu())
            )
        self.test_indecies = list(range(len(self.test_set)))


class DNN_IWDAN(DNN_OGD_abc):

    def __init__(self, cfgs: exp_config.Config, stepsize=0.0, **algo_kwargs):
        super(DNN_IWDAN, self).__init__(cfgs=cfgs, stepsize=stepsize, **algo_kwargs)

        self.online_dom_model = None

        self.train_set = self.alg_kwargs["dataset"]
        self.train_indecies = list(range(len(self.train_set)))
        self.test_set = []
        self.test_indecies = []

        self.update_rounds = self.cfgs.online_cfgs.kwargs["update_rounds"]
        self.rep_lr = self.cfgs.online_cfgs.kwargs["rep_lr"]
        self.cls_lr = self.cfgs.online_cfgs.kwargs["cls_lr"]
        self.rep_batch_size = self.cfgs.online_cfgs.kwargs["rep_batch_size"]
        self.cls_batch_size = self.cfgs.online_cfgs.kwargs["cls_batch_size"]
        self.num_workers = self.cfgs.hardware_cfgs.kwargs.get("num_workers", 8)

    def stratified_sample(self, sample_size):
        lucky = []
        random.shuffle(self.test_indecies)
        random.shuffle(self.train_indecies)
        n_test = round(
            sample_size
            * len(self.test_indecies)
            / (len(self.train_indecies) + len(self.test_indecies))
        )
        n_train = sample_size - n_test
        for i_test in self.test_indecies[:n_test]:
            lucky.append(self.test_set[i_test])
        for i_train in self.train_indecies[:n_train]:
            lucky.append(self.train_set[i_train])
        return lucky

    def opt_rep(self, dataloader):
        self.online_rep_model = self.online_rep_model.to(self.device)
        self.online_cls_model = self.online_cls_model.to(self.device)
        self.online_rep_model.train()
        self.online_cls_model.eval()
        loss_func = torch.nn.CrossEntropyLoss()
        optimizer = optim.SGD(self.online_rep_model.parameters(), lr=self.rep_lr)

        if self.online_dom_model:
            self.online_dom_model = self.online_dom_model.to(self.device)
            self.online_dom_model.eval()

        iwdan_lambda = self.cfgs.online_cfgs.kwargs.get("iwdan_lambda", 0.001)
        iwdan_batch_size = self.cfgs.online_cfgs.kwargs.get(
            "iwdan_batch_size", self.rep_batch_size
        )
        iwdan_buffer_size = self.cfgs.online_cfgs.kwargs.get(
            "iwdan_buffer_size", self.rep_batch_size
        )

        for x_tgt, y_tgt, domain_id_tgt in dataloader:
            optimizer.zero_grad()
            x_tgt = x_tgt.to(self.device)
            # y_tgt = y_tgt.to(self.device)
            z_tgt = self.online_rep_model(x_tgt)
            # y_pred_tgt = self.online_cls_model(z_tgt)

            x_src = torch.stack([record[0] for record in self.lucky])
            y_src = torch.stack([record[1] for record in self.lucky])
            # domain_id_src = torch.stack([record[2] for record in self.lucky])
            x_src = x_src.to(self.device)
            y_src = y_src.to(self.device)
            z_src = self.online_rep_model(x_src)
            y_pred_src = self.online_cls_model(z_src)

            f_src = z_src.detach().cpu()
            f_tgt = z_tgt.detach().cpu()
            rbf_sigma = torch.quantile(torch.norm(f_src, dim=1), q=0.5).item()
            iw = solve_kmm_qp(f_src.numpy(), f_tgt.numpy(), rbf_sigma)
            iw = torch.FloatTensor(iw.reshape((-1, 1))).to(self.device)

            if self.online_dom_model is None:
                feature_dim = z_src.size(1)

            else:
                cls_loss = loss_func(y_pred_src, y_src)
                ssl_loss = torch.mean(iw * self.online_dom_model(z_src)) - torch.mean(
                    self.online_dom_model(z_tgt)
                )
                loss = cls_loss + iwdan_lambda * ssl_loss
                loss.backward()

                if self.grad_clip:
                    torch.nn.utils.clip_grad_norm_(
                        self.online_rep_model.parameters(), 1.0, norm_type=1.0
                    )
                optimizer.step()

        if self.online_dom_model is None:
            self.online_dom_model = torch.nn.Linear(feature_dim, 1)

    def opt_cls(self, dataloader):
        self.online_rep_model = self.online_rep_model.to(self.device)
        self.online_cls_model = self.online_cls_model.to(self.device)
        self.online_rep_model.eval()
        self.online_cls_model.train()
        loss_func = torch.nn.CrossEntropyLoss()
        optimizer = optim.SGD(self.online_cls_model.parameters(), lr=self.cls_lr)

        for x, y, domain_id in dataloader:
            optimizer.zero_grad()
            x = x.to(self.device)
            y = y.to(self.device)
            z = self.online_rep_model(x)
            y_pred = self.online_cls_model(z)
            loss = loss_func(y_pred, y)
            loss.backward()

            if self.grad_clip:
                torch.nn.utils.clip_grad_norm_(
                    self.online_cls_model.parameters(), 1.0, norm_type=1.0
                )
            optimizer.step()

        self.online_dom_model = self.online_dom_model.to(self.device)
        self.online_dom_model.train()
        optimizer = optim.SGD(self.online_cls_model.parameters(), lr=self.cls_lr)

        iwdan_batch_size = self.cfgs.online_cfgs.kwargs.get(
            "iwdan_batch_size", self.rep_batch_size
        )

        for x_tgt, y_tgt, domain_id_tgt in dataloader:
            optimizer.zero_grad()
            x_tgt = x_tgt.to(self.device)
            # y_tgt = y_tgt.to(self.device)
            z_tgt = self.online_rep_model(x_tgt)

            x_src = torch.stack([record[0] for record in self.lucky])
            y_src = torch.stack([record[1] for record in self.lucky])
            # domain_id_src = torch.stack([record[2] for record in self.lucky])
            x_src = x_src.to(self.device)
            y_src = y_src.to(self.device)
            z_src = self.online_rep_model(x_src)

            loss = torch.mean(self.online_dom_model(z_tgt)) - torch.mean(
                self.online_dom_model(z_src)
            )
            loss.backward()

            if self.grad_clip:
                torch.nn.utils.clip_grad_norm_(
                    self.online_cls_model.parameters(), 1.0, norm_type=1.0
                )
            optimizer.step()

    def alg_forward(self, x, y, domain_id):
        iwdan_batch_size = self.cfgs.online_cfgs.kwargs.get(
            "iwdan_batch_size", self.rep_batch_size
        )
        self.lucky = self.stratified_sample(iwdan_batch_size)

        dataset = torch_data.TensorDataset(x, y, domain_id)
        for round in range(self.update_rounds):
            rep_dataloader = torch_data.DataLoader(
                dataset,
                batch_size=self.rep_batch_size,
                shuffle=True,
                # num_workers=self.num_workers,
            )
            self.opt_rep(rep_dataloader)
            cls_dataloader = torch_data.DataLoader(
                dataset,
                batch_size=self.cls_batch_size,
                shuffle=True,
                # num_workers=self.num_workers,
            )
            self.opt_cls(cls_dataloader)

        for index in range(domain_id.size(0)):
            self.test_set.append(
                (x[index].cpu(), y[index].cpu(), domain_id[index].cpu())
            )
        self.test_indecies = list(range(len(self.test_set)))


class DNN_HAL(DNN_OGD_abc):

    def __init__(self, cfgs: exp_config.Config, stepsize=0.0, **algo_kwargs):
        super(DNN_HAL, self).__init__(cfgs=cfgs, stepsize=stepsize, **algo_kwargs)

        self.train_set = self.alg_kwargs["dataset"]
        self.train_indecies = list(range(len(self.train_set)))
        self.test_set = []
        self.test_indecies = []

        self.anchor_x = None
        self.anchor_z = None

        self.update_rounds = self.cfgs.online_cfgs.kwargs["update_rounds"]
        self.rep_lr = self.cfgs.online_cfgs.kwargs["rep_lr"]
        self.cls_lr = self.cfgs.online_cfgs.kwargs["cls_lr"]
        self.rep_batch_size = self.cfgs.online_cfgs.kwargs["rep_batch_size"]
        self.cls_batch_size = self.cfgs.online_cfgs.kwargs["cls_batch_size"]
        self.num_workers = self.cfgs.hardware_cfgs.kwargs.get("num_workers", 8)

    def stratified_sample(self, sample_size):
        lucky = []
        random.shuffle(self.test_indecies)
        random.shuffle(self.train_indecies)
        n_test = round(
            sample_size
            * len(self.test_indecies)
            / (len(self.train_indecies) + len(self.test_indecies))
        )
        n_train = sample_size - n_test
        for i_test in self.test_indecies[:n_test]:
            lucky.append(self.test_set[i_test])
        for i_train in self.train_indecies[:n_train]:
            lucky.append(self.train_set[i_train])
        return lucky

    def opt_rep(self, dataloader):
        self.online_rep_model = self.online_rep_model.to(self.device)
        self.online_cls_model = self.online_cls_model.to(self.device)
        self.online_rep_model.train()
        self.online_cls_model.eval()
        loss_func = torch.nn.CrossEntropyLoss()
        optimizer = optim.SGD(self.online_rep_model.parameters(), lr=self.rep_lr)

        hal_lambda = self.cfgs.online_cfgs.kwargs.get("hal_lambda", 0.02)
        hal_anchor_lr = self.cfgs.online_cfgs.kwargs.get("hal_anchor_lr", self.rep_lr)
        hal_batch_size = self.cfgs.online_cfgs.kwargs.get(
            "hal_batch_size", self.rep_batch_size
        )

        for x_tgt, y_tgt, domain_id_tgt in dataloader:

            # bert-mini overload
            if self.cfgs.data_cfgs.name == "gols" and self.cfgs.data_cfgs.kwargs[
                "gols_name"
            ] in (
                "amazon",
                "amazon_by_category",
            ):

                optimizer.zero_grad()
                x_tgt = x_tgt.to(self.device)
                y_tgt = y_tgt.to(self.device)
                e_tgt = self.online_rep_model.embeddings(x_tgt)
                z_tgt = self.online_rep_model.pooler(
                    self.online_rep_model.encoder(e_tgt)
                )
                y_pred_tgt = self.online_cls_model(z_tgt)

                if self.anchor_x is None:
                    self.anchor_x = torch.mean(e_tgt, dim=0, keepdim=True)
                    self.anchor_x = (
                        self.anchor_x.detach()
                        .clone()
                        .to(self.device)
                        .requires_grad_(True)
                    )

                with torch.no_grad():
                    self.anchor_z = torch.mean(
                        self.online_rep_model.pooler(
                            self.online_rep_model.encoder(self.anchor_x)
                        ),
                        dim=0,
                        keepdim=True,
                    )

                loss = loss_func(y_pred_tgt, y_tgt) + hal_lambda * torch.mean(
                    (z_tgt - self.anchor_z) ** 2
                )
                loss.backward()

                if self.grad_clip:
                    torch.nn.utils.clip_grad_norm_(
                        self.online_rep_model.parameters(), 1.0, norm_type=1.0
                    )
                optimizer.step()

                x_src = torch.stack([record[0] for record in self.lucky])
                y_src = torch.stack([record[1] for record in self.lucky])
                # domain_id_src = torch.stack([record[2] for record in self.lucky])
                x_src = x_src.to(self.device)
                y_src = y_src.to(self.device)
                e_src = self.online_rep_model.embeddings(x_src)
                z_src = self.online_rep_model.pooler(
                    self.online_rep_model.encoder(e_src)
                )
                z_src = self.online_rep_model(x_src)
                y_pred_src = self.online_cls_model(z_src)

                loss = (
                    loss_func(y_pred_src, y_src)
                    - loss_func(y_pred_tgt, y_tgt)
                    - torch.mean(
                        (
                            self.online_rep_model.pooler(
                                self.online_rep_model.encoder(self.anchor_x)
                            )
                            - self.anchor_z
                        )
                        ** 2
                    )
                )
                self.anchor_x = (
                    self.anchor_x
                    + hal_anchor_lr * torch.autograd.grad(loss, self.anchor_x)[0]
                )
                self.anchor_x = (
                    self.anchor_x.detach().clone().to(self.device).requires_grad_(True)
                )

                continue

            optimizer.zero_grad()
            x_tgt = x_tgt.to(self.device)
            y_tgt = y_tgt.to(self.device)
            z_tgt = self.online_rep_model(x_tgt)
            y_pred_tgt = self.online_cls_model(z_tgt)

            if self.anchor_x is None:
                self.anchor_x = torch.mean(x_tgt, dim=0, keepdim=True)
                self.anchor_x = (
                    self.anchor_x.detach().clone().to(self.device).requires_grad_(True)
                )

            with torch.no_grad():
                self.anchor_z = torch.mean(
                    self.online_rep_model(self.anchor_x), dim=0, keepdim=True
                )

            loss = loss_func(y_pred_tgt, y_tgt) + hal_lambda * torch.mean(
                (z_tgt - self.anchor_z) ** 2
            )
            loss.backward()

            if self.grad_clip:
                torch.nn.utils.clip_grad_norm_(
                    self.online_rep_model.parameters(), 1.0, norm_type=1.0
                )
            optimizer.step()

            x_src = torch.stack([record[0] for record in self.lucky])
            y_src = torch.stack([record[1] for record in self.lucky])
            # domain_id_src = torch.stack([record[2] for record in self.lucky])
            x_src = x_src.to(self.device)
            y_src = y_src.to(self.device)
            z_src = self.online_rep_model(x_src)
            y_pred_src = self.online_cls_model(z_src)

            loss = (
                loss_func(y_pred_src, y_src)
                - loss_func(y_pred_tgt, y_tgt)
                - torch.mean(
                    (self.online_rep_model(self.anchor_x) - self.anchor_z) ** 2
                )
            )
            self.anchor_x = (
                self.anchor_x
                + hal_anchor_lr * torch.autograd.grad(loss, self.anchor_x)[0]
            )
            self.anchor_x = (
                self.anchor_x.detach().clone().to(self.device).requires_grad_(True)
            )

    def opt_cls(self, dataloader):
        self.online_rep_model = self.online_rep_model.to(self.device)
        self.online_cls_model = self.online_cls_model.to(self.device)
        self.online_rep_model.eval()
        self.online_cls_model.train()
        loss_func = torch.nn.CrossEntropyLoss()
        optimizer = optim.SGD(self.online_cls_model.parameters(), lr=self.cls_lr)

        for x, y, domain_id in dataloader:
            optimizer.zero_grad()
            x = x.to(self.device)
            y = y.to(self.device)
            z = self.online_rep_model(x)
            y_pred = self.online_cls_model(z)
            loss = loss_func(y_pred, y)
            loss.backward()

            if self.grad_clip:
                torch.nn.utils.clip_grad_norm_(
                    self.online_cls_model.parameters(), 1.0, norm_type=1.0
                )
            optimizer.step()

    def alg_forward(self, x, y, domain_id):
        hal_batch_size = self.cfgs.online_cfgs.kwargs.get(
            "hal_batch_size", self.rep_batch_size
        )
        self.lucky = self.stratified_sample(hal_batch_size)

        dataset = torch_data.TensorDataset(x, y, domain_id)
        for round in range(self.update_rounds):
            rep_dataloader = torch_data.DataLoader(
                dataset,
                batch_size=self.rep_batch_size,
                shuffle=True,
                # num_workers=self.num_workers,
            )
            self.opt_rep(rep_dataloader)
            cls_dataloader = torch_data.DataLoader(
                dataset,
                batch_size=self.cls_batch_size,
                shuffle=True,
                # num_workers=self.num_workers,
            )
            self.opt_cls(cls_dataloader)

        for index in range(domain_id.size(0)):
            self.test_set.append(
                (x[index].cpu(), y[index].cpu(), domain_id[index].cpu())
            )
        self.test_indecies = list(range(len(self.test_set)))


class DNN_CCSA(DNN_OGD_abc):

    def __init__(self, cfgs: exp_config.Config, stepsize=0.0, **algo_kwargs):
        super(DNN_CCSA, self).__init__(cfgs=cfgs, stepsize=stepsize, **algo_kwargs)

        self.train_set = self.alg_kwargs["dataset"]
        self.train_indecies = list(range(len(self.train_set)))
        self.test_set = []
        self.test_indecies = []

        self.update_rounds = self.cfgs.online_cfgs.kwargs["update_rounds"]
        self.rep_lr = self.cfgs.online_cfgs.kwargs["rep_lr"]
        self.cls_lr = self.cfgs.online_cfgs.kwargs["cls_lr"]
        self.rep_batch_size = self.cfgs.online_cfgs.kwargs["rep_batch_size"]
        self.cls_batch_size = self.cfgs.online_cfgs.kwargs["cls_batch_size"]
        self.num_workers = self.cfgs.hardware_cfgs.kwargs.get("num_workers", 8)

    def stratified_sample(self, sample_size):
        lucky = []
        random.shuffle(self.test_indecies)
        random.shuffle(self.train_indecies)
        n_test = round(
            sample_size
            * len(self.test_indecies)
            / (len(self.train_indecies) + len(self.test_indecies))
        )
        n_train = sample_size - n_test
        for i_test in self.test_indecies[:n_test]:
            lucky.append(self.test_set[i_test])
        for i_train in self.train_indecies[:n_train]:
            lucky.append(self.train_set[i_train])
        return lucky

    def opt_rep(self, dataloader):
        self.online_rep_model = self.online_rep_model.to(self.device)
        self.online_cls_model = self.online_cls_model.to(self.device)
        self.online_rep_model.train()
        self.online_cls_model.eval()
        loss_func = torch.nn.CrossEntropyLoss()
        optimizer = optim.SGD(self.online_rep_model.parameters(), lr=self.rep_lr)

        ccsa_alpha = self.cfgs.online_cfgs.kwargs.get("ccsa_alpha", 0.0001)
        ccsa_batch_size = self.cfgs.online_cfgs.kwargs.get(
            "ccsa_batch_size", self.rep_batch_size
        )

        for x_tgt, y_tgt, domain_id_tgt in dataloader:
            optimizer.zero_grad()
            x_tgt = x_tgt.to(self.device)
            y_tgt = y_tgt.to(self.device)
            z_tgt = self.online_rep_model(x_tgt)
            y_pred_tgt = self.online_cls_model(z_tgt)

            x_src = torch.stack([record[0] for record in self.lucky])
            y_src = torch.stack([record[1] for record in self.lucky])
            # domain_id_src = torch.stack([record[2] for record in self.lucky])
            x_src = x_src.to(self.device)
            y_src = y_src.to(self.device)
            z_src = self.online_rep_model(x_src)
            # y_pred_src = self.online_cls_model(z_src)

            # Constrastive Semantic Alignment Loss https://github.com/YooJiHyeong/CCSA_PyTorch/blob/master/main.py
            margin = 1
            distance = torch.nn.functional.pairwise_distance(z_src, z_tgt)
            identity = (y_src == y_tgt).float()
            csa_loss = (
                identity * distance**2
                + (1 - identity) * (margin - distance).clamp(min=0) ** 2
            )
            csa_loss = torch.mean(csa_loss)

            cls_loss = loss_func(y_pred_tgt, y_tgt)

            loss = (1 - ccsa_alpha) * cls_loss + ccsa_alpha * csa_loss
            loss.backward()

            if self.grad_clip:
                torch.nn.utils.clip_grad_norm_(
                    self.online_rep_model.parameters(), 1.0, norm_type=1.0
                )
            optimizer.step()

    def opt_cls(self, dataloader):
        self.online_rep_model = self.online_rep_model.to(self.device)
        self.online_cls_model = self.online_cls_model.to(self.device)
        self.online_rep_model.eval()
        self.online_cls_model.train()
        loss_func = torch.nn.CrossEntropyLoss()
        optimizer = optim.SGD(self.online_cls_model.parameters(), lr=self.cls_lr)

        for x, y, domain_id in dataloader:
            optimizer.zero_grad()
            x = x.to(self.device)
            y = y.to(self.device)
            z = self.online_rep_model(x)
            y_pred = self.online_cls_model(z)
            loss = loss_func(y_pred, y)
            loss.backward()

            if self.grad_clip:
                torch.nn.utils.clip_grad_norm_(
                    self.online_cls_model.parameters(), 1.0, norm_type=1.0
                )
            optimizer.step()

    def alg_forward(self, x, y, domain_id):
        ccsa_batch_size = self.cfgs.online_cfgs.kwargs.get(
            "ccsa_batch_size", self.rep_batch_size
        )
        self.lucky = self.stratified_sample(ccsa_batch_size)

        dataset = torch_data.TensorDataset(x, y, domain_id)
        for round in range(self.update_rounds):
            rep_dataloader = torch_data.DataLoader(
                dataset,
                batch_size=self.rep_batch_size,
                shuffle=True,
                # num_workers=self.num_workers,
            )
            self.opt_rep(rep_dataloader)
            cls_dataloader = torch_data.DataLoader(
                dataset,
                batch_size=self.cls_batch_size,
                shuffle=True,
                # num_workers=self.num_workers,
            )
            self.opt_cls(cls_dataloader)

        for index in range(domain_id.size(0)):
            self.test_set.append(
                (x[index].cpu(), y[index].cpu(), domain_id[index].cpu())
            )
        self.test_indecies = list(range(len(self.test_set)))


def get_online_alg(
    cfgs: exp_config.Config,
    online_cfgs,
    min_step,
    max_step,
    models_dict,
    train_set,
    device,
    rng,
    info,
):
    alg_kwargs = {
        "offline_rep_model": models_dict["offline_rep_model"],
        "offline_cls_model": models_dict["offline_cls_model"],
        "online_rep_model": models_dict["online_rep_model"],
        "online_cls_model": models_dict["online_cls_model"],
        "cls_init": models_dict["cls_init"],
        "rep_init": models_dict["rep_init"],
        "dataset": train_set,
        "device": device,
        "batch_size": cfgs.offline_cfgs.source_batch_size,
        "unsupervised_update": False,
    }

    if online_cfgs.algorithm == "DNN_FIX":
        online_alg = DNN_FIX(cfgs=cfgs, **alg_kwargs)

    elif online_cfgs.algorithm == "DNN_Skyline":
        online_alg = DNN_Skyline(cfgs=cfgs, **alg_kwargs)

    elif online_cfgs.algorithm == "DNN_LAME":
        online_alg = DNN_LAME(cfgs=cfgs, **alg_kwargs)

    elif online_cfgs.algorithm == "DNN_OGD":
        online_alg = DNN_OGD(cfgs=cfgs, **alg_kwargs)

    elif online_cfgs.algorithm == "DNN_OGD1":
        online_alg = DNN_OGD1(cfgs=cfgs, **alg_kwargs)

    elif online_cfgs.algorithm == "DNN_AGEM":
        online_alg = DNN_AGEM(cfgs=cfgs, **alg_kwargs)

    elif online_cfgs.algorithm == "DNN_DANN":
        online_alg = DNN_DANN(cfgs=cfgs, **alg_kwargs)

    elif online_cfgs.algorithm == "DNN_IWDAN":
        online_alg = DNN_IWDAN(cfgs=cfgs, **alg_kwargs)

    elif online_cfgs.algorithm == "DNN_HAL":
        online_alg = DNN_HAL(cfgs=cfgs, **alg_kwargs)

    elif online_cfgs.algorithm == "DNN_CCSA":
        online_alg = DNN_CCSA(cfgs=cfgs, **alg_kwargs)

    elif online_cfgs.algorithm == "DNN_MaskOGD":
        online_alg = DNN_MaskOGD(cfgs=cfgs, **alg_kwargs)

    else:
        raise NotImplementedError(
            f"unknown online_cfgs.algorithm={repr(online_cfgs.algorithm)}"
        )

    return online_alg
