import abc
import copy

import math
from torch import autograd, nn
from tqdm import trange, tqdm

from online.algorithms.General.DNN_ogd import DNN_OGD as DNN_OGD_abc

import numpy as np

import torch
import torch.optim as optim
import torch.utils
import torch.utils.data as torch_data
import random

from utils_pkg import exp_config
import torch.nn.functional as F


class DNN_MaskOGD(DNN_OGD_abc):
    @abc.abstractmethod
    def __init__(self, cfgs: exp_config.Config, stepsize=0.0, **algo_kwargs):
        super(DNN_MaskOGD, self).__init__(cfgs=cfgs, stepsize=stepsize, **algo_kwargs)

        self.update_rounds = self.cfgs.online_cfgs.kwargs["update_rounds"]
        self.rep_lr = self.cfgs.online_cfgs.kwargs["rep_lr"]
        self.cls_lr = self.cfgs.online_cfgs.kwargs["cls_lr"]
        self.rep_batch_size = self.cfgs.online_cfgs.kwargs["rep_batch_size"]
        self.cls_batch_size = self.cfgs.online_cfgs.kwargs["cls_batch_size"]
        self.num_workers = self.cfgs.hardware_cfgs.kwargs.get("num_workers", 8)

        # configs for MaskOGD
        self.buffer = []  # historical data buffer
        self.num_base_learner = self.cfgs.online_cfgs.kwargs["num_base_learner"]
        self.max_mask_rate = self.cfgs.online_cfgs.kwargs["max_mask_rate"]

        # self.mask_rate_list = np.logspace(math.log2(0.0001), math.log2(self.max_mask_rate), self.num_base_learner, base=2)

        # self.mask_rate_list = np.geomspace(0.0001, self.max_mask_rate, self.num_base_learner)

        # rate = 1.0
        # self.m = []
        # # self.mask_rate_list = []
        # for i in range(self.num_base_learner - 1):
        #     self.mask_rate_list.append(self.max_mask_rate / rate)
        #     self.m.append(nn.Dropout(p=self.max_mask_rate / rate, inplace=True))
        #     rate *= 2.0
        # self.mask_rate_list.append(0.0)
        # self.m.append(nn.Dropout(p=0.0, inplace=True))
        # self.mask_rate_list = np.array(self.mask_rate_list[::-1])
        # self.m = self.m[::-1]

        self.mask_rate_list = self.cfgs.online_cfgs.kwargs["mask_rate_list"]
        # self.mask_rate_list = np.array(self.mask_rate_list[::-1])
        self.m = []
        for i in range(self.num_base_learner):
            self.m.append(nn.Dropout(p=self.mask_rate_list[i], inplace=True))

        # self.mask_rate_list = [0.0]
        print(f"\033[33m[MaskOGD] mask_rate_list: {self.mask_rate_list}\033[0m")
        self.historical_data_buffer_size = self.num_base_learner
        self.mask = None
        self.is_lr_vary = self.cfgs.online_cfgs.kwargs["is_lr_vary"]
        self.is_mask_normalization = self.cfgs.online_cfgs.kwargs[
            "is_mask_normalization"
        ]
        self.is_perturb = self.cfgs.online_cfgs.kwargs["is_perturb"]
        self.penalty_lambda = self.cfgs.online_cfgs.kwargs["penalty_lambda"]
        self.round_proportion_min = self.cfgs.online_cfgs.kwargs["round_proportion_min"]
        self.round_proportion_max = self.cfgs.online_cfgs.kwargs["round_proportion_max"]
        self.t = 0
        self.T = self.cfgs.T
        self.ori_rep_lr = self.rep_lr
        self.ori_cls_model = copy.deepcopy(self.online_cls_model)
        self.last_loss = 0.0
        self.y_num_list = [0] * self.cfgs.data_cfgs.data_info["cls_num"]
        self.cls_num = self.cfgs.data_cfgs.data_info["cls_num"]
        self.weights = torch.ones(self.cls_num)

    def mean_nll(self, logits, y):
        return nn.functional.binary_cross_entropy_with_logits(logits, y)

    def find_last_layer(self, model):
        last_layer = None
        for name, module in model.named_modules():
            if list(module.children()):
                continue
            if any(p.requires_grad for p in module.parameters(recurse=False)):
                last_layer = module
        return last_layer

    def get_penalty(self, loss):
        grad = autograd.grad(
            loss,
            self.find_last_layer(self.online_rep_model).parameters(),
            create_graph=True,
        )[0]
        # return torch.sum(grad ** 2) / len(grad)
        # clip to 1.0
        grad = torch.clamp(grad, -1.0, 1.0)
        return torch.sum(grad**2) / len(grad)

    def change_dropout_rate(self, X, drop_prob):
        # if self.mask is None:
        assert 0 <= drop_prob <= 1
        keep_prob = 1 - drop_prob
        if keep_prob == 0:
            self.mask = torch.zeros_like(X)
            self.keep_prob = 0.0
        mask = (torch.rand_like(X) <= keep_prob).float()
        self.mask = mask
        self.keep_prob = keep_prob
        # return mask * X / keep_prob

    # def change_dropout_rate(self, dropout_rate):
    #     self.dropout_layer = torch.nn.Dropout(p=dropout_rate, inplace=True)
    def get_random_perturbation(self, mask_rate, i):
        return 1.0 + (0.05 * torch.rand(1).item() - 0.1) * ((1 - mask_rate) ** i)

    def opt_rep(self, dataloader, i, round_proportion=0.0):
        # lr descent
        # self.rep_lr = self.ori_rep_lr * (1 - self.t / self.update_rounds / self.T)

        # self.rep_lr = (self.ori_rep_lr - 0.001) * (1 - self.t / self.update_rounds / self.T) + 0.001

        self.online_rep_model = self.online_rep_model.to(self.device)
        self.online_cls_model = self.online_cls_model.to(self.device)
        self.online_rep_model.train()
        self.online_cls_model.eval()
        loss_func = torch.nn.CrossEntropyLoss()

        self.last_loss = 0.0
        # use historical data to update the rep_model
        # for i in range(self.num_base_learner - 1, -1, -1):
        loss_list = [0.0]

        mask_rate = self.mask_rate_list[i]
        self.mask = None

        mean_loss = np.mean(loss_list)
        meta_weight = min(math.exp(mean_loss - self.last_loss), 1.0) ** 2  # \in [0, 1]

        # if self.t % 256 == 0:
        #     print(f"[MaskOGD] t={self.t}, i={i}, mask_rate={mask_rate}, meta_weight={meta_weight}, "
        #           f"mean_loss={mean_loss},last_loss={self.last_loss}")

        # Opt the representation with mask and random perturb.
        if self.is_lr_vary:
            optimizer = optim.SGD(
                self.online_rep_model.parameters(),
                lr=self.rep_lr * meta_weight * (1 - mask_rate),
            )
        else:
            optimizer = optim.SGD(
                self.online_rep_model.parameters(), lr=self.rep_lr * meta_weight
            )
        # tot_len = len(self.buffer[-(i + 1)])
        # tot_len is always 1

        for x, y, domain_id in dataloader:
            optimizer.zero_grad()
            x = x.to(self.device)
            y = y.to(self.device)
            z = self.online_rep_model(x)

            # z = self.dropout_layer(z)

            self.change_dropout_rate(z, mask_rate)
            if self.is_mask_normalization:
                z = self.mask * z / self.keep_prob
            else:
                z = self.mask * z

            # z = self.m[i](z)

            # if self.t % 256 <= self.num_base_learner:
            #     print(f"[MaskOGD] t={self.t}, i={i}, mask_rate={mask_rate}, mask={self.mask}, keep_prob={self.keep_prob},"
            #           f"meta_weight={meta_weight}, mean_loss={mean_loss}, last_loss={self.last_loss}")

            y_pred = self.online_cls_model(z)
            loss = loss_func(y_pred, y)

            penalty = 0.0
            if (
                round_proportion >= self.round_proportion_min
                and round_proportion <= self.round_proportion_max
            ):
                # add the penalty
                penalty = self.get_penalty(loss)
                loss += self.penalty_lambda * penalty

                # add the random perturbation
                if self.is_perturb:
                    loss *= self.get_random_perturbation(mask_rate, i)

            loss_list.append(loss.item())

            loss.backward()

            if self.grad_clip:
                torch.nn.utils.clip_grad_norm_(
                    self.online_rep_model.parameters(), 1.0, norm_type=1.0
                )
            optimizer.step()

            if self.t % (self.update_rounds // 2) == 0:
                # print(f"\033[33m \n\t****[MaskOGD] t={(self.t - 1) // self.update_rounds}, "
                #       f"base learner i={i}, mask_rate={mask_rate}, lr={self.rep_lr * meta_weight * (1 - mask_rate)}, "
                #       f"drop_out={self.m[i].p}, "
                #       f"meta_weight={meta_weight}, loss={loss.item()}, penalty={penalty} \033[0m")
                print(
                    f"[MaskOGD] t={(self.t - 1) // self.update_rounds}, "
                    f"base learner i={i}, mask_rate={mask_rate}, lr={self.rep_lr * meta_weight * (1 - mask_rate)}, "
                    f"drop_out={self.m[i].p}, "
                    f"meta_weight={meta_weight}, loss={loss.item()}, penalty={penalty}"
                )

        self.last_loss += np.mean(loss_list)

        self.last_loss /= self.num_base_learner

    def opt_cls(self, dataloader):
        self.online_rep_model = self.online_rep_model.to(self.device)
        self.online_cls_model = self.online_cls_model.to(self.device)
        self.online_rep_model.eval()
        self.online_cls_model.train()
        loss_func = None
        optimizer = optim.SGD(self.online_cls_model.parameters(), lr=self.cls_lr)

        for x, y, domain_id in dataloader:
            optimizer.zero_grad()
            x = x.to(self.device)
            y = y.to(self.device)
            z = self.online_rep_model(x)
            y_pred = self.online_cls_model(z)
            if loss_func is None:
                loss_func = torch.nn.CrossEntropyLoss(weight=self.weights.to(x.device))
            loss = loss_func(y_pred, y)
            loss.backward()

            if self.grad_clip:
                torch.nn.utils.clip_grad_norm_(
                    self.online_cls_model.parameters(), 1.0, norm_type=1.0
                )
            optimizer.step()

        # if self.t % 256 == 0:
        #     print(f"[MaskOGD] t={self.t}, weights={self.weights}")

    def alg_forward(self, x, y, domain_id):
        dataset = torch_data.TensorDataset(x, y, domain_id)

        # reweight the loss based on label distribution

        # self.y_num_list = torch.zeros(self.cls_num)
        # for class_i in range(self.cls_num):
        #     class_i_idx = (y == class_i)
        #     self.y_num_list[class_i] += class_i_idx.detach().cpu().sum()
        # self.weights = self.y_num_list / self.y_num_list.sum() * self.cls_num
        # self.weights = torch.softmax(self.weights / self.cls_num, dim=0) * self.cls_num
        # print('num_list1:', self.y_num_list))
        # print('weights1:', self.weights)

        y_num_list = torch.bincount(y, minlength=self.cls_num).float()
        weights = -y_num_list / y_num_list.sum()
        self.weights = torch.softmax(weights, dim=0)
        self.weights = self.weights / self.weights.sum() * self.cls_num
        # print('num_list2:', y_num_list)
        # print('weights2:', self.weights)

        # update the buffer:
        self.buffer.append(dataset)
        if len(self.buffer) > self.historical_data_buffer_size:
            self.buffer.pop(0)

        # for round in trange(self.update_rounds, desc=f"Optimizing the models at t={self.t // self.update_rounds}"):
        for round in range(self.update_rounds):
            self.t += 1
            for i in range(self.num_base_learner - 1, -1, -1):
                if len(self.buffer) <= i:
                    continue
                rep_dataloader = torch_data.DataLoader(
                    self.buffer[-(i + 1)],
                    batch_size=self.rep_batch_size,
                    shuffle=True,
                    # num_workers=self.num_workers,
                )
                self.opt_rep(
                    rep_dataloader, i, round_proportion=round / self.update_rounds
                )
            cls_dataloader = torch_data.DataLoader(
                dataset,
                batch_size=self.cls_batch_size,
                shuffle=True,
                # num_workers=self.num_workers,
            )
            self.opt_cls(cls_dataloader)
