# /usr/bin/env python
# -*- coding: utf-8 -*-

import torch
from torch.utils.data import DataLoader
from tqdm import tqdm

from online.algorithms.General.DNN_base import DNN_base
from utils_pkg import exp_config

__all__ = ["DNN_FIX"]

import abc

from utils_pkg.utils import collate_first2_args


class DNN_FIX(DNN_base, metaclass=abc.ABCMeta):

    @abc.abstractmethod
    def __init__(self, cfgs: exp_config.Config, stepsize=0.0, **algo_kwargs):
        super(DNN_FIX, self).__init__(cfgs=cfgs, **algo_kwargs)
        self.lr = stepsize

        self.optimizer = None
        # print('DNN_FIX Stepsize: {}'.format(self.lr))

        self.estimate_result = {
            "D": [],
            "G": [],
        }

        self.grad_clip = self.cfgs.online_cfgs.grad_clip
        self.projection = self.cfgs.online_cfgs.kwargs.get("projection", False)

        if self.alg_kwargs.get("unsupervised_update", True):
            self.source_rep, self.source_label = self.get_rep_of_data(
                self.alg_kwargs["dataset"]
            )

    @torch.no_grad()
    def get_rep_of_data(self, dataset):
        dataloader = DataLoader(
            dataset,
            num_workers=0,
            batch_size=self.cfgs.online_cfgs.kwargs.get("rep_batch_size", 256),
            shuffle=False,
            pin_memory=False,
            collate_fn=collate_first2_args,
        )
        tot_rep = None
        tot_label = None
        for batch_idx, (data, label) in enumerate(
            tqdm(dataloader, desc="Updating rep_data")
        ):
            if self.online_rep_model is not None:
                data = data.to(self.device)
                rep = self.online_rep_model(data).cpu()
            else:
                rep = data.cpu()
            label = label.cpu()
            if tot_rep is None:
                tot_rep = rep
                tot_label = label
            else:
                tot_rep = torch.cat((tot_rep, rep), dim=0)
                tot_label = torch.cat((tot_label, label), dim=0)
        return tot_rep, tot_label

    def opt_rep(self):
        # no opt for FIX model
        pass

    def opt_cls(self, target_data):
        # no opt for FIX model
        pass

    @torch.no_grad()
    def predict(self, data):
        return super(DNN_FIX, self).predict(data)

    @torch.no_grad()
    def eval(self):

        estimate_loss, underlying_loss = 0, 0

        # for batch_idx, (data, target) in enumerate(self.cache):
        #     data, target = data.to(self.device), target.to(self.device)
        #     if self.online_rep_model is not None:
        #         data = self.online_rep_model(data).detach()

        self.online_cls_model.eval()
        self.online_cls_model = self.online_cls_model.cpu()
        output = self.online_cls_model(self.source_rep)

        info = self.criterion(output.float(), self.source_label)

        estimate_loss += info["estimate"].item()
        if info["underlying"] is None:
            underlying_loss = None
        else:
            underlying_loss += info["underlying"].item()

        estimate_loss /= len(self.dataloader)
        if underlying_loss is not None:
            underlying_loss /= len(self.dataloader)

        return estimate_loss, underlying_loss

    def alg_forward(self, target_data, prior_estimate, t):

        pred = self.predict(target_data)
        estimate_loss, underlying_loss = self.eval()

        return pred, estimate_loss, underlying_loss
