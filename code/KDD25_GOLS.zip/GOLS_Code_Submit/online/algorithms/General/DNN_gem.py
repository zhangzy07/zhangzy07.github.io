import abc, os, sys, random
from tqdm import tqdm, trange

import numpy as np
import torch

from utils_pkg import exp_config
from utils_pkg.tools import tensor2scalar
from utils_pkg.convex_opt.qp import solve_gem_qp
from online.algorithms.General.DNN_base import DNN_base


class DNN_GEM(DNN_base, metaclass=abc.ABCMeta):
    @abc.abstractmethod
    def __init__(self, cfgs: exp_config.Config, stepsize=0.0, **algo_kwargs):
        super(DNN_GEM, self).__init__(cfgs=cfgs, **algo_kwargs)

        self.offline_cls_model.eval()
        self.offline_cls_model = self.online_cls_model.cpu()
        if self.offline_rep_model:
            self.offline_rep_model.eval()
            self.offline_rep_model = self.online_rep_model.cpu()
        self.online_cls_model.eval()
        self.online_cls_model = self.online_cls_model.cpu()
        if self.online_rep_model:
            self.online_rep_model.eval()
            self.online_rep_model = self.online_rep_model.cpu()

        self.grad_clip = self.cfgs.online_cfgs.grad_clip

        # set classification criterion
        self._wilds_fmow_criterion = torch.nn.CrossEntropyLoss()

        # get learning rate
        self._gem_cls_lr = stepsize
        self._gem_rep_lr = float(
            self.cfgs.online_cfgs.kwargs.get("rep_lr", self._gem_cls_lr)
        )
        self._gem_online_bs = self.cfgs.online_cfgs.kwargs["rep_batch_size"]

        self.online_cls_model = self.online_cls_model.cpu()
        if self.online_rep_model:
            self.online_rep_model = self.online_rep_model.cpu()

        if self.alg_kwargs.get("unsupervised_update", True):

            self._gem_pool = [
                (record[0].cpu(), record[1].cpu())
                for record in tqdm(self.alg_kwargs["dataset"], ncols=80)
            ]

            if not cfgs.online_cfgs.kwargs.get("is_base_expert", False):
                self.source_rep, self.source_label = self.get_rep_of_data()

    def _gem_gen_rep_parameters(self):
        if self.cfgs.online_cfgs.kwargs.get("only_opt_rep", False):
            _agem_para = list(self.online_rep_model.parameters())
        else:
            _agem_para = list(self.online_rep_model.parameters()) + list(
                self.online_cls_model.parameters()
            )
        return _agem_para

    @torch.no_grad()
    def get_rep_of_data(self):
        self.online_rep_model = self.online_rep_model.to(self.device)
        self.online_rep_model.eval()
        _embeds = []
        _labels = []
        for _batch_index in trange(
            len(self._gem_pool) // self._gem_online_bs,
            desc="\033[93m[DNN_GEM]\033[0m get_rep_of_data",
        ):
            _batch = self._gem_pool[
                _batch_index
                * self._gem_online_bs : (_batch_index + 1)
                * self._gem_online_bs
            ]
            _batch_image = torch.stack([dat[0] for dat in _batch], dim=0)
            _batch_label = torch.tensor([dat[1] for dat in _batch], dtype=torch.long)
            _batch_image = _batch_image.to(self.device)
            _batch_embed = self.online_rep_model(_batch_image)
            _embeds.append(_batch_embed.cpu())
            _labels.append(_batch_label)
        self.online_rep_model = self.online_rep_model.cpu()
        return torch.cat(_embeds, dim=0), torch.cat(_labels, dim=0)

    def opt_cls_one_batch(self):
        self.online_cls_model = self.online_cls_model.cpu()
        self.online_cls_model.train()
        optimizer = torch.optim.SGD(
            self.online_cls_model.parameters(), lr=self._gem_cls_lr
        )
        optimizer.zero_grad()
        output = self.online_cls_model(self.source_rep)
        info = self.criterion(output.float(), self.source_label)
        loss = info["estimate"]
        loss.backward()
        if self.cfgs.online_cfgs.grad_clip:
            torch.nn.utils.clip_grad_norm_(
                self.online_cls_model.parameters(), 1.0, norm_type=1.0
            )
        optimizer.step()
        return tensor2scalar(info["estimate"]), tensor2scalar(info["underlying"])

    def opt_cls(self, target_images):
        estimate_loss, underlying_loss = self.opt_cls_one_batch()
        if isinstance(estimate_loss, float):
            estimate_loss /= len(self.dataloader)
        if isinstance(underlying_loss, float):
            underlying_loss /= len(self.dataloader)
        if self.cfgs.online_cfgs.kwargs.get("projection", False):
            self.online_cls_model.project()
        pseudo_labels = self.predict(target_images)
        return estimate_loss, underlying_loss, pseudo_labels

    def opt_rep(self, target_images, pseudo_labels):
        self.online_cls_model.train()
        self.online_rep_model.train()
        self.online_cls_model = self.online_cls_model.to(self.device)
        self.online_rep_model = self.online_rep_model.to(self.device)

        if self.cfgs.online_cfgs.kwargs.get("only_opt_rep", False):
            tqdm_text = "only opt rep model"
            self.online_cls_model.eval()
        else:
            tqdm_text = "opt rep and cls models"
            self.online_cls_model.train()

        # build gradient pool
        self.online_cls_model.train()
        self.online_rep_model.train()
        self.online_cls_model = self.online_cls_model.to(self.device)
        self.online_rep_model = self.online_rep_model.to(self.device)
        _gem_grad_pool = []
        _gem_grad_shape = []
        _offline_grad_pool = []
        # do not use all old grad (old batch), to avoid O(n^2) time complexity
        _batch_indecies = list(range(len(self._gem_pool) // self._gem_online_bs))
        random.shuffle(_batch_indecies)

        # for _batch_index in tqdm(
        #     _batch_indecies[0 : self.cfgs.online_cfgs.kwargs.get("gem_sample_size", 1024)],
        #     # desc="\033[93m[DNN_GEM]\033[0m build gradient pool",
        #     desc="[DNN_GEM] build gradient pool",
        #     leave=False
        # ):
        for _batch_index in _batch_indecies[
            0 : self.cfgs.online_cfgs.kwargs.get("gem_sample_size", 1024)
        ]:
            _batch = self._gem_pool[
                _batch_index
                * self._gem_online_bs : (_batch_index + 1)
                * self._gem_online_bs
            ]
            _batch_image = torch.stack([dat[0] for dat in _batch], dim=0)
            _batch_label = torch.tensor([dat[1] for dat in _batch], dtype=torch.long)
            _batch_image = _batch_image.to(self.device)
            _batch_embed = self.online_rep_model(_batch_image)
            _batch_logits = self.online_cls_model(_batch_embed)
            _batch_logits = _batch_logits.cpu()
            _batch_loss = self._wilds_fmow_criterion(_batch_logits, _batch_label)
            _batch_grad = torch.autograd.grad(
                _batch_loss, self._gem_gen_rep_parameters()
            )
            _offline_grad_pool.append(tuple(_grad.cpu() for _grad in _batch_grad))

            _accum_grad_numel = 0
            for _grad in _offline_grad_pool[0]:
                _gem_grad_shape.append(
                    (
                        (_accum_grad_numel, _accum_grad_numel + _grad.numel()),
                        _grad.shape,
                    )
                )
                _accum_grad_numel += _grad.numel()
            if self.cfgs.online_cfgs.kwargs.get("optimize_by_source", False):
                _numpy_grad = np.concatenate(
                    [_grad.cpu().flatten().numpy() for _grad in _batch_grad], axis=0
                )
                _batch_grad = tuple(
                    torch.FloatTensor(_numpy_grad[_left:_right])
                    .reshape(_shape)
                    .to(self.device)
                    for (_left, _right), _shape in _gem_grad_shape
                )
                for _para, _grad in zip(self._gem_gen_rep_parameters(), _batch_grad):
                    _para.data -= _grad * self._gem_rep_lr

        _accum_grad_numel = 0
        for _grad in _offline_grad_pool[0]:
            _gem_grad_shape.append(
                ((_accum_grad_numel, _accum_grad_numel + _grad.numel()), _grad.shape)
            )
            _accum_grad_numel += _grad.numel()
        for _offline_grad in _offline_grad_pool:
            _numpy_grad = np.concatenate(
                [_grad.flatten().numpy() for _grad in _offline_grad], axis=0
            )
            _gem_grad_pool.append(_numpy_grad)

        print(
            "\033[93m[DNN_GEM]\033[0m",
            f"grad_pool_size={len(_gem_grad_pool)},",
            f"grad_entr_num={_gem_grad_pool[0].shape[0]}",
            file=sys.stderr,
        )

        # assume target_images is torch.Tensor of shape (batch, channel, height, width)
        # assume pseudo_labels is torch.Tensor of shape (batch)

        loss = 0.0
        for epoch in range(self.cfgs.online_cfgs.kwargs.get("rep_optimize_epoch", 1)):
            for _batch_index in trange(
                target_images.size(0)
                // min(self._gem_online_bs, target_images.size(0)),
                desc=f"\033[93m[DNN_GEM]\033[0m epoch#{epoch} (optimize {tqdm_text}, loss={loss})",
                leave=False,
            ):
                _batch_image = target_images[
                    _batch_index
                    * self._gem_online_bs : (_batch_index + 1)
                    * self._gem_online_bs
                ]
                _batch_label = pseudo_labels[
                    _batch_index
                    * self._gem_online_bs : (_batch_index + 1)
                    * self._gem_online_bs
                ]
                _batch_image = _batch_image.to(self.device)
                _batch_label = _batch_label.to(self.device)
                _batch_embed = self.online_rep_model(_batch_image)
                _batch_logits = self.online_cls_model(_batch_embed)
                _batch_loss = self._wilds_fmow_criterion(_batch_logits, _batch_label)
                _batch_grad = torch.autograd.grad(
                    _batch_loss, self._gem_gen_rep_parameters()
                )
                _numpy_grad = np.concatenate(
                    [_grad.cpu().flatten().numpy() for _grad in _batch_grad], axis=0
                )
                _numpy_grad = solve_gem_qp(_numpy_grad, _gem_grad_pool)
                _batch_grad = tuple(
                    torch.FloatTensor(_numpy_grad[_left:_right])
                    .reshape(_shape)
                    .to(self.device)
                    for (_left, _right), _shape in _gem_grad_shape
                )
                for _para, _grad in zip(self._gem_gen_rep_parameters(), _batch_grad):
                    _para.data -= _grad * self._gem_rep_lr

                if epoch == 0:
                    for i in range(min(self._gem_online_bs, target_images.size(0))):
                        _image = _batch_image[i].cpu()
                        _label = _batch_label[i].cpu().item()
                        self._gem_pool.append((_image, _label))

        self.online_cls_model = self.online_cls_model.cpu()
        self.online_rep_model = self.online_rep_model.cpu()

        self.source_rep, self.source_label = self.get_rep_of_data()

    @torch.no_grad()
    def predict(self, data):
        return super(DNN_GEM, self).predict(data)

    def alg_forward(self, target_images, prior_estimate, t):
        pred = self.predict(target_images)

        estimate_loss, underlying_loss, pseudo_labels = self.opt_cls(target_images)

        if (
            self.cfgs.online_cfgs.update_DNN_represent
            and t % self.cfgs.online_cfgs.kwargs["rep_update_interval"] == 0
        ):
            print("\033[93m[DNN_GEM]\033[0m", f"opt_rep at t={t}")
            self.opt_rep(target_images, pseudo_labels)
            if self.cfgs.online_cfgs.kwargs.get("rep_update_only_once", False):
                self.cfgs.online_cfgs.update_DNN_represent = False

        return pred, estimate_loss, underlying_loss
