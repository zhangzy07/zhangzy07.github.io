# /usr/bin/env python
# -*- coding: utf-8 -*-
import copy

from tqdm import trange

from online.algorithms.General.ogd import Base
import torch
import torch.nn as nn
import abc
import torch.nn.functional as F

from utils_pkg import exp_config


class FTH(Base, metaclass=abc.ABCMeta):

    @abc.abstractmethod
    def __init__(self, cfgs=None, seed=None, simplex_model=None, **alg_kwargs):
        super(FTH, self).__init__(cfgs, seed, **alg_kwargs)
        self.offline_cls_model = copy.deepcopy(self.model)
        # Models:
        self.online_cls_model = self.alg_kwargs[
            "online_cls_model"
        ].cpu()  # store the initial online cls model
        self.online_rep_model = self.alg_kwargs[
            "online_rep_model"
        ]  # store the initial online rep model
        if self.online_rep_model is not None:
            self.online_rep_model = self.online_rep_model.to(self.device)

        self.init_expert = copy.deepcopy((self.online_cls_model))

        self.offline_cls_model = self.alg_kwargs[
            "offline_cls_model"
        ].cpu()  # store the initial cls model
        self.offline_rep_model = self.alg_kwargs[
            "offline_rep_model"
        ]  # store the initial rep model
        if self.offline_rep_model is not None:
            self.offline_rep_model = self.offline_rep_model.to(self.device)

        self.cls_init = None
        if self.alg_kwargs["cls_init"] is not None:
            self.online_cls_model.load_state_dict(self.alg_kwargs["cls_init"])
            self.cls_init = self.alg_kwargs["cls_init"]

        self.rep_init = None
        if self.alg_kwargs["rep_init"] is not None:
            self.online_rep_model.load_state_dict(self.alg_kwargs["rep_init"])
            self.rep_init = self.alg_kwargs["rep_init"]

        self.model = simplex_model
        self.model = self.model.cpu()
        self.weight_scale = cfgs.online_cfgs.kwargs.get("weight_scale", 1.0)
        # for i in trange(len(self.cache), desc='Covert to soft preds'):
        #     self.cache[i][0] = torch.softmax(self.offline_cls_model(self.cache[i][0]).detach(), dim=-1)

    @torch.no_grad()
    def alg_forward(self, target_data, prior_estimate, t):
        if self.online_rep_model is not None:
            target_data = self.online_rep_model(target_data)
        target_data = target_data.detach().cpu()

        estimate_loss, underlying_loss = 0, 0
        target_data = self.offline_cls_model(target_data).detach().cpu()

        pred = self.model(target_data).detach()
        pred = pred.argmax(dim=-1)

        if self.cfgs.online_cfgs.kwargs["projection"]:
            self.model.project()

        prior_estimate = prior_estimate.cpu()
        weights = self.model.get_weights()
        new_weights = (t * weights["priors"].data + prior_estimate) / (t + 1)

        weights["priors"] = nn.Parameter(new_weights)
        weights["priors"] = torch.softmax(weights["priors"] * self.weight_scale, dim=-1)
        self.model.load_state_dict(weights)

        return pred, estimate_loss, underlying_loss


class FTFWH(Base):
    @abc.abstractmethod
    def __init__(
        self, cfgs: exp_config = None, seed=None, simplex_model=None, **alg_kwargs
    ):
        super(FTFWH, self).__init__(cfgs, seed, **alg_kwargs)
        self.cfgs = cfgs
        self.win_len = alg_kwargs.get("win_len", 100)
        self.queue = []
        self.offline_cls_model = copy.deepcopy(self.model)

        # Models:
        self.online_cls_model = self.alg_kwargs[
            "online_cls_model"
        ].cpu()  # store the initial online cls model
        self.online_rep_model = self.alg_kwargs[
            "online_rep_model"
        ]  # store the initial online rep model
        if self.online_rep_model is not None:
            self.online_rep_model = self.online_rep_model.to(self.device)

        self.init_expert = copy.deepcopy((self.online_cls_model))

        self.offline_cls_model = self.alg_kwargs[
            "offline_cls_model"
        ].cpu()  # store the initial cls model
        self.offline_rep_model = self.alg_kwargs[
            "offline_rep_model"
        ]  # store the initial rep model
        if self.offline_rep_model is not None:
            self.offline_rep_model = self.offline_rep_model.to(self.device)

        self.cls_init = None
        if self.alg_kwargs["cls_init"] is not None:
            self.online_cls_model.load_state_dict(self.alg_kwargs["cls_init"])
            self.cls_init = self.alg_kwargs["cls_init"]

        self.rep_init = None
        if self.alg_kwargs["rep_init"] is not None:
            self.online_rep_model.load_state_dict(self.alg_kwargs["rep_init"])
            self.rep_init = self.alg_kwargs["rep_init"]

        self.model = simplex_model
        self.model = self.model.cpu()
        # for i in trange(len(self.cache), desc='Covert to soft preds'):
        #     self.cache[i][0] = torch.softmax(self.offline_cls_model(self.cache[i][0]).detach(), dim=-1)
        print("Window length: {}".format(self.win_len))

        self.weight_scale = cfgs.online_cfgs.kwargs.get("weight_scale", 1.0)

    @torch.no_grad()
    def alg_forward(self, target_data, prior_estimate, t):
        if self.online_rep_model is not None:
            target_data = self.online_rep_model(target_data)
        target_data = target_data.detach().cpu()

        estimate_loss, underlying_loss = 0, 0
        target_data = self.offline_cls_model(target_data).detach().cpu()

        # pred = target_data.argmax(dim=-1)

        pred = self.model(target_data).detach()
        pred = pred.argmax(dim=-1)

        if self.cfgs.online_cfgs.kwargs["projection"]:
            self.model.project()

        self.queue.append(prior_estimate)
        if len(self.queue) > self.win_len:
            self.queue.pop(0)

        weights = self.model.get_weights()
        new_weights = torch.stack(self.queue, dim=0).mean(dim=0)

        weights["priors"] = nn.Parameter(new_weights)
        weights["priors"] = torch.softmax(weights["priors"] * self.weight_scale, dim=-1)
        self.model.load_state_dict(weights)

        return pred, estimate_loss, underlying_loss
