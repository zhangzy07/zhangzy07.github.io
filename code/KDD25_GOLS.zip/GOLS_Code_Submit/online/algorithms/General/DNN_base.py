# /usr/bin/env python
# -*- coding: utf-8 -*-
import abc
import copy

import math
import numpy as np
import torch
from torch.utils.data import DataLoader

from utils_pkg import exp_config
from abc import ABC, abstractmethod
import abc

__all__ = ["DNN_base"]


class DNN_base(object, metaclass=abc.ABCMeta):
    # DNN-based OGD updated online algorithm (model),
    # where representation and classifier are optimized separately

    def __init__(self, cfgs: exp_config.Config, **alg_kwargs):
        self.device = alg_kwargs["device"]
        self.alg_kwargs = alg_kwargs
        self.cfgs = cfgs
        self.seed = self.cfgs.seed

        # Models:
        self.online_cls_model: torch.nn.Module = self.alg_kwargs[
            "online_cls_model"
        ].cpu()
        self.online_rep_model: torch.nn.Module = self.alg_kwargs["online_rep_model"]
        if self.online_rep_model is not None:
            self.online_rep_model = self.online_rep_model.to(self.device)

        self.init_expert = copy.deepcopy((self.online_cls_model))

        self.offline_cls_model: torch.nn.Module = self.alg_kwargs[
            "offline_cls_model"
        ].cpu()
        self.offline_rep_model: torch.nn.Module = self.alg_kwargs["offline_rep_model"]
        if self.offline_rep_model is not None:
            self.offline_rep_model = self.offline_rep_model.to(self.device)

        self.cls_init = None
        if self.alg_kwargs["cls_init"] is not None:
            self.online_cls_model.load_state_dict(self.alg_kwargs["cls_init"])
            self.cls_init = self.alg_kwargs["cls_init"]

        self.rep_init = None
        if self.alg_kwargs["rep_init"] is not None:
            self.online_rep_model.load_state_dict(self.alg_kwargs["rep_init"])
            self.rep_init = self.alg_kwargs["rep_init"]

        self.criterion = None
        self.dataloader = DataLoader(
            self.alg_kwargs["dataset"],  # source (train) dataset's dataloader
            num_workers=0,
            batch_size=self.alg_kwargs["batch_size"],
            shuffle=True,
            pin_memory=True,
        )

        # self.cache = []
        # for batch_idx, (data, target) in enumerate(tqdm(self.dataloader, desc='Building cache data')):
        #     # data, target = data.to(self.device), target.to(self.device)
        #     self.cache.append((data, target))

    def set_criterion(self, func):
        self.criterion = func

    @abstractmethod
    def opt_rep(self, *args):
        """
        Optimize the representation layer (except the last layer classifier) with OGD.
        """
        raise NotImplementedError

    @abstractmethod
    def opt_cls(self, *args):
        """
        Only optimize the last layer classifier with OGD.
        """
        raise NotImplementedError

    @torch.no_grad()
    def predict(self, data, return_logits=False):
        self.online_cls_model.eval()
        self.online_cls_model = self.online_cls_model.cpu()
        if self.online_rep_model:
            self.online_rep_model.eval()
            self.online_rep_model = self.online_rep_model.to(self.device)

        data = data.to(self.device)
        _dtype_name = repr(data.dtype)
        if "float" in _dtype_name or "double" in _dtype_name:
            data = data.to(torch.float32)
        elif "long" in _dtype_name or "int" in _dtype_name:
            data = data.to(torch.long)

        if self.online_rep_model is not None:
            data = self.online_rep_model(data)
        data = data.detach().cpu()
        output = self.online_cls_model(data)

        if return_logits:
            return output
        else:
            return output.argmax(-1)

    def eval(self, *args):
        """
        Get some statistical information of the model.
        """
        pass

    def alg_forward(self, target_feature, prior_estimate, t):

        pred = self.predict(target_feature)
        # estimate_loss, underlying_loss = self.opt(target_feature)

        return pred
