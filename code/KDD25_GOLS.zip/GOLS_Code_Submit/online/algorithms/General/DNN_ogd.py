import torch
import torch.nn as nn
from torch.optim import *
from torch.utils.data import DataLoader
from tqdm import tqdm

from online.algorithms.General.DNN_base import DNN_base
from utils_pkg import exp_config
from utils_pkg.tools import Timer
from utils_pkg.tools import tensor2scalar

import abc
import random

from utils_pkg.utils import collate_first2_args


class DNN_OGD(DNN_base, metaclass=abc.ABCMeta):

    @abc.abstractmethod
    def __init__(self, cfgs: exp_config.Config, stepsize=0.0, **algo_kwargs):
        super(DNN_OGD, self).__init__(cfgs=cfgs, **algo_kwargs)
        self.lr = stepsize

        self.optimizer = None
        # print('DNN_OGD Stepsize: {}'.format(self.lr))

        self.estimate_result = {
            "D": [],
            "G": [],
        }

        self.grad_clip = self.cfgs.online_cfgs.grad_clip
        self.projection = self.cfgs.online_cfgs.kwargs.get("projection", False)

        self.rep_data_buffer = []

        if self.alg_kwargs.get("unsupervised_update", True):

            if self.cfgs.online_cfgs.update_DNN_represent:
                self.dataloader = DataLoader(
                    self.alg_kwargs["dataset"],
                    num_workers=0,
                    batch_size=self.cfgs.online_cfgs.kwargs["rep_batch_size"],
                    shuffle=True,
                    pin_memory=False,
                    collate_fn=collate_first2_args,
                )
                for batch_idx, (data, target) in enumerate(self.dataloader):
                    # initialize the rep_data_buffer to be the (source data and source label)
                    # data, target = data.to(self.device), target.to(self.device)
                    self.rep_data_buffer.append((data, target))

            if not cfgs.online_cfgs.kwargs.get("is_base_expert", False):
                self.source_rep, self.source_label = self.get_rep_of_data(
                    self.alg_kwargs["dataset"]
                )

    def opt_rep(self):
        """
        Optimize the representation layer (except the last layer classifier) with OGD.
        """
        #     use data and label in rep_data_buffer to optimize the rep_model
        self.online_rep_model.train()
        self.online_cls_model = self.online_cls_model.to(self.device)

        if self.cfgs.online_cfgs.kwargs.get("only_opt_rep", False):
            # optimizer only the rep_model
            text = "only opt rep model"
            self.online_cls_model.eval()
            optimizer = SGD(
                self.online_rep_model.parameters(),
                lr=float(self.cfgs.online_cfgs.kwargs["rep_lr"]),
            )
        else:
            # optimizer both the rep_model and cls_model
            text = "opt rep and cls models"
            self.online_cls_model.train()
            optimizer = SGD(
                list(self.online_rep_model.parameters())
                + list(self.online_cls_model.parameters()),
                lr=float(self.cfgs.online_cfgs.kwargs["rep_lr"]),
            )

        optimizer.zero_grad()

        loss = 0.0
        for epoch in range(self.cfgs.online_cfgs.kwargs["rep_optimize_epoch"]):
            for data, label in tqdm(
                self.rep_data_buffer,
                desc="Optimize {}, loss={}".format(text, loss),
                leave=True,
            ):
                label = label.to(self.device)
                data = data.to(self.device)
                data = self.online_rep_model(data)
                output = self.online_cls_model(data)
                # use logistic loss to optimize the online_rep_model
                loss = nn.CrossEntropyLoss()(output, label)
                loss.backward()
                optimizer.step()

        # get self.source_rep using the rep_model
        self.source_rep, self.source_label = self.get_rep_of_data(
            self.alg_kwargs["dataset"]
        )

    @torch.no_grad()
    def get_rep_of_data(self, dataset):
        dataloader = DataLoader(
            dataset,
            num_workers=0,
            batch_size=self.cfgs.online_cfgs.kwargs.get("rep_batch_size", 256),
            shuffle=False,
            pin_memory=False,
            collate_fn=collate_first2_args,
        )
        tot_rep = None
        tot_label = None
        for batch_idx, (data, label) in enumerate(
            tqdm(dataloader, desc="Updating rep_data")
        ):
            if self.online_rep_model is not None:
                data = data.to(self.device)
                rep = self.online_rep_model(data).cpu()
            else:
                rep = data.cpu()
            label = label.cpu()
            if tot_rep is None:
                tot_rep = rep
                tot_label = label
            else:
                tot_rep = torch.cat((tot_rep, rep), dim=0)
                tot_label = torch.cat((tot_label, label), dim=0)
        return tot_rep, tot_label

    def opt_cls_one_batch(self, source_rep, source_label, target_data):
        self.online_cls_model = self.online_cls_model.cpu()
        self.online_cls_model.train()
        timer = Timer()
        optimizer = SGD(self.online_cls_model.parameters(), lr=self.lr)
        optimizer.zero_grad()

        # if self.online_rep_model is not None:
        #     self.online_rep_model.eval()
        #     source_data = self.online_rep_model(source_data).cpu().detach()

        output = self.online_cls_model(source_rep)

        info = self.criterion(output.float(), source_label)

        loss = info["estimate"]
        loss.backward()

        if self.grad_clip:
            nn.utils.clip_grad_norm_(
                self.online_cls_model.parameters(), 1.0, norm_type=1.0
            )

        optimizer.step()

        return tensor2scalar(info["estimate"]), tensor2scalar(info["underlying"])

    def opt_cls(self, target_data):
        """
        Only optimize the last layer classifier with OGD.
        """
        estimate_loss, underlying_loss = 0, 0

        # optimize cls_model with CPU
        _estimate_loss, _underlying_loss = self.opt_cls_one_batch(
            self.source_rep, self.source_label, target_data
        )

        if _estimate_loss is None:
            estimate_loss = None
        else:
            estimate_loss += _estimate_loss

        if _underlying_loss is None:
            underlying_loss = None
        else:
            underlying_loss += _underlying_loss

        if estimate_loss is not None:
            estimate_loss /= len(self.dataloader)
        if underlying_loss is not None:
            underlying_loss /= len(self.dataloader)

        # for batch_idx, (source_data, source_label) in enumerate(self.cache):
        #     source_data, source_label = source_data.to(self.device), source_label.to(self.device)
        #     _estimate_loss, _underlying_loss = self.opt_cls_one_batch(source_data, source_label, target_data)
        #
        #     if _estimate_loss is None:
        #         estimate_loss = None
        #     else:
        #         estimate_loss += _estimate_loss
        #
        #     if _underlying_loss is None:
        #         underlying_loss = None
        #     else:
        #         underlying_loss += _underlying_loss
        #
        # if estimate_loss is not None:
        #     estimate_loss /= len(self.dataloader)
        # if underlying_loss is not None:
        #     underlying_loss /= len(self.dataloader)

        if self.projection:
            self.online_cls_model.project()

        # For OLS setting: add the pseudo-label to rep_data_buffer
        pseudo_target_label = self.predict(target_data)

        if self.cfgs.online_cfgs.update_DNN_represent:
            if (
                len(self.rep_data_buffer[-1]) + len(target_data)
                > self.cfgs.online_cfgs.kwargs["rep_batch_size"]
            ):
                self.rep_data_buffer.append(
                    (target_data.cpu(), pseudo_target_label.cpu())
                )
            else:
                self.rep_data_buffer[-1] = (
                    torch.cat((self.rep_data_buffer[-1][0], target_data.cpu()), dim=0),
                    torch.cat(
                        (self.rep_data_buffer[-1][1], pseudo_target_label.cpu()), dim=0
                    ),
                )

        return estimate_loss, underlying_loss

    @torch.no_grad()
    def predict(self, data):
        return super(DNN_OGD, self).predict(data)

    def eval(self):

        estimate_loss, underlying_loss = 0, 0

        for batch_idx, (data, target) in enumerate(self.cache):
            data, target = data.to(self.device), target.to(self.device)
            if self.online_rep_model is not None:
                data = self.online_rep_model(data).detach()
            output = self.online_cls_model(data)

            info = self.criterion(output.float(), target)

            estimate_loss += info["estimate"].item()
            if info["underlying"] is None:
                underlying_loss = None
            else:
                underlying_loss += info["underlying"].item()

        estimate_loss /= len(self.dataloader)
        if underlying_loss is not None:
            underlying_loss /= len(self.dataloader)

        return estimate_loss, underlying_loss

    def alg_forward(self, target_data, prior_estimate, t):
        pred = self.predict(target_data)
        estimate_loss, underlying_loss = self.opt_cls(target_data)
        if (
            self.cfgs.online_cfgs.update_DNN_represent
            and t % self.cfgs.online_cfgs.kwargs["rep_update_interval"] == 0
        ):
            print("Update the representation layer.")
            self.opt_rep()

        return pred, estimate_loss, underlying_loss
