# the algorithms in this folder are all abstract classes,
# and the actual instantiation is in the subfolders (LabelShift and NewClass, etc.)
