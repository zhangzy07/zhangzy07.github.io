import torch
import random
import numpy as np


# Use the risk over a period of time to decide
# Take the starting node, and use two separate integrations to see the results in this data (SOSE)
# To implement POSE, it's necessary to use new data every time an absolute advantage is taken (to prevent a series of problems caused by rollback of the trained part)
# Lines 111-135 get the risk
# This version uses a string to represent chromosomes


class EvoPruner(object):
    def __init__(self) -> None:
        """
        TWO TYPES: SOSE AND POSE
        SOSE: Optimize solution
        POSE: Optimize solution and #learners (NOT IMPLEMENTED)
        """
        self.evotype = "SOSE"
        self.learners_num = None
        self.max_t = 400
        self.stationary_cnt = 0
        self.prune_now = False

        self.solution = None
        self.gen_num = 0
        self.new_sol = None
        self.mutation_rate = 0.3  # initialize
        self.rng = np.random.default_rng(47)

    def set_learners_num(self, learners_num):
        self.learners_num = learners_num

    def set_type(self, evotype):
        self.evotype = evotype

    def init_type(self):
        if self.evotype == "SOSE":
            self.solution = bin(self.rng.integers(1, 2**self.learners_num))[2:]
            self.solution = (
                "0" * (self.learners_num - len(self.solution)) + self.solution
            )
            self.gen_num = 0
            self.new_sol = self.mutation(self.solution)
        else:
            raise NotImplementedError

    def gen_idx(self, prob, length):
        idx = ""
        for _ in range(length):
            bit = "1" if self.rng.random() < prob else "0"
            idx += bit
        return idx

    def str_xor(self, str1, str2):
        length = len(str1)
        int1 = int(str1, 2)
        int2 = int(str2, 2)
        rst = int1 ^ int2
        bi_rst = bin(rst)[2:]
        ans = "0" * (length - len(bi_rst)) + bi_rst
        return ans

    def mutation(self, one_sol):
        mutation_idx = self.gen_idx(self.mutation_rate, self.learners_num)
        ans = self.str_xor(one_sol, mutation_idx)
        while int(mutation_idx, 2) == 0 or all(char == "0" for char in ans):
            mutation_idx = self.gen_idx(self.mutation_rate, self.learners_num)
            ans = self.str_xor(one_sol, mutation_idx)
        return ans

    def sose_update(self, prev_risk, new_risk):
        # prev_loss and new_loss are calculated externally and then passed as parameters
        # Since it relies on risk, then pass and compare risk afterwards
        # End if no improvement after five rounds, or end after a maximum of fifty rounds

        # if self.stationary_cnt >= 5 or self.gen_num >= self.max_t:
        #     self.prune_now = True
        #     return

        if prev_risk > new_risk:
            self.solution = self.new_sol
            self.new_sol = self.mutation(self.solution)
            self.stationary_cnt = 0
        else:
            self.new_sol = self.mutation(self.solution)
            self.stationary_cnt += 1
        self.gen_num += 1
