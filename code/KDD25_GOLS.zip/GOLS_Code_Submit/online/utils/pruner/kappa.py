import torch


class KappaPruner(object):
    def __init__(self) -> None:
        self.kappa_pred = None
        self.turn_num = 0
        self.kappa = None

    def update_data(self, pred_data, ssp_num):
        if self.turn_num == 0:
            # self.kappa_pred = torch.stack([pred_data for i in range(ssp_num)],dim=1)
            self.kappa_pred = pred_data.detach()  # copy
            # torch.Size([10,k])
            # print(self.kappa_pred)
            # print(self.kappa_pred[1].shape)
            # assert 0
            self.turn_num += 1
        else:
            # new_pred = torch.stack([pred_data for i in range(ssp_num)],dim=1)
            # self.kappa_pred = torch.cat([self.kappa_pred, new_pred], dim=0)
            self.kappa_pred = torch.cat([self.kappa_pred, pred_data], dim=0)
            # print(self.kappa_pred.shape)
            # assert 0
            self.turn_num += 1

    def get_kappa(self, ssp_num):
        """
        Given a kappa value, output a list with the length of C(ssp_num,2) (deprecated)
        During pruning, delete the one with the highest average kappa value
        What is the average kappa? The sum of kappa values can be understood as the contribution to diversity, the smallest average contributes the least (just use the average directly)
        The results are presented in a matrix, where element i,j is the kappa between the ith and jth learners
        """
        ans = [0] * (ssp_num * ssp_num)
        m = self.kappa_pred.shape[0]
        for i in range(ssp_num):
            for j in range(i + 1, ssp_num):
                same_num = torch.sum(
                    (self.kappa_pred[:, i] - self.kappa_pred[:, j]) == 0
                ).item()
                # class number
                unique_values_a = torch.bincount(self.kappa_pred[:, i])
                unique_values_b = torch.bincount(self.kappa_pred[:, j])

                shape1 = unique_values_a.shape
                shape2 = unique_values_b.shape
                max_len = max(shape1[0], shape2[0])
                if shape1[0] < max_len:
                    padding = torch.zeros(
                        max_len - shape1[0], dtype=unique_values_a.dtype
                    )
                    unique_values_a = torch.cat([unique_values_a, padding])

                if shape2[0] < max_len:
                    padding = torch.zeros(
                        max_len - shape2[0], dtype=unique_values_b.dtype
                    )
                    unique_values_b = torch.cat([unique_values_b, padding])
                rst = unique_values_a * unique_values_b
                theta1 = same_num / m
                theta2 = torch.sum(rst) / (m**2)
                kappa = (theta1 - theta2) / (1 - theta2)
                idx = i * ssp_num + j
                ans[idx] = kappa

        ans = torch.tensor(ans).reshape(ssp_num, ssp_num)
        upper_tri = torch.triu(ans)
        ans = ans + upper_tri.t()
        self.kappa = ans  # is a tensor
        return self.kappa
