from utils import *
def main():
    parser = argparse.ArgumentParser(description='Run PrefUCB experiments with various settings')
    parser.add_argument('--scenarios', nargs='+', type=str,
                        choices=list(get_preference_matrices().keys()),
                        help='Specific scenarios to run (default: all scenarios)')
    parser.add_argument('--T', type=int, default=10000,
                        help='Number of time steps (default: 10000)')
    parser.add_argument('--retrain', type=int, default=0,
                        help='Force retraining even if results exist (default: 0)')
    parser.add_argument('--repeats', type=int, default=10,
                        help='Number of experiment repeats (default: 10)')

    args = parser.parse_args()

    # Create results directory
    results_dir = Path('./PrefUCB_results')
    results_dir.mkdir(exist_ok=True)

    # Get scenarios to run
    all_scenarios = list(get_preference_matrices().keys())
    scenarios_to_run = args.scenarios if args.scenarios else all_scenarios

    if args.retrain:
        # Run experiments for all specified scenarios
        print(f"Running experiments with retrain flag...")
        run_experiment(scenarios_to_run, args.T, args.repeats)
    else:
        # Check which scenarios need to be run
        existing_results = {f.stem for f in results_dir.glob('*.npy')}
        missing_scenarios = [s for s in scenarios_to_run if s not in existing_results]

        if missing_scenarios:
            print(f"Running experiments for missing scenarios: {missing_scenarios}")
            run_experiment(missing_scenarios, args.T, args.repeats)
        else:
            print("All scenario results exist.")

    # Plot results after experiments are complete
    print("\nGenerating plots for all scenarios...")
    plot_results(scenarios_to_run)


if __name__ == "__main__":
    main()