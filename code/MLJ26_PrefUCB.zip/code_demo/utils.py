import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from typing import List, Set, Tuple, Dict
import os
from pathlib import Path
import argparse


def get_reward(action: int, true_rewards: np.ndarray, concentration: float = 10.0) -> np.ndarray:
    """Generate noisy reward using beta distribution"""
    true_r = np.clip(true_rewards[action], 0.01, 0.99)
    alpha = true_r * concentration
    beta = concentration * (1 - true_r)
    return np.random.beta(alpha, beta)


def find_pareto_c_optimal(rewards: np.ndarray, W: np.ndarray) -> Set[int]:
    """Find Pareto-C-optimal actions (Definition 3.4)"""
    optimal_actions = set()
    n_actions = rewards.shape[0]

    for i in range(n_actions):
        is_optimal = True
        reward_i = rewards[i]

        for j in range(n_actions):
            if i == j:
                continue

            # Check if action j C-dominates action i
            reward_j = rewards[j]
            diff = reward_j - reward_i

            # Check W(rⱼ - rᵢ) ≥ 0 (Definition 3.3)
            if np.all(W @ diff >= 0):
                is_optimal = False
                break

        if is_optimal:
            optimal_actions.add(i)

    return optimal_actions


class PrefUCB:
    def __init__(self, num_actions: int, num_objectives: int, preference_matrix: np.ndarray,
                 optimal_actions: Set[int], T: int):
        self.K = num_actions
        self.d = num_objectives
        self.T = T
        self.W = preference_matrix
        self.M = preference_matrix.shape[0]
        self.optimal_actions = optimal_actions

        # Initialize counters and estimates
        self.t = 0
        self.n = np.zeros(self.K)
        self.empirical_means = np.zeros((self.K, self.d))

        # Track results
        self.instant_regret = []
        self.cumulative_regret = []
        self.total_regret = 0
        self.rewards_history = []  # Track all d objectives

        # Compute L_k and U_k for normalization
        self.L_k = np.array([np.sum(np.minimum(0, self.W[k])) for k in range(self.M)])
        self.U_k = np.array([np.sum(np.maximum(0, self.W[k])) for k in range(self.M)])

    def S_k(self, rewards: np.ndarray, k: int) -> float:
        projection = np.dot(self.W[k], rewards)
        return (projection - self.L_k[k]) / (self.U_k[k] - self.L_k[k])

    def f_function(self, q_k: float, S_ka: float) -> float:
        if q_k <= 0 or q_k >= 1:
            return -np.inf
        return S_ka * np.log(q_k) + (1 - S_ka) * np.log(1 - q_k)

    def select_action(self) -> int:
        self.t += 1
        if self.t <= self.K:
            return self.t - 1

        ucb_values = np.zeros(self.K)
        for a in range(self.K):
            if self.n[a] == 0:
                return a

            min_q = float('inf')
            for k in range(self.M):
                S_ka = self.S_k(self.empirical_means[a], k)
                log_t_over_n = np.log(self.t) / self.n[a]
                C_ak = self.f_function(S_ka, S_ka) - log_t_over_n

                left, right = S_ka, 1.0
                for _ in range(50):
                    mid = (left + right) / 2
                    if self.f_function(mid, S_ka) >= C_ak:
                        left = mid
                    else:
                        right = mid
                min_q = min(min_q, left)

            ucb_values[a] = min_q

        return int(np.argmax(ucb_values))

    def update(self, action: int, reward: np.ndarray) -> Tuple[float, float]:
        self.n[action] += 1
        self.empirical_means[action] = (
                (self.empirical_means[action] * (self.n[action] - 1) + reward) / self.n[action]
        )
        self.rewards_history.append(reward)

        instant_regret = 0 if action in self.optimal_actions else 1
        self.total_regret += instant_regret

        self.instant_regret.append(instant_regret)
        self.cumulative_regret.append(self.total_regret)

        return instant_regret, self.total_regret


def get_preference_matrices() -> Dict[str, np.ndarray]:
    """Return preference matrices for different scenarios"""
    return {
        "Customer Service": np.array([
            [1, 0, 1, 0, 0, 2, 1],
            [0, -1, 0, 0, 0, 1, 0]
        ]),
        "Legal Document Review": np.array([
            [0, 1, 2, 1, 0, 0, 0],
            [0, 0, 1, 0, 0, -1, 0]
        ]),
        "High-frequency Trade": np.array([
            [0, 0, 0, 1, 0, 0, 2],
            [0, -1, 0, 0, 0, 0, 1]
        ]),
        "Scientific Discovery": np.array([
            [0, 2, 1, 1, 1, 0, 0],
            [0, 1, 0, 0, 0, 0, -1]
        ]),
    }


def run_experiment(scenarios: List[str], T: int, n_runs: int):
    """Run experiments for specified scenarios"""
    # Load data
    df = pd.read_csv("./open-llm/open-llm-leaderboard_normalized.csv")
    reward_columns = ['Accuracy', 'Advanced Problem-Solving', 'Reasoning',
                      'Domain Knowledge', 'Interaction Consistency',
                      'Multitasking', 'Intensity']
    true_rewards = df[reward_columns].values

    # Problem dimensions
    num_actions = true_rewards.shape[0]
    num_objectives = true_rewards.shape[1]

    # Get preference matrices for scenarios
    preference_matrices = get_preference_matrices()
    if scenarios:
        preference_matrices = {k: v for k, v in preference_matrices.items() if k in scenarios}

    # Initialize results storage
    os.makedirs('./PrefUCB_results', exist_ok=True)

    # Run experiments for each scenario
    for scenario, W in preference_matrices.items():
        print(f"\nRunning experiments for {scenario} scenario")

        # Find optimal actions for this scenario
        optimal_actions = find_pareto_c_optimal(true_rewards, W)
        print(f"Number of Pareto-C-optimal actions: {len(optimal_actions)}")

        # Initialize results arrays
        results = np.zeros((1, 9, T, n_runs))  # 1 algorithm, 9 metrics, T timesteps, n_runs

        for run in range(n_runs):
            print(f"Run {run + 1}/{n_runs}")

            # Initialize PrefUCB algorithm
            algorithm = PrefUCB(num_actions, num_objectives, W, optimal_actions, T)

            # Run algorithm
            for t in range(T):
                action = algorithm.select_action()
                reward = get_reward(action, true_rewards)
                _, _ = algorithm.update(action, reward)

                # Store results
                results[0, 0, t, run] = algorithm.instant_regret[-1]
                results[0, 1, t, run] = algorithm.cumulative_regret[-1]
                results[0, 2:, t, run] = reward

        # Save results for this scenario
        np.save(f'./PrefUCB_results/{scenario}.npy', results)


def plot_results(scenarios: List[str] = None, show_std: bool = True):
    """
    Plot cumulative regret results for each scenario in separate plots.

    Args:
        scenarios: List of scenarios to plot. If None, plots all available scenarios.
        show_std: Whether to show standard deviation bands in the plots.
    """
    if scenarios is None:
        scenarios = [f.split('.')[0] for f in os.listdir('./PrefUCB_results') if f.endswith('.npy')]

    def get_representative_points(data, n_points=20):
        """Get representative points for plotting to reduce visual complexity."""
        total_points = len(data)
        indices = np.linspace(0, total_points - 1, n_points, dtype=int)
        return indices, data[indices]

    for scenario in scenarios:
        results = np.load(f'./PrefUCB_results/{scenario}.npy')  # Shape: (1, 9, T, n_runs)

        plt.figure(figsize=(10, 6))

        # Calculate mean and standard deviation
        mean_regret = np.mean(results[0, 1, :, :], axis=1)  # Average across runs
        std_regret = np.std(results[0, 1, :, :], axis=1)

        # Get representative points for cleaner plotting
        indices, rep_mean = get_representative_points(mean_regret)
        _, rep_std = get_representative_points(std_regret)

        # Plot mean regret
        plt.plot(indices, rep_mean, color='#FF6B6B', lw=2, label='PrefUCB')

        # Add standard deviation bands if requested
        if show_std:
            plt.fill_between(indices,
                             rep_mean - rep_std,
                             rep_mean + rep_std,
                             color='#FF6B6B', alpha=0.3,
                             label='±1 std dev')

        plt.xlabel('Time Step', fontsize=12)
        plt.ylabel('Cumulative Regret', fontsize=12)
        plt.title(f'Cumulative Regret - {scenario}', fontsize=14)
        plt.grid(True, linestyle='--', alpha=0.7)
        plt.yscale('log')
        plt.legend()

        # Improve layout and display
        plt.tight_layout()
        plt.show()

