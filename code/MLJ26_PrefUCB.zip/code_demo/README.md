# PrefUCB Experiment Runner

This script implements the PrefUCB algorithm for multi-objective bandits with preference-based feedback. It allows running experiments across different scenarios with configurable parameters.

## Command Line Arguments

The script accepts the following command line arguments:

### `--scenarios`
- **Type**: List of strings
- **Default**: All available scenarios
- **Choices**: 
  - "Legal Document Review"
  - "Customer Service"
  - "High-frequency Trade"
  - "Scientific Discovery"
- **Description**: Specifies which scenarios to run experiments for. Multiple scenarios can be provided.
- **Example**: `--scenarios "Legal Document Review" "Customer Service"`

### `--T`
- **Type**: Integer
- **Default**: 10000
- **Description**: Number of time steps for each experiment run
- **Example**: `--T 5000`

### `--retrain`
- **Type**: Integer (0 or 1)
- **Default**: 0
- **Description**: Whether to force retraining even if results already exist
  - 0: Skip scenarios that already have results
  - 1: Rerun all specified scenarios
- **Example**: `--retrain 1`

### `--repeats`
- **Type**: Integer
- **Default**: 10
- **Description**: Number of times to repeat each experiment for statistical significance
- **Example**: `--repeats 20`

## Example Usage

1. Run experiments for all scenarios with default settings:
```bash
python main.py
```

2. Run specific scenarios with custom parameters:
```bash
python main.py --scenarios "Legal Document Review" "Customer Service" --T 5000 --repeats 15
```

3. Force retraining for all scenarios:
```bash
python main.py --retrain 1
```

4. Run a quick test with fewer time steps and repeats:
```bash
python main.py --T 1000 --repeats 5
```

## Output

The script saves results in the `./PrefUCB_results` directory, with one `.npy` file per scenario. Each file contains the following metrics:
- Instant regret
- Cumulative regret
- Performance metrics for each objective

## Dependencies

- NumPy
- Pandas
- Matplotlib
- Pathlib

Make sure to have the required data file `./open-llm/open-llm-leaderboard_normalized.csv` in the correct location before running the experiments.